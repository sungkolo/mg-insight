'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronRight, Home } from 'lucide-react';

const resourcesNav = [
  { label: 'Documentation', href: '/resources/documentation' },
  { label: 'Blog', href: '/resources/blog' },
];

export default function ResourcesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-charcoal-950 pt-20 sm:pt-24">
      <div className="container-width px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm mb-8">
          <Link 
            href="/" 
            className="text-muted-foreground hover:text-gold-400 transition-colors flex items-center gap-1"
          >
            <Home className="w-4 h-4" />
            <span>Home</span>
          </Link>
          <ChevronRight className="w-4 h-4 text-muted-foreground/50" />
          <span className="text-gold-400">Resources</span>
        </nav>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <aside className="lg:col-span-1">
            <div className="sticky top-28">
              <h3 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">
                Resources
              </h3>
              <nav className="space-y-1">
                {resourcesNav.map((item) => (
                  <Link
                    key={item.label}
                    href={item.href}
                    className={`block px-4 py-2.5 rounded-lg text-sm transition-colors ${
                      pathname === item.href
                        ? 'bg-gold-500/10 text-gold-400 border-l-2 border-gold-500'
                        : 'text-muted-foreground hover:text-foreground hover:bg-charcoal-800/50'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </div>
          </aside>

          {/* Main Content */}
          <main className="lg:col-span-3">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}
