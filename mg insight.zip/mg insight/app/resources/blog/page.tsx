'use client';

import { Card, CardContent } from '@/components/ui/card';
import { FileText, Calendar, Clock, ArrowRight, Tag } from 'lucide-react';

// Blog data - can be moved to API/JSON file later
const blogPosts = [
  {
    id: 1,
    title: 'Memahami Pola Pikir Melalui Mind Geometry',
    excerpt: 'Bagaimana geometri kognitif dapat membantu Anda memahami pola pikir dan mengambil keputusan yang lebih baik dalam kehidupan sehari-hari.',
    date: '15 Des 2024',
    readTime: '8 min',
    category: 'Insight',
    featured: true,
  },
  {
    id: 2,
    title: '5 Teknik Meningkatkan Emotional Intelligence',
    excerpt: 'Pelajari teknik-teknik praktis untuk mengembangkan kecerdasan emosional dan meningkatkan kualitas hubungan interpersonal.',
    date: '12 Des 2024',
    readTime: '6 min',
    category: 'Self-Development',
    featured: false,
  },
  {
    id: 3,
    title: 'The Science Behind Decision Making',
    excerpt: 'Eksplorasi mendalam tentang proses pengambilan keputusan dan bagaimana cognitive bias mempengaruhi pilihan kita.',
    date: '10 Des 2024',
    readTime: '10 min',
    category: 'Research',
    featured: false,
  },
  {
    id: 4,
    title: 'Mengapa Journaling Efektif untuk Kesehatan Mental',
    excerpt: 'Bukti ilmiah dan praktik terbaik dalam menggunakan jurnal sebagai alat untuk meningkatkan kesejahteraan psikologis.',
    date: '8 Des 2024',
    readTime: '5 min',
    category: 'Wellness',
    featured: false,
  },
  {
    id: 5,
    title: 'Probability Thinking dalam Kehidupan Sehari-hari',
    excerpt: 'Cara berpikir probabilistik dapat membantu Anda membuat keputusan yang lebih rasional dan mengelola risiko dengan lebih efektif.',
    date: '5 Des 2024',
    readTime: '7 min',
    category: 'Insight',
    featured: false,
  },
  {
    id: 6,
    title: 'Transformasi Digital dalam Psikologi Modern',
    excerpt: 'Bagaimana teknologi digital mengubah cara kita memahami dan mengembangkan potensi diri.',
    date: '1 Des 2024',
    readTime: '9 min',
    category: 'Technology',
    featured: false,
  },
  {
    id: 7,
    title: 'Membangun Mindfulness: Panduan untuk Pemula',
    excerpt: 'Panduan lengkap untuk memulai praktik mindfulness dan mengintegrasikannya ke dalam rutinitas harian Anda.',
    date: '28 Nov 2024',
    readTime: '6 min',
    category: 'Wellness',
    featured: false,
  },
  {
    id: 8,
    title: 'Cognitive Bias: Musuh Tersembunyi dalam Keputusan',
    excerpt: 'Mengenali berbagai jenis cognitive bias dan strategi untuk menghindarinya dalam pengambilan keputusan penting.',
    date: '25 Nov 2024',
    readTime: '8 min',
    category: 'Insight',
    featured: false,
  },
  {
    id: 9,
    title: 'Strategi Mengatasi Procrastination',
    excerpt: 'Teknik berbasis psikologi untuk mengatasi kebiasaan menunda-nunda dan meningkatkan produktivitas.',
    date: '22 Nov 2024',
    readTime: '7 min',
    category: 'Self-Development',
    featured: false,
  },
  {
    id: 10,
    title: 'The Power of Habit: Membentuk Kebiasaan Positif',
    excerpt: 'Memahami loop kebiasaan dan cara memanfaatkannya untuk membangun rutinitas yang mendukung kesuksesan.',
    date: '18 Nov 2024',
    readTime: '9 min',
    category: 'Self-Development',
    featured: false,
  },
  {
    id: 11,
    title: 'Mengelola Stress di Era Digital',
    excerpt: 'Strategi praktis untuk menjaga kesehatan mental di tengah tekanan dunia digital yang serba cepat.',
    date: '15 Nov 2024',
    readTime: '6 min',
    category: 'Wellness',
    featured: false,
  },
  {
    id: 12,
    title: 'Psychology of Motivation: Apa yang Mendorong Kita',
    excerpt: 'Eksplorasi teori motivasi dan cara menerapkannya untuk mencapai tujuan personal dan profesional.',
    date: '12 Nov 2024',
    readTime: '10 min',
    category: 'Research',
    featured: false,
  },
];

const categories = ['All', 'Insight', 'Self-Development', 'Research', 'Wellness', 'Technology'];

export default function BlogPage() {
  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gold-500/20 to-gold-600/10 border border-gold-500/20 flex items-center justify-center">
            <FileText className="w-6 h-6 text-gold-400" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Blog</h1>
            <p className="text-muted-foreground">Artikel dan insight terbaru dari MG Insight</p>
          </div>
        </div>
        
        {/* Categories */}
        <div className="flex flex-wrap gap-2 mt-6">
          {categories.map((cat, idx) => (
            <button
              key={idx}
              className={`px-4 py-2 rounded-full text-sm transition-colors ${
                idx === 0
                  ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30'
                  : 'bg-charcoal-800/50 text-muted-foreground hover:text-foreground hover:bg-charcoal-800 border border-gold-500/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Post */}
      <Card className="bg-gradient-to-br from-charcoal-900/80 to-charcoal-900/50 border-gold-500/20 mb-8 overflow-hidden">
        <CardContent className="p-0">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-8 flex flex-col justify-center">
              <div className="flex items-center gap-2 mb-3">
                <span className="px-3 py-1 rounded-full text-xs bg-gold-500/20 text-gold-400 border border-gold-500/30">
                  Featured
                </span>
                <span className="text-xs text-muted-foreground">{blogPosts[0].category}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-foreground mb-3 hover:text-gold-400 cursor-pointer transition-colors">
                {blogPosts[0].title}
              </h2>
              <p className="text-muted-foreground mb-4 text-sm">
                {blogPosts[0].excerpt}
              </p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{blogPosts[0].date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{blogPosts[0].readTime}</span>
                </div>
              </div>
            </div>
            <div className="relative h-64 md:h-auto bg-gradient-to-br from-gold-500/10 to-gold-600/5 flex items-center justify-center">
              <div className="text-6xl opacity-50">🧠</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Blog Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogPosts.slice(1).map((post) => (
          <Card 
            key={post.id} 
            className="bg-charcoal-900/30 border-gold-500/10 hover:border-gold-500/30 transition-all duration-300 cursor-pointer group"
          >
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <Tag className="w-3 h-3 text-gold-400" />
                <span className="text-xs text-gold-400">{post.category}</span>
              </div>
              <h3 className="text-base font-semibold text-foreground mb-2 group-hover:text-gold-400 transition-colors line-clamp-2">
                {post.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {post.excerpt}
              </p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{post.date}</span>
                  </div>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{post.readTime}</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-gold-400 transition-colors" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More */}
      <div className="text-center mt-10">
        <button className="px-6 py-3 rounded-xl text-sm font-medium border border-gold-500/30 text-gold-400 hover:bg-gold-500/10 transition-colors">
          Load More Articles
        </button>
      </div>
    </div>
  );
}
