'use client';

import { Card, CardContent } from '@/components/ui/card';
import { BookOpen, ArrowRight, Search, ChevronDown, ExternalLink, Code, Zap, Shield, BarChart3 } from 'lucide-react';

const docCategories = [
  {
    title: 'Getting Started',
    description: 'Panduan dasar untuk memulai menggunakan MG Insight',
    icon: Zap,
    articles: [
      { title: 'Pengenalan Mind Geometry', time: '5 min read', slug: 'intro' },
      { title: 'Setup Akun & Profil', time: '3 min read', slug: 'setup' },
      { title: 'Navigasi Dashboard', time: '4 min read', slug: 'dashboard' },
      { title: 'Memahami Interface', time: '6 min read', slug: 'interface' },
    ],
  },
  {
    title: 'Features & Tools',
    description: 'Dokumentasi lengkap fitur-fitur MG Insight',
    icon: BarChart3,
    articles: [
      { title: 'Life Map - Peta Kehidupan', time: '8 min read', slug: 'lifemap' },
      { title: 'Psych Experiment - Assessment', time: '7 min read', slug: 'psychexperiment' },
      { title: 'Probability Simulator', time: '5 min read', slug: 'probsim' },
      { title: 'Mind Journal - Jurnal Digital', time: '6 min read', slug: 'mindjournal' },
      { title: 'Puzzle Section - Brain Training', time: '4 min read', slug: 'puzzle' },
      { title: 'Knowledge Graph - Visualisasi', time: '5 min read', slug: 'knowledgegraph' },
    ],
  },
  {
    title: 'Advanced Topics',
    description: 'Panduan mendalam untuk penggunaan advanced',
    icon: Code,
    articles: [
      { title: 'Integrasi Data & Analytics', time: '10 min read', slug: 'analytics' },
      { title: 'Custom Analysis Models', time: '12 min read', slug: 'custom-models' },
      { title: 'API Documentation', time: '15 min read', slug: 'api' },
      { title: 'Export & Reporting', time: '8 min read', slug: 'export' },
      { title: 'Webhook Integration', time: '6 min read', slug: 'webhook' },
    ],
  },
  {
    title: 'Security & Privacy',
    description: 'Informasi keamanan dan privasi data',
    icon: Shield,
    articles: [
      { title: 'Data Encryption Standards', time: '5 min read', slug: 'encryption' },
      { title: 'Privacy Policy Overview', time: '7 min read', slug: 'privacy' },
      { title: 'GDPR Compliance', time: '8 min read', slug: 'gdpr' },
      { title: 'Data Retention Policy', time: '4 min read', slug: 'retention' },
    ],
  },
];

const faqItems = [
  {
    question: 'Bagaimana cara memulai assessment pertama?',
    answer: 'Setelah login, Anda dapat langsung mengakses berbagai assessment melalui dashboard. Klik "Start Assessment" untuk memulai. Setiap assessment memiliki panduan langkah demi langkah yang mudah diikuti.',
  },
  {
    question: 'Apakah data saya aman?',
    answer: 'Ya, kami menggunakan enkripsi 256-bit untuk semua data pengguna. Data disimpan di server yang memenuhi standar ISO 27001 dan SOC 2. Privasi Anda adalah prioritas utama kami.',
  },
  {
    question: 'Bagaimana interpretasi hasil analisis?',
    answer: 'Setiap hasil dilengkapi dengan penjelasan detail dan rekomendasi personal. Anda juga bisa berkonsultasi dengan ahli kami melalui fitur consultation yang tersedia di menu premium.',
  },
  {
    question: 'Bisakah saya export hasil analisis?',
    answer: 'Ya, semua hasil analisis dapat di-export dalam format PDF atau CSV. Fitur export tersedia di halaman hasil setiap assessment atau melalui menu Reports di dashboard.',
  },
  {
    question: 'Bagaimana cara mengintegrasikan dengan aplikasi lain?',
    answer: 'MG Insight menyediakan API dan webhook untuk integrasi. Dokumentasi lengkap tersedia di section Advanced Topics. Hubungi tim support untuk mendapatkan API key.',
  },
];

const quickLinks = [
  { title: 'Quick Start Guide', desc: 'Mulai dalam 5 menit', icon: '🚀', href: '#' },
  { title: 'Video Tutorials', desc: 'Pelajari dengan video', icon: '📺', href: '#' },
  { title: 'API Reference', desc: 'Dokumentasi API', icon: '📡', href: '#' },
  { title: 'FAQ', desc: 'Pertanyaan umum', icon: '❓', href: '#faq' },
];

export default function DocumentationPage() {
  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gold-500/20 to-gold-600/10 border border-gold-500/20 flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-gold-400" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Documentation</h1>
            <p className="text-muted-foreground">Panduan lengkap platform MG Insight</p>
          </div>
        </div>
        
        {/* Search */}
        <div className="relative mt-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Cari dokumentasi... (contoh: Life Map, API, Assessment)"
            className="w-full pl-12 pr-4 py-3 bg-charcoal-900/50 border border-gold-500/10 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold-500/30 transition-colors"
          />
        </div>
      </div>

      {/* Quick Links */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        {quickLinks.map((item, idx) => (
          <Card key={idx} className="bg-charcoal-900/30 border-gold-500/10 hover:border-gold-500/30 transition-colors cursor-pointer group">
            <CardContent className="p-4 flex items-center gap-3">
              <span className="text-2xl">{item.icon}</span>
              <div className="flex-1">
                <div className="text-sm font-medium text-foreground group-hover:text-gold-400 transition-colors">
                  {item.title}
                </div>
                <div className="text-xs text-muted-foreground">{item.desc}</div>
              </div>
              <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-gold-400 transition-colors" />
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Documentation Categories */}
      <div className="space-y-8">
        {docCategories.map((category, idx) => {
          const IconComponent = category.icon;
          return (
            <Card key={idx} className="bg-charcoal-900/30 border-gold-500/10">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-gold-500/10 flex items-center justify-center">
                    <IconComponent className="w-4 h-4 text-gold-400" />
                  </div>
                  <h2 className="text-lg font-semibold text-foreground">{category.title}</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-4 ml-11">{category.description}</p>
                
                <div className="space-y-1 ml-11">
                  {category.articles.map((article, aIdx) => (
                    <div
                      key={aIdx}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-gold-500/5 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <ChevronDown className="w-4 h-4 text-muted-foreground rotate-[-90deg] group-hover:text-gold-400 transition-colors" />
                        <span className="text-sm text-foreground group-hover:text-gold-400 transition-colors">
                          {article.title}
                        </span>
                      </div>
                      <span className="text-xs text-muted-foreground">{article.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* FAQ Section */}
      <div id="faq" className="mt-12">
        <h2 className="text-xl font-semibold text-foreground mb-6">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqItems.map((item, idx) => (
            <Card key={idx} className="bg-charcoal-900/30 border-gold-500/10">
              <CardContent className="p-4">
                <h3 className="text-sm font-medium text-gold-400 mb-2">{item.question}</h3>
                <p className="text-sm text-muted-foreground">{item.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Need Help */}
      <Card className="mt-12 bg-gradient-to-br from-gold-500/10 to-gold-600/5 border-gold-500/20">
        <CardContent className="p-6 text-center">
          <h3 className="text-lg font-semibold text-foreground mb-2">Butuh Bantuan Lebih?</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Tim support kami siap membantu Anda 24/7
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="mailto:lionr1078@gmail.com"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm bg-gold-500/20 text-gold-400 border border-gold-500/30 hover:bg-gold-500/30 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              Hubungi Support
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
