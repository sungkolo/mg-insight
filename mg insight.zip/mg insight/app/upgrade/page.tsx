import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// This page now redirects to /premium since all features are free
export default async function UpgradePage() {
  const session = await getServerSession(authOptions);
  
  // If not logged in, redirect to login
  if (!session) {
    redirect('/login?redirect=/premium');
  }
  
  // All logged-in users get access to all features
  redirect('/premium');
}
