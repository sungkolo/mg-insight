'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  LineChart,
  Line,
  ResponsiveContainer,
  YAxis,
  XAxis,
  Tooltip,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Minus,
  Target,
  Calendar,
  RefreshCw,
  Loader2,
  Smile,
  Frown,
  Meh,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  BookOpen,
  Clock,
  Crown,
} from 'lucide-react';
import Link from 'next/link';
import { useLanguage } from '@/context/language-context';

// Types for analytics data
interface WeeklyDataPoint {
  day: string;
  mood: number | null;
  entries: number;
}

interface AdvancedAnalyticsData {
  success: boolean;
  avgThisWeek: number | null;
  avgLastWeek: number | null;
  percentageChange: number | null;
  highestMoodDay: string | null;
  lowestMoodDay: string | null;
  consistency: number;
  consistencyLabel: string;
  weeklyData: WeeklyDataPoint[];
  totalEntriesThisWeek: number;
  totalEntriesLastWeek: number;
  insight: string;
  hasData: boolean;
}

export default function AdvancedAnalyticsPage() {
  const { t } = useLanguage();
  const [data, setData] = useState<AdvancedAnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await fetch('/api/analytics/advanced');

      if (!res.ok) {
        throw new Error('Failed to fetch analytics');
      }

      const result = await res.json();
      setData(result);
      setLastUpdated(new Date().toLocaleString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }));
    } catch (err) {
      console.error('Failed to fetch advanced analytics:', err);
      setError(t.error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Get mood icon based on score
  const getMoodIcon = (score: number | null) => {
    if (score === null) return <Meh className="w-6 h-6 text-gray-400" />;
    if (score >= 7) return <Smile className="w-6 h-6 text-green-400" />;
    if (score >= 4) return <Meh className="w-6 h-6 text-yellow-400" />;
    return <Frown className="w-6 h-6 text-red-400" />;
  };

  // Get trend info with proper null handling
  const getTrendInfo = (change: number | null) => {
    if (change === null) {
      return {
        icon: <Minus className="w-5 h-5" />,
        color: 'text-gray-400',
        bg: 'bg-gray-500/20',
        text: 'N/A',
        subtext: t.insufficientData,
      };
    }

    if (change === 0) {
      return {
        icon: <Minus className="w-5 h-5" />,
        color: 'text-yellow-400',
        bg: 'bg-yellow-500/20',
        text: '0%',
        subtext: t.trend,
      };
    }

    if (change > 0) {
      return {
        icon: <ArrowUpRight className="w-5 h-5" />,
        color: 'text-green-400',
        bg: 'bg-green-500/20',
        text: `+${change}%`,
        subtext: t.trend,
      };
    }

    return {
      icon: <ArrowDownRight className="w-5 h-5" />,
      color: 'text-red-400',
      bg: 'bg-red-500/20',
      text: `${change}%`,
      subtext: t.trend,
    };
  };

  // Format value display
  const formatValue = (value: number | null): string => {
    if (value === null) return t.noData;
    return value.toFixed(1);
  };

  // Custom tooltip for chart
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const point = payload[0].payload;
      return (
        <div className="bg-charcoal-900/95 border border-white/10 rounded-lg px-3 py-2 shadow-lg">
          <p className="text-xs text-muted-foreground">{point.day}</p>
          <p className="text-sm font-medium text-foreground">
            {point.mood !== null ? `${point.mood.toFixed(1)} mood` : t.noData}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-6 h-6 text-pink-400" />
            <Badge className="bg-pink-500/20 text-pink-400 border-pink-500/30">
              <Crown className="w-3 h-3 mr-1" />
              {t.premium}
            </Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">{t.usageStats}</h1>
          <p className="text-muted-foreground mt-1">
            {t.analyticsDescription}
          </p>
        </div>
        <Button
          variant="outline"
          onClick={fetchData}
          disabled={loading}
          className="border-white/10 text-foreground hover:bg-white/5"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          {t.reset}
        </Button>
      </div>

      {/* Loading State */}
      {loading && (
        <Card className="bg-charcoal-900/50 border-white/5 shadow-lg">
          <CardContent className="p-12 text-center">
            <Loader2 className="w-12 h-12 animate-spin text-pink-400 mx-auto mb-4" />
            <p className="text-lg text-foreground font-medium">{t.loading}</p>
            <p className="text-sm text-muted-foreground mt-2">{t.loading}</p>
          </CardContent>
        </Card>
      )}

      {/* Error State */}
      {error && !loading && (
        <Card className="bg-red-500/10 border-red-500/20 shadow-lg">
          <CardContent className="p-6 text-center">
            <Frown className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <p className="text-red-400">{error}</p>
            <Button
              variant="outline"
              onClick={fetchData}
              className="mt-4 border-red-500/30 text-red-400 hover:bg-red-500/10"
            >
              {t.reset}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* No Data State */}
      {data && !loading && !error && !data.hasData && (
        <Card className="bg-charcoal-900/50 border-white/5 shadow-lg">
          <CardContent className="p-8 text-center">
            <Calendar className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              {t.insufficientData}
            </h3>
            <p className="text-muted-foreground mb-6">
              {t.mindJournalDescription}
            </p>
            <Link href="/premium/mind-journal-pro">
              <Button className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white shadow-lg">
                <BookOpen className="w-4 h-4 mr-2" />
                {t.newEntry}
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Data Display */}
      {data && !loading && !error && data.hasData && (
        <>
          {/* Main Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {/* Avg This Week */}
            <Card className="bg-charcoal-900/50 border-white/5 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardContent className="p-5 text-center">
                {getMoodIcon(data.avgThisWeek)}
                <p className="text-3xl font-bold text-foreground mt-2">
                  {formatValue(data.avgThisWeek)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">{t.thisWeek}</p>
              </CardContent>
            </Card>

            {/* Avg Last Week */}
            <Card className="bg-charcoal-900/50 border-white/5 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardContent className="p-5 text-center">
                {getMoodIcon(data.avgLastWeek)}
                <p className="text-3xl font-bold text-foreground mt-2">
                  {formatValue(data.avgLastWeek)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">{t.lastWeek}</p>
              </CardContent>
            </Card>

            {/* Trend Percentage */}
            <Card className="bg-charcoal-900/50 border-white/5 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardContent className="p-5 text-center">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full ${getTrendInfo(data.percentageChange).bg}`}>
                  <span className={getTrendInfo(data.percentageChange).color}>
                    {getTrendInfo(data.percentageChange).icon}
                  </span>
                </div>
                <p className={`text-3xl font-bold mt-2 ${getTrendInfo(data.percentageChange).color}`}>
                  {getTrendInfo(data.percentageChange).text}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {getTrendInfo(data.percentageChange).subtext}
                </p>
              </CardContent>
            </Card>

            {/* Consistency */}
            <Card className="bg-charcoal-900/50 border-white/5 shadow-lg hover:shadow-xl transition-shadow rounded-xl">
              <CardContent className="p-5 text-center">
                <Target className="w-6 h-6 text-blue-400 mx-auto" />
                <p className="text-3xl font-bold text-foreground mt-2">
                  {data.consistency}/7
                </p>
                <p className="text-xs mt-1">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                    data.consistencyLabel === 'Strong' 
                      ? 'bg-green-500/20 text-green-400' 
                      : data.consistencyLabel === 'Moderate' 
                      ? 'bg-yellow-500/20 text-yellow-400' 
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {data.consistencyLabel}
                  </span>
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Mini Weekly Trend Chart */}
          <Card className="bg-charcoal-900/50 border-white/5 shadow-lg rounded-xl">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-foreground">{t.weeklyMoodPattern}</h3>
                <Badge variant="outline" className="text-xs border-white/10 text-muted-foreground">
                  7 {t.daysRemaining.split(' ')[0]}
                </Badge>
              </div>
              <div className="h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.weeklyData}>
                    <XAxis 
                      dataKey="day" 
                      stroke="rgba(255,255,255,0.3)" 
                      tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 10 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis 
                      domain={[0, 10]} 
                      hide
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Line
                      type="monotone"
                      dataKey="mood"
                      stroke="url(#colorGradient)"
                      strokeWidth={2}
                      dot={{ fill: '#ec4899', strokeWidth: 0, r: 3 }}
                      activeDot={{ r: 5, fill: '#ec4899' }}
                      connectNulls={false}
                    />
                    <defs>
                      <linearGradient id="colorGradient" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#ec4899" />
                        <stop offset="100%" stopColor="#f97316" />
                      </linearGradient>
                    </defs>
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Highlight Days */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Highest Mood Day */}
            <Card className="bg-gradient-to-br from-green-500/5 to-emerald-500/5 border-green-500/10 shadow-lg rounded-xl">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-green-500/10 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{t.trend}</p>
                    <p className="text-lg font-semibold text-foreground">
                      {data.highestMoodDay || t.noData}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Lowest Mood Day */}
            <Card className="bg-gradient-to-br from-red-500/5 to-rose-500/5 border-red-500/10 shadow-lg rounded-xl">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-red-500/10 flex items-center justify-center">
                    <TrendingDown className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{t.trend}</p>
                    <p className="text-lg font-semibold text-foreground">
                      {data.lowestMoodDay || t.noData}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Insight Box - Premium */}
          <Card className="bg-gradient-to-r from-pink-500/5 via-purple-500/5 to-amber-500/5 border-pink-500/10 shadow-lg rounded-xl">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-base font-semibold text-foreground">{t.aiInterpretation}</h3>
                    <Badge className="bg-pink-500/20 text-pink-400 border-pink-500/30 text-[10px]">{t.premium}</Badge>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {data.insight}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Entry Stats & Last Updated */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{t.thisWeek}: {data.totalEntriesThisWeek} {t.moodEntries}</span>
              </div>
              <span className="text-white/20">|</span>
              <span>{t.lastWeek}: {data.totalEntriesLastWeek} {t.moodEntries}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>{t.lastUpdated}: {lastUpdated}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-3">
            <Link href="/premium/mind-journal-pro">
              <Button variant="outline" className="border-white/10 text-foreground hover:bg-white/5">
                <BookOpen className="w-4 h-4 mr-2" />
                {t.newEntry}
              </Button>
            </Link>
            <Link href="/premium/analytics/mood">
              <Button variant="outline" className="border-white/10 text-muted-foreground hover:text-foreground hover:bg-white/5">
                <BarChart3 className="w-4 h-4 mr-2" />
                {t.moodAnalytics}
              </Button>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
