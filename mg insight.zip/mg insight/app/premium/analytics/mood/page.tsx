'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  BarChart3,
  TrendingUp,
  Calendar,
  Smile,
  Frown,
  Meh,
  Loader2,
  RefreshCw,
  BookOpen,
  Target,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import Link from 'next/link';

// Types for analytics data
interface WeeklyData {
  day: string;
  date: string;
  mood: number;
  entries: number;
}

interface AnalyticsData {
  success: boolean;
  weeklyData: WeeklyData[];
  stats: {
    totalEntries: number;
    avgMoodScore: number;
    hasData: boolean;
  };
}

export default function MoodAnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await fetch('/api/analytics/mood');

      if (!res.ok) {
        throw new Error('Failed to fetch analytics');
      }

      const result = await res.json();
      setData(result);
    } catch (err) {
      console.error('Failed to fetch mood analytics:', err);
      setError('Failed to load analytics. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Get mood emoji based on score
  const getMoodEmoji = (score: number) => {
    if (score >= 8) return <Smile className="w-6 h-6 text-green-400" />;
    if (score >= 5) return <Meh className="w-6 h-6 text-yellow-400" />;
    return <Frown className="w-6 h-6 text-red-400" />;
  };

  // Get mood label based on score
  const getMoodLabel = (score: number) => {
    if (score >= 8) return 'Great';
    if (score >= 6) return 'Good';
    if (score >= 4) return 'Okay';
    if (score >= 2) return 'Low';
    return 'No Data';
  };

  // Custom tooltip for chart
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-charcoal-900 border border-gold-500/30 rounded-lg p-3 shadow-lg">
          <p className="font-semibold text-foreground">{label}</p>
          <p className="text-sm text-amber-400">
            Mood Score: <span className="font-bold">{data.mood}/10</span>
          </p>
          <p className="text-xs text-muted-foreground">
            {data.entries} {data.entries === 1 ? 'entry' : 'entries'}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-6 h-6 text-pink-400" />
            <Badge className="bg-pink-500/20 text-pink-400">Premium Analytics</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Mood Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Track your emotional patterns and mood trends over the past 7 days.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={fetchData}
          disabled={loading}
          className="border-gold-500/30 text-gold-400 hover:bg-gold-500/10"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <Card className="bg-red-500/10 border-red-500/20">
          <CardContent className="p-6 text-center">
            <Frown className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <p className="text-red-400">{error}</p>
            <Button
              variant="outline"
              onClick={fetchData}
              className="mt-4 border-red-500/30 text-red-400 hover:bg-red-500/10"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Data Display */}
      {data && !loading && !error && (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardContent className="p-6 text-center">
                <BookOpen className="w-10 h-10 text-blue-400 mx-auto mb-3" />
                <p className="text-3xl font-bold text-foreground">{data.stats.totalEntries}</p>
                <p className="text-sm text-muted-foreground">Total Entries (7 Days)</p>
              </CardContent>
            </Card>

            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardContent className="p-6 text-center">
                {getMoodEmoji(data.stats.avgMoodScore)}
                <p className="text-3xl font-bold text-foreground mt-2">
                  {data.stats.avgMoodScore > 0 ? data.stats.avgMoodScore : '-'}
                </p>
                <p className="text-sm text-muted-foreground">
                  Average Mood {data.stats.avgMoodScore > 0 && `(${getMoodLabel(data.stats.avgMoodScore)})`}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardContent className="p-6 text-center">
                <TrendingUp className="w-10 h-10 text-green-400 mx-auto mb-3" />
                <p className="text-3xl font-bold text-foreground">
                  {data.stats.avgMoodScore > 0 ? getMoodLabel(data.stats.avgMoodScore) : 'No Data'}
                </p>
                <p className="text-sm text-muted-foreground">Overall Trend</p>
              </CardContent>
            </Card>
          </div>

          {/* No Data State */}
          {!data.stats.hasData && (
            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardContent className="p-8 text-center">
                <Calendar className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Belum ada data mood minggu ini
                </h3>
                <p className="text-muted-foreground mb-6">
                  Start journaling to track your mood and see your emotional patterns.
                </p>
                <Link href="/premium/mind-journal-pro">
                  <Button className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Start Journaling
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}

          {/* Mood Chart */}
          {data.stats.hasData && (
            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardHeader>
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-pink-400" />
                  Weekly Mood Trend
                </CardTitle>
                <CardDescription>
                  Your mood scores over the past 7 days (1-10 scale)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 sm:h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data.weeklyData}>
                      <defs>
                        <linearGradient id="moodGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ec4899" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#ec4899" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis
                        dataKey="day"
                        stroke="rgba(255,255,255,0.5)"
                        tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
                      />
                      <YAxis
                        domain={[0, 10]}
                        stroke="rgba(255,255,255,0.5)"
                        tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
                        ticks={[0, 2, 4, 6, 8, 10]}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Area
                        type="monotone"
                        dataKey="mood"
                        stroke="#ec4899"
                        strokeWidth={3}
                        fill="url(#moodGradient)"
                        dot={{ fill: '#ec4899', strokeWidth: 2, r: 4 }}
                        activeDot={{ r: 6, fill: '#ec4899' }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Daily Breakdown */}
          {data.stats.hasData && (
            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardHeader>
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-400" />
                  Daily Breakdown
                </CardTitle>
                <CardDescription>
                  Detailed view of your mood scores for each day
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.weeklyData.map((day) => (
                    <div
                      key={day.date}
                      className="flex items-center justify-between p-3 rounded-lg bg-charcoal-800/50 border border-gold-500/10"
                    >
                      <div className="flex items-center gap-3">
                        {getMoodEmoji(day.mood)}
                        <div>
                          <p className="font-medium text-foreground">{day.day}</p>
                          <p className="text-xs text-muted-foreground">
                            {day.entries} {day.entries === 1 ? 'entry' : 'entries'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge
                          className={
                            day.mood >= 7
                              ? 'bg-green-500/20 text-green-400'
                              : day.mood >= 4
                              ? 'bg-yellow-500/20 text-yellow-400'
                              : day.mood > 0
                              ? 'bg-red-500/20 text-red-400'
                              : 'bg-gray-500/20 text-gray-400'
                          }
                        >
                          {day.mood > 0 ? `${day.mood}/10` : 'No Data'}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          {getMoodLabel(day.mood)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex flex-wrap gap-3">
            <Link href="/premium/mind-journal-pro">
              <Button variant="outline" className="border-gold-500/30 text-gold-400 hover:bg-gold-500/10">
                <BookOpen className="w-4 h-4 mr-2" />
                New Journal Entry
              </Button>
            </Link>
            <Link href="/premium/analytics">
              <Button variant="outline" className="border-gold-500/30 text-muted-foreground hover:text-foreground">
                <Target className="w-4 h-4 mr-2" />
                Full Analytics
              </Button>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
