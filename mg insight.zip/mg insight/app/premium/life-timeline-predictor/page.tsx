'use client';

import { useState, useCallback, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Timeline,
  TimelineItem,
  TimelineConnector,
  TimelineHeader,
  TimelineTitle,
  TimelineDescription,
} from '@/components/ui/timeline';
import {
  TrendingUp,
  TrendingDown,
  Target,
  Brain,
  Sparkles,
  Save,
  RotateCcw,
  Play,
  ChevronRight,
  AlertCircle,
  CheckCircle2,
  Clock,
  Calendar,
  Zap,
  Heart,
  DollarSign,
  Briefcase,
  GraduationCap,
  Rocket,
  AlertTriangle,
  Star,
  Crown,
  Lightbulb,
  Activity,
  Users,
  MapPin,
  Building,
  User,
  RefreshCw,
  Download,
  Share2,
} from 'lucide-react';

// ============================================
// TYPES
// ============================================

type CareerStage = 'entry' | 'junior' | 'mid' | 'senior' | 'lead' | 'executive';
type IncomeLevel = 'low' | 'lower-middle' | 'middle' | 'upper-middle' | 'high' | 'wealthy';
type EducationLevel = 'high-school' | 'some-college' | 'bachelors' | 'masters' | 'doctorate';
type SkillLevel = 'beginner' | 'intermediate' | 'advanced' | 'expert' | 'master';
type FinancialStability = 'unstable' | 'somewhat' | 'stable' | 'very-stable' | 'excellent';
type RiskTolerance = 'conservative' | 'moderate' | 'aggressive';
type HealthStatus = 'poor' | 'fair' | 'good' | 'very-good' | 'excellent';
type RelationshipStatus = 'single' | 'dating' | 'committed' | 'married' | 'divorced';
type LearningHabit = 'minimal' | 'occasional' | 'regular' | 'intensive';

interface LifeVariables {
  age: number;
  careerStage: CareerStage;
  incomeLevel: IncomeLevel;
  educationLevel: EducationLevel;
  skillLevel: SkillLevel;
  financialStability: FinancialStability;
  riskTolerance: RiskTolerance;
  healthStatus: HealthStatus;
  // Optional
  relationshipStatus?: RelationshipStatus;
  location?: string;
  industry?: string;
  entrepreneurshipInterest: boolean;
  learningHabit: LearningHabit;
}

interface LifeVector {
  skillGrowthRate: number;
  financialGrowthRate: number;
  careerMomentum: number;
  decisionRiskPattern: number;
  timeHorizonMultiplier: number;
  overallPotential: number;
}

interface TimelineEvent {
  id: string;
  age: number;
  year: number;
  label: string;
  probability: number;
  type: 'opportunity' | 'growth' | 'risk' | 'neutral';
  category: 'career' | 'financial' | 'personal' | 'growth';
  explanation: string;
  phase: 'near' | 'mid' | 'long';
}

interface TimelinePhase {
  name: string;
  range: string;
  years: number;
  events: TimelineEvent[];
  opportunityScore: number;
  riskScore: number;
  growthScore: number;
}

interface TimelinePrediction {
  id: string;
  variables: LifeVariables;
  vector: LifeVector;
  phases: TimelinePhase[];
  events: TimelineEvent[];
  strategicInsight: string;
  highOpportunityWindows: string[];
  highRiskPeriods: string[];
  createdAt: Date;
}

// ============================================
// CONFIGURATION
// ============================================

const careerStageConfig: Record<CareerStage, { value: number; label: string }> = {
  'entry': { value: 1, label: 'Entry Level' },
  'junior': { value: 2, label: 'Junior' },
  'mid': { value: 3, label: 'Mid-Level' },
  'senior': { value: 4, label: 'Senior' },
  'lead': { value: 5, label: 'Lead/Manager' },
  'executive': { value: 6, label: 'Executive' },
};

const incomeLevelConfig: Record<IncomeLevel, { value: number; label: string }> = {
  'low': { value: 1, label: 'Low Income' },
  'lower-middle': { value: 2, label: 'Lower Middle' },
  'middle': { value: 3, label: 'Middle Class' },
  'upper-middle': { value: 4, label: 'Upper Middle' },
  'high': { value: 5, label: 'High Income' },
  'wealthy': { value: 6, label: 'Wealthy' },
};

const educationLevelConfig: Record<EducationLevel, { value: number; label: string }> = {
  'high-school': { value: 1, label: 'High School' },
  'some-college': { value: 2, label: 'Some College' },
  'bachelors': { value: 3, label: "Bachelor's Degree" },
  'masters': { value: 4, label: "Master's Degree" },
  'doctorate': { value: 5, label: 'Doctorate' },
};

const skillLevelConfig: Record<SkillLevel, { value: number; label: string }> = {
  'beginner': { value: 1, label: 'Beginner' },
  'intermediate': { value: 2, label: 'Intermediate' },
  'advanced': { value: 3, label: 'Advanced' },
  'expert': { value: 4, label: 'Expert' },
  'master': { value: 5, label: 'Master' },
};

const financialStabilityConfig: Record<FinancialStability, { value: number; label: string }> = {
  'unstable': { value: 1, label: 'Unstable' },
  'somewhat': { value: 2, label: 'Somewhat Stable' },
  'stable': { value: 3, label: 'Stable' },
  'very-stable': { value: 4, label: 'Very Stable' },
  'excellent': { value: 5, label: 'Excellent' },
};

const riskToleranceConfig: Record<RiskTolerance, { value: number; label: string; multiplier: number }> = {
  'conservative': { value: 1, label: 'Conservative', multiplier: 0.8 },
  'moderate': { value: 2, label: 'Moderate', multiplier: 1.0 },
  'aggressive': { value: 3, label: 'Aggressive', multiplier: 1.3 },
};

const healthStatusConfig: Record<HealthStatus, { value: number; label: string }> = {
  'poor': { value: 1, label: 'Poor' },
  'fair': { value: 2, label: 'Fair' },
  'good': { value: 3, label: 'Good' },
  'very-good': { value: 4, label: 'Very Good' },
  'excellent': { value: 5, label: 'Excellent' },
};

const learningHabitConfig: Record<LearningHabit, { value: number; label: string }> = {
  'minimal': { value: 1, label: 'Minimal' },
  'occasional': { value: 2, label: 'Occasional' },
  'regular': { value: 3, label: 'Regular' },
  'intensive': { value: 4, label: 'Intensive' },
};

// ============================================
// LIFE VECTOR MODELING ENGINE
// ============================================

function calculateLifeVector(variables: LifeVariables): LifeVector {
  // Normalize all inputs to 0-1 scale
  const careerScore = careerStageConfig[variables.careerStage].value / 6;
  const incomeScore = incomeLevelConfig[variables.incomeLevel].value / 6;
  const educationScore = educationLevelConfig[variables.educationLevel].value / 5;
  const skillScore = skillLevelConfig[variables.skillLevel].value / 5;
  const financialScore = financialStabilityConfig[variables.financialStability].value / 5;
  const healthScore = healthStatusConfig[variables.healthStatus].value / 5;
  const learningScore = learningHabitConfig[variables.learningHabit].value / 4;
  const riskMultiplier = riskToleranceConfig[variables.riskTolerance].multiplier;
  
  // Age factor (optimal growth years 25-40)
  const ageFactor = variables.age < 25 ? 0.8 + (variables.age / 25) * 0.2 :
                    variables.age < 40 ? 1.0 :
                    variables.age < 50 ? 0.9 :
                    0.8;
  
  // Calculate growth rates
  const skillGrowthRate = (skillScore * 0.3 + learningScore * 0.4 + educationScore * 0.2 + healthScore * 0.1) * ageFactor;
  const financialGrowthRate = (incomeScore * 0.3 + financialScore * 0.3 + careerScore * 0.25 + skillScore * 0.15) * riskMultiplier;
  const careerMomentum = (careerScore * 0.35 + skillScore * 0.25 + educationScore * 0.2 + variables.entrepreneurshipInterest ? 0.15 : 0.1 + learningScore * 0.1);
  const decisionRiskPattern = (riskMultiplier - 1) * 0.5 + (1 - financialScore) * 0.3 + (1 - healthScore) * 0.2;
  const timeHorizonMultiplier = Math.max(0.5, 1 - (variables.age / 80));
  
  const overallPotential = (skillGrowthRate + financialGrowthRate + careerMomentum) / 3;
  
  return {
    skillGrowthRate: Math.round(skillGrowthRate * 100),
    financialGrowthRate: Math.round(financialGrowthRate * 100),
    careerMomentum: Math.round(careerMomentum * 100),
    decisionRiskPattern: Math.round(decisionRiskPattern * 100),
    timeHorizonMultiplier: Math.round(timeHorizonMultiplier * 100),
    overallPotential: Math.round(overallPotential * 100),
  };
}

// ============================================
// TIMELINE FORECAST ENGINE
// ============================================

function generateTimelinePrediction(variables: LifeVariables, vector: LifeVector): TimelinePrediction {
  const currentYear = new Date().getFullYear();
  const events: TimelineEvent[] = [];
  
  // Event templates with probability modifiers
  const eventTemplates = [
    // Career Events
    { type: 'opportunity', category: 'career', baseLabel: 'Skill Expansion Phase', baseProbability: 0.7, ageOffset: 2 },
    { type: 'opportunity', category: 'career', baseLabel: 'Career Breakthrough Window', baseProbability: 0.5, ageOffset: 4 },
    { type: 'growth', category: 'career', baseLabel: 'Leadership Opportunity', baseProbability: 0.45, ageOffset: 6 },
    { type: 'risk', category: 'career', baseLabel: 'Career Plateau Risk', baseProbability: 0.3, ageOffset: 8 },
    { type: 'opportunity', category: 'career', baseLabel: 'Industry Pivot Window', baseProbability: 0.4, ageOffset: 10 },
    { type: 'growth', category: 'career', baseLabel: 'Executive Potential Phase', baseProbability: 0.35, ageOffset: 12 },
    
    // Financial Events
    { type: 'growth', category: 'financial', baseLabel: 'Income Acceleration Phase', baseProbability: 0.6, ageOffset: 3 },
    { type: 'opportunity', category: 'financial', baseLabel: 'Investment Window', baseProbability: 0.55, ageOffset: 5 },
    { type: 'growth', category: 'financial', baseLabel: 'Wealth Building Phase', baseProbability: 0.5, ageOffset: 7 },
    { type: 'opportunity', category: 'financial', baseLabel: 'Financial Independence Milestone', baseProbability: 0.35, ageOffset: 15 },
    
    // Personal Events
    { type: 'growth', category: 'personal', baseLabel: 'Major Life Decision Window', baseProbability: 0.4, ageOffset: 2 },
    { type: 'risk', category: 'personal', baseLabel: 'Burnout Risk Period', baseProbability: 0.25, ageOffset: 5 },
    { type: 'opportunity', category: 'personal', baseLabel: 'Life Satisfaction Peak', baseProbability: 0.5, ageOffset: 8 },
    { type: 'growth', category: 'personal', baseLabel: 'Wisdom Accumulation Phase', baseProbability: 0.6, ageOffset: 12 },
    
    // Growth Events
    { type: 'opportunity', category: 'growth', baseLabel: 'Network Expansion Phase', baseProbability: 0.65, ageOffset: 1 },
    { type: 'growth', category: 'growth', baseLabel: 'Skill Mastery Milestone', baseProbability: 0.5, ageOffset: 4 },
    { type: 'opportunity', category: 'growth', baseLabel: 'Innovation Opportunity', baseProbability: 0.4, ageOffset: 6 },
    { type: 'growth', category: 'growth', baseLabel: 'Legacy Building Phase', baseProbability: 0.45, ageOffset: 14 },
  ];
  
  // Entrepreneurship events (if interested)
  if (variables.entrepreneurshipInterest) {
    eventTemplates.push(
      { type: 'opportunity', category: 'career', baseLabel: 'Startup Window', baseProbability: 0.4, ageOffset: 3 },
      { type: 'growth', category: 'financial', baseLabel: 'Business Scaling Phase', baseProbability: 0.35, ageOffset: 7 },
      { type: 'risk', category: 'career', baseLabel: 'Entrepreneurship Risk Period', baseProbability: 0.45, ageOffset: 4 },
    );
  }
  
  // Generate events based on vector
  eventTemplates.forEach((template, index) => {
    const eventAge = variables.age + template.ageOffset;
    if (eventAge <= variables.age + 20) {
      // Modify probability based on vector
      let probability = template.baseProbability;
      
      if (template.type === 'opportunity') {
        probability *= (vector.overallPotential / 100);
      } else if (template.type === 'risk') {
        probability *= (vector.decisionRiskPattern / 100);
      } else if (template.type === 'growth') {
        probability *= (vector.skillGrowthRate / 100);
      }
      
      // Clamp probability
      probability = Math.max(0.1, Math.min(0.95, probability));
      
      // Determine phase
      const phase: 'near' | 'mid' | 'long' = 
        template.ageOffset <= 3 ? 'near' :
        template.ageOffset <= 10 ? 'mid' : 'long';
      
      // Generate explanation
      const explanation = generateEventExplanation(template, probability, vector);
      
      events.push({
        id: `event-${index}`,
        age: eventAge,
        year: currentYear + template.ageOffset,
        label: template.baseLabel,
        probability: Math.round(probability * 100),
        type: template.type as 'opportunity' | 'growth' | 'risk' | 'neutral',
        category: template.category as 'career' | 'financial' | 'personal' | 'growth',
        explanation,
        phase,
      });
    }
  });
  
  // Sort by age
  events.sort((a, b) => a.age - b.age);
  
  // Create phases
  const phases: TimelinePhase[] = [
    createPhase('Near Future', '1-3 years', events.filter(e => e.phase === 'near'), 'near'),
    createPhase('Mid Future', '4-10 years', events.filter(e => e.phase === 'mid'), 'mid'),
    createPhase('Long Future', '10-20 years', events.filter(e => e.phase === 'long'), 'long'),
  ];
  
  // Find high opportunity windows and risk periods
  const highOpportunityWindows = events
    .filter(e => e.type === 'opportunity' && e.probability >= 50)
    .map(e => `Age ${e.age}: ${e.label} (${e.probability}%)`);
  
  const highRiskPeriods = events
    .filter(e => e.type === 'risk' && e.probability >= 30)
    .map(e => `Age ${e.age}: ${e.label} (${e.probability}%)`);
  
  // Generate strategic insight
  const strategicInsight = generateStrategicInsight(variables, vector, events);
  
  return {
    id: `prediction-${Date.now()}`,
    variables,
    vector,
    phases,
    events,
    strategicInsight,
    highOpportunityWindows,
    highRiskPeriods,
    createdAt: new Date(),
  };
}

function createPhase(name: string, range: string, events: TimelineEvent[], phaseType: 'near' | 'mid' | 'long'): TimelinePhase {
  const opportunityScore = events.filter(e => e.type === 'opportunity').length > 0
    ? Math.round(events.filter(e => e.type === 'opportunity').reduce((sum, e) => sum + e.probability, 0) / events.filter(e => e.type === 'opportunity').length)
    : 0;
  
  const riskScore = events.filter(e => e.type === 'risk').length > 0
    ? Math.round(events.filter(e => e.type === 'risk').reduce((sum, e) => sum + e.probability, 0) / events.filter(e => e.type === 'risk').length)
    : 0;
  
  const growthScore = events.filter(e => e.type === 'growth').length > 0
    ? Math.round(events.filter(e => e.type === 'growth').reduce((sum, e) => sum + e.probability, 0) / events.filter(e => e.type === 'growth').length)
    : 0;
  
  return {
    name,
    range,
    years: phaseType === 'near' ? 3 : phaseType === 'mid' ? 7 : 10,
    events,
    opportunityScore,
    riskScore,
    growthScore,
  };
}

function generateEventExplanation(template: { type: string; category: string; baseLabel: string }, probability: number, vector: LifeVector): string {
  const explanations: Record<string, string[]> = {
    'Skill Expansion Phase': [
      'Your learning trajectory suggests accelerated skill development.',
      'Favorable conditions for acquiring new competencies.',
      'Optimal period for professional development investments.',
    ],
    'Career Breakthrough Window': [
      'Converging factors indicate a potential career advancement opportunity.',
      'Your experience level aligns with typical promotion cycles.',
      'Market conditions may favor career progression.',
    ],
    'Income Acceleration Phase': [
      'Financial growth indicators point to increased earning potential.',
      'Your skill accumulation may translate to income growth.',
      'Market value optimization window approaching.',
    ],
    'Burnout Risk Period': [
      'High activity patterns may lead to exhaustion.',
      'Consider work-life balance adjustments.',
      'Preventive self-care recommended during this phase.',
    ],
    'Entrepreneurship Risk Period': [
      'Business venture decisions carry significant risk.',
      'Market timing factors require careful evaluation.',
      'Resource allocation decisions critical.',
    ],
    'Financial Independence Milestone': [
      'Long-term wealth accumulation trajectory on track.',
      'Compound growth effects becoming significant.',
      'Passive income potential increasing.',
    ],
  };
  
  const defaultExplanation = `Probability influenced by your current trajectory and growth factors.`;
  const specificExplanations = explanations[template.baseLabel] || [defaultExplanation];
  
  return specificExplanations[Math.floor(Math.random() * specificExplanations.length)];
}

function generateStrategicInsight(variables: LifeVariables, vector: LifeVector, events: TimelineEvent[]): string {
  const insights: string[] = [];
  
  // Growth window analysis
  const growthEvents = events.filter(e => e.type === 'growth' || e.type === 'opportunity');
  if (growthEvents.length > 0) {
    const firstGrowth = growthEvents[0];
    insights.push(`Your model indicates a growth window beginning at age ${firstGrowth.age}, driven by ${vector.skillGrowthRate > 60 ? 'skill accumulation' : 'career momentum'}.`);
  }
  
  // Financial trajectory
  if (vector.financialGrowthRate > 60) {
    insights.push(`Financial acceleration is highly probable with your current trajectory.`);
  } else if (vector.financialGrowthRate > 40) {
    insights.push(`Financial growth is achievable with continued skill development and strategic career moves.`);
  }
  
  // Risk analysis
  const riskEvents = events.filter(e => e.type === 'risk');
  if (riskEvents.length > 0) {
    insights.push(`Key risk periods to monitor: ${riskEvents.slice(0, 2).map(e => `age ${e.age}`).join(', ')}.`);
  }
  
  // Entrepreneurship
  if (variables.entrepreneurshipInterest && vector.overallPotential > 50) {
    insights.push(`Your entrepreneurial potential is favorable. Consider timing business ventures with opportunity windows.`);
  }
  
  // Learning habit impact
  if (learningHabitConfig[variables.learningHabit].value >= 3) {
    insights.push(`Your intensive learning habits significantly enhance long-term trajectory potential.`);
  }
  
  return insights.join(' ') || 'Your timeline shows balanced growth potential across multiple life dimensions.';
}

// ============================================
// MAIN COMPONENT
// ============================================

export default function LifeTimelinePredictor() {
  // Form state
  const [formData, setFormData] = useState<LifeVariables>({
    age: 25,
    careerStage: 'mid',
    incomeLevel: 'middle',
    educationLevel: 'bachelors',
    skillLevel: 'intermediate',
    financialStability: 'stable',
    riskTolerance: 'moderate',
    healthStatus: 'good',
    relationshipStatus: 'single',
    location: '',
    industry: '',
    entrepreneurshipInterest: false,
    learningHabit: 'regular',
  });
  
  // Prediction state
  const [prediction, setPrediction] = useState<TimelinePrediction | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [savedPredictions, setSavedPredictions] = useState<TimelinePrediction[]>([]);
  const [activeTab, setActiveTab] = useState<'form' | 'results'>('form');
  
  // Update form data
  const updateFormData = useCallback(<K extends keyof LifeVariables>(key: K, value: LifeVariables[K]) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  }, []);
  
  // Generate prediction
  const generatePrediction = useCallback(() => {
    setIsCalculating(true);
    
    // Simulate processing delay
    setTimeout(() => {
      const vector = calculateLifeVector(formData);
      const result = generateTimelinePrediction(formData, vector);
      setPrediction(result);
      setIsCalculating(false);
      setActiveTab('results');
    }, 1500);
  }, [formData]);
  
  // Save prediction
  const savePrediction = useCallback(() => {
    if (prediction) {
      setSavedPredictions(prev => [prediction, ...prev]);
    }
  }, [prediction]);
  
  // Load saved prediction
  const loadPrediction = useCallback((saved: TimelinePrediction) => {
    setFormData(saved.variables);
    setPrediction(saved);
    setActiveTab('results');
  }, []);
  
  // Reset form
  const resetForm = useCallback(() => {
    setFormData({
      age: 25,
      careerStage: 'mid',
      incomeLevel: 'middle',
      educationLevel: 'bachelors',
      skillLevel: 'intermediate',
      financialStability: 'stable',
      riskTolerance: 'moderate',
      healthStatus: 'good',
      relationshipStatus: 'single',
      location: '',
      industry: '',
      entrepreneurshipInterest: false,
      learningHabit: 'regular',
    });
    setPrediction(null);
    setActiveTab('form');
  }, []);
  
  // Get event color
  const getEventColor = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'opportunity': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'growth': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'risk': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-zinc-500/20 text-zinc-400 border-zinc-500/30';
    }
  };
  
  const getCategoryIcon = (category: TimelineEvent['category']) => {
    switch (category) {
      case 'career': return Briefcase;
      case 'financial': return DollarSign;
      case 'personal': return Heart;
      case 'growth': return TrendingUp;
      default: return Target;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        <motion.div
          animate={{ opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 4, ease: 'easeInOut' }}
          className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ opacity: [0.2, 0.3, 0.2] }}
          transition={{ duration: 5, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10 p-4 lg:p-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-white">Life Timeline Predictor</h1>
                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              </div>
              <p className="text-sm text-zinc-400">
                Probabilistic life trajectory modeling & forecasting
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={resetForm}
              className="border-zinc-700 text-zinc-400 hover:text-white"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
            {prediction && (
              <Button
                variant="outline"
                onClick={() => setActiveTab(activeTab === 'form' ? 'results' : 'form')}
                className="border-zinc-700 text-zinc-400 hover:text-white"
              >
                {activeTab === 'form' ? 'View Results' : 'Edit Form'}
              </Button>
            )}
          </div>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2">
          <Button
            variant={activeTab === 'form' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('form')}
            className={activeTab === 'form' ? 'bg-emerald-600 text-white' : 'text-zinc-400'}
          >
            <User className="w-4 h-4 mr-2" />
            Life Variables
          </Button>
          <Button
            variant={activeTab === 'results' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('results')}
            disabled={!prediction}
            className={activeTab === 'results' ? 'bg-emerald-600 text-white' : 'text-zinc-400'}
          >
            <Activity className="w-4 h-4 mr-2" />
            Timeline Results
          </Button>
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'form' ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              {/* Required Fields */}
              <Card className="bg-zinc-900/50 border-zinc-800/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2 text-base">
                    <Target className="w-4 h-4 text-emerald-400" />
                    Required Variables
                  </CardTitle>
                  <CardDescription>
                    Enter your current life variables for accurate prediction
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Age */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Age</Label>
                      <Input
                        type="number"
                        value={formData.age}
                        onChange={(e) => updateFormData('age', parseInt(e.target.value) || 18)}
                        className="bg-zinc-800/50 border-zinc-700 text-white"
                      />
                    </div>

                    {/* Career Stage */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Career Stage</Label>
                      <Select value={formData.careerStage} onValueChange={(v) => updateFormData('careerStage', v as CareerStage)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(careerStageConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Income Level */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Income Level</Label>
                      <Select value={formData.incomeLevel} onValueChange={(v) => updateFormData('incomeLevel', v as IncomeLevel)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(incomeLevelConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Education Level */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Education Level</Label>
                      <Select value={formData.educationLevel} onValueChange={(v) => updateFormData('educationLevel', v as EducationLevel)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(educationLevelConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Skill Level */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Skill Level</Label>
                      <Select value={formData.skillLevel} onValueChange={(v) => updateFormData('skillLevel', v as SkillLevel)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(skillLevelConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Financial Stability */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Financial Stability</Label>
                      <Select value={formData.financialStability} onValueChange={(v) => updateFormData('financialStability', v as FinancialStability)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(financialStabilityConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Risk Tolerance */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Risk Tolerance</Label>
                      <Select value={formData.riskTolerance} onValueChange={(v) => updateFormData('riskTolerance', v as RiskTolerance)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(riskToleranceConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Health Status */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Health Status</Label>
                      <Select value={formData.healthStatus} onValueChange={(v) => updateFormData('healthStatus', v as HealthStatus)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(healthStatusConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Optional Fields */}
              <Card className="bg-zinc-900/50 border-zinc-800/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2 text-base">
                    <Lightbulb className="w-4 h-4 text-amber-400" />
                    Optional Variables
                  </CardTitle>
                  <CardDescription>
                    Additional details for more accurate predictions
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Relationship Status */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Relationship Status</Label>
                      <Select 
                        value={formData.relationshipStatus || ''} 
                        onValueChange={(v) => updateFormData('relationshipStatus', v as RelationshipStatus)}
                      >
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue placeholder="Select..." />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          <SelectItem value="single">Single</SelectItem>
                          <SelectItem value="dating">Dating</SelectItem>
                          <SelectItem value="committed">Committed</SelectItem>
                          <SelectItem value="married">Married</SelectItem>
                          <SelectItem value="divorced">Divorced</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Location */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Location</Label>
                      <Input
                        value={formData.location || ''}
                        onChange={(e) => updateFormData('location', e.target.value)}
                        placeholder="City/Country"
                        className="bg-zinc-800/50 border-zinc-700 text-white"
                      />
                    </div>

                    {/* Industry */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Industry</Label>
                      <Input
                        value={formData.industry || ''}
                        onChange={(e) => updateFormData('industry', e.target.value)}
                        placeholder="Your industry"
                        className="bg-zinc-800/50 border-zinc-700 text-white"
                      />
                    </div>

                    {/* Learning Habit */}
                    <div className="space-y-2">
                      <Label className="text-zinc-400">Learning Habit</Label>
                      <Select value={formData.learningHabit} onValueChange={(v) => updateFormData('learningHabit', v as LearningHabit)}>
                        <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-700">
                          {Object.entries(learningHabitConfig).map(([key, config]) => (
                            <SelectItem key={key} value={key}>{config.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Entrepreneurship Interest */}
                  <div className="flex items-center justify-between p-4 rounded-lg bg-zinc-800/50">
                    <div>
                      <Label className="text-white">Entrepreneurship Interest</Label>
                      <p className="text-xs text-zinc-500">Are you interested in starting a business?</p>
                    </div>
                    <Switch
                      checked={formData.entrepreneurshipInterest}
                      onCheckedChange={(checked) => updateFormData('entrepreneurshipInterest', checked)}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Generate Button */}
              <Button
                onClick={generatePrediction}
                disabled={isCalculating}
                className="w-full bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white h-12 text-lg"
              >
                {isCalculating ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    >
                      <RefreshCw className="w-5 h-5 mr-2" />
                    </motion.div>
                    Calculating Life Trajectory...
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 mr-2" />
                    Generate Timeline Prediction
                  </>
                )}
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="results"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {prediction && (
                <>
                  {/* Life Vector Summary */}
                  <Card className="bg-zinc-900/50 border-zinc-800/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <Brain className="w-4 h-4 text-cyan-400" />
                        Life Vector Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                        {[
                          { label: 'Skill Growth', value: prediction.vector.skillGrowthRate, color: 'text-green-400' },
                          { label: 'Financial Growth', value: prediction.vector.financialGrowthRate, color: 'text-amber-400' },
                          { label: 'Career Momentum', value: prediction.vector.careerMomentum, color: 'text-blue-400' },
                          { label: 'Risk Pattern', value: prediction.vector.decisionRiskPattern, color: 'text-red-400' },
                          { label: 'Overall Potential', value: prediction.vector.overallPotential, color: 'text-purple-400' },
                        ].map((stat) => (
                          <div key={stat.label} className="text-center">
                            <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}%</p>
                            <p className="text-xs text-zinc-500">{stat.label}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Timeline Phases */}
                  {prediction.phases.map((phase, phaseIndex) => (
                    <Card key={phase.name} className="bg-zinc-900/50 border-zinc-800/50">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-white flex items-center gap-2 text-base">
                              <Clock className="w-4 h-4 text-cyan-400" />
                              {phase.name}
                            </CardTitle>
                            <CardDescription>{phase.range}</CardDescription>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="flex items-center gap-1">
                              <div className="w-3 h-3 rounded-full bg-green-500" />
                              <span className="text-xs text-zinc-500">{phase.opportunityScore}%</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <div className="w-3 h-3 rounded-full bg-yellow-500" />
                              <span className="text-xs text-zinc-500">{phase.growthScore}%</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <div className="w-3 h-3 rounded-full bg-red-500" />
                              <span className="text-xs text-zinc-500">{phase.riskScore}%</span>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {phase.events.map((event, eventIndex) => {
                            const CategoryIcon = getCategoryIcon(event.category);
                            return (
                              <motion.div
                                key={event.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: eventIndex * 0.1 }}
                                className="flex items-start gap-4 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50 hover:border-zinc-600 transition-colors"
                              >
                                <div className="flex-shrink-0 w-12 text-center">
                                  <p className="text-lg font-bold text-white">{event.age}</p>
                                  <p className="text-xs text-zinc-500">Age</p>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 mb-1">
                                    <CategoryIcon className="w-4 h-4 text-zinc-400" />
                                    <p className="font-medium text-white truncate">{event.label}</p>
                                  </div>
                                  <p className="text-sm text-zinc-400 line-clamp-2">{event.explanation}</p>
                                </div>
                                <Badge className={`flex-shrink-0 ${getEventColor(event.type)}`}>
                                  {event.probability}%
                                </Badge>
                              </motion.div>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {/* Opportunity & Risk Indicators */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/5 border-green-500/20">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2 text-base">
                          <TrendingUp className="w-4 h-4 text-green-400" />
                          High Opportunity Windows
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {prediction.highOpportunityWindows.length > 0 ? (
                          <ul className="space-y-2">
                            {prediction.highOpportunityWindows.map((window, index) => (
                              <li key={index} className="flex items-center gap-2 text-sm text-zinc-300">
                                <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                                {window}
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-zinc-500">No high-opportunity windows detected in current trajectory.</p>
                        )}
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-red-500/10 to-rose-500/5 border-red-500/20">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2 text-base">
                          <AlertTriangle className="w-4 h-4 text-red-400" />
                          High Risk Periods
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {prediction.highRiskPeriods.length > 0 ? (
                          <ul className="space-y-2">
                            {prediction.highRiskPeriods.map((period, index) => (
                              <li key={index} className="flex items-center gap-2 text-sm text-zinc-300">
                                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                                {period}
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-sm text-zinc-500">No significant risk periods detected in current trajectory.</p>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  {/* Strategic AI Insight */}
                  <Card className="bg-gradient-to-br from-cyan-500/10 to-emerald-500/5 border-cyan-500/20">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-emerald-500 flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-white mb-2 flex items-center gap-2">
                            Strategic AI Insight
                            <Badge className="bg-cyan-500/20 text-cyan-400 text-[10px]">AI-Generated</Badge>
                          </h3>
                          <p className="text-zinc-300 leading-relaxed">{prediction.strategicInsight}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-3">
                    <Button
                      onClick={savePrediction}
                      className="bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Timeline
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setActiveTab('form')}
                      className="border-zinc-700 text-zinc-400 hover:text-white"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Modify Variables
                    </Button>
                  </div>

                  {/* Saved Predictions */}
                  {savedPredictions.length > 0 && (
                    <Card className="bg-zinc-900/50 border-zinc-800/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2 text-base">
                          <Save className="w-4 h-4 text-cyan-400" />
                          Saved Timelines
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {savedPredictions.map((saved, index) => (
                            <button
                              key={saved.id}
                              onClick={() => loadPrediction(saved)}
                              className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50 hover:border-cyan-500/30 text-left transition-all group"
                            >
                              <div className="flex items-center justify-between mb-1">
                                <p className="font-medium text-white group-hover:text-cyan-400 transition-colors">
                                  Timeline #{index + 1}
                                </p>
                                <span className="text-xs text-zinc-500">Age {saved.variables.age}</span>
                              </div>
                              <p className="text-xs text-zinc-500">
                                Potential: {saved.vector.overallPotential}%
                              </p>
                            </button>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
