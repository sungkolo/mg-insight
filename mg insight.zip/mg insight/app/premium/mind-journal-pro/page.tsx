'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  BookOpen,
  Plus,
  Sparkles,
  TrendingUp,
  Heart,
  Brain,
  Calendar,
  Clock,
  ChevronRight,
  Send,
  Trash2,
  Edit,
  Loader2,
  Search,
  AlertCircle,
  CheckCircle,
  Smile,
  Meh,
  Frown,
  Zap,
  Target,
  Coffee,
  Lightbulb,
  MessageSquare,
  Wand2,
} from 'lucide-react';

// Journal entry type
interface Journal {
  id: string;
  title: string;
  content: string;
  mood: string | null;
  tags: string | null;
  aiSummary: string | null;
  aiEmotion: string | null;
  aiAdvice: string | null;
  aiInsight: string | null;
  createdAt: string;
  updatedAt: string;
}

// Mood options with icons and colors
const moodOptions = [
  { value: 'happy', label: 'Happy', icon: Smile, color: 'text-green-400', bg: 'bg-green-500/20' },
  { value: 'productive', label: 'Productive', icon: Zap, color: 'text-amber-400', bg: 'bg-amber-500/20' },
  { value: 'grateful', label: 'Grateful', icon: Heart, color: 'text-pink-400', bg: 'bg-pink-500/20' },
  { value: 'thoughtful', label: 'Thoughtful', icon: Brain, color: 'text-purple-400', bg: 'bg-purple-500/20' },
  { value: 'neutral', label: 'Neutral', icon: Meh, color: 'text-gray-400', bg: 'bg-gray-500/20' },
  { value: 'anxious', label: 'Anxious', icon: AlertCircle, color: 'text-orange-400', bg: 'bg-orange-500/20' },
  { value: 'stressed', label: 'Stressed', icon: Target, color: 'text-red-400', bg: 'bg-red-500/20' },
  { value: 'sad', label: 'Sad', icon: Frown, color: 'text-blue-400', bg: 'bg-blue-500/20' },
  { value: 'calm', label: 'Calm', icon: Coffee, color: 'text-teal-400', bg: 'bg-teal-500/20' },
  { value: 'inspired', label: 'Inspired', icon: Sparkles, color: 'text-yellow-400', bg: 'bg-yellow-500/20' },
];

export default function MindJournalProPage() {
  const [journals, setJournals] = useState<Journal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState('neutral');
  const [moodScore, setMoodScore] = useState(5);
  const [showMoodPicker, setShowMoodPicker] = useState(false);

  // Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMood, setFilterMood] = useState<string | null>(null);

  // Edit/Delete state
  const [editingJournal, setEditingJournal] = useState<Journal | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<Journal | null>(null);
  const [viewJournal, setViewJournal] = useState<Journal | null>(null);

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    thisWeek: 0,
    topMood: 'neutral',
    streak: 0,
    aiInsightsGenerated: 0,
  });

  // Fetch journals
  const fetchJournals = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/journal');
      const data = await res.json();

      if (data.success) {
        setJournals(data.journals);
        calculateStats(data.journals);
      } else {
        setError(data.message || 'Failed to fetch journals');
      }
    } catch (err) {
      console.error('Failed to fetch journals:', err);
      setError('Failed to load journals. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Calculate stats
  const calculateStats = (journalList: Journal[]) => {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const thisWeekJournals = journalList.filter(
      (j) => new Date(j.createdAt) >= weekAgo
    );

    // Count moods
    const moodCounts: Record<string, number> = {};
    journalList.forEach((j) => {
      if (j.mood) {
        moodCounts[j.mood] = (moodCounts[j.mood] || 0) + 1;
      }
    });

    const topMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'neutral';

    // Calculate streak
    let streak = 0;
    const dates = new Set(
      journalList.map((j) => new Date(j.createdAt).toDateString())
    );
    let checkDate = new Date();
    while (dates.has(checkDate.toDateString())) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    }

    // Count AI insights generated
    const aiInsightsGenerated = journalList.filter(
      (j) => j.aiSummary || j.aiEmotion || j.aiAdvice
    ).length;

    setStats({
      total: journalList.length,
      thisWeek: thisWeekJournals.length,
      topMood,
      streak,
      aiInsightsGenerated,
    });
  };

  useEffect(() => {
    fetchJournals();
  }, [fetchJournals]);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError(null);
        setSuccess(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Calculate mood score from mood string
  const calculateMoodScore = (moodValue: string): number => {
    const moodScores: Record<string, number> = {
      happy: 10,
      grateful: 9,
      inspired: 9,
      productive: 8,
      calm: 7,
      thoughtful: 6,
      neutral: 5,
      anxious: 3,
      stressed: 3,
      sad: 2,
    };
    return moodScores[moodValue.toLowerCase()] ?? 5;
  };

  // Handle mood change
  const handleMoodChange = (moodValue: string) => {
    setMood(moodValue);
    setMoodScore(calculateMoodScore(moodValue));
  };

  // Handle form submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('SUBMIT TRIGGERED');

    if (!title.trim() || !content.trim()) {
      setError('Please fill in both title and content');
      return;
    }

    try {
      setIsSaving(true);
      setError(null);
      console.log('Sending request with:', { title, content, mood });

      const res = await fetch('/api/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          title: title.trim(), 
          content: content.trim(), 
          mood,
        }),
      });

      const data = await res.json();
      console.log('Response:', data);

      if (data.success) {
        setSuccess('Journal entry saved successfully!');
        setTitle('');
        setContent('');
        setMood('neutral');
        setMoodScore(5);
        fetchJournals();
      } else {
        setError(data.message || 'Failed to save journal');
      }
    } catch (err) {
      console.error('Failed to save journal:', err);
      setError('Failed to save journal. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Generate AI insights
  const handleGenerateAIInsight = async (journalId: string) => {
    try {
      setIsGeneratingAI(journalId);
      setError(null);

      const res = await fetch('/api/journal/insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ journalId }),
      });

      const data = await res.json();

      if (data.success) {
        setSuccess('AI insights generated successfully!');
        fetchJournals();
        
        // Update view journal if currently viewing
        if (viewJournal?.id === journalId) {
          setViewJournal((prev) => prev ? {
            ...prev,
            aiSummary: data.insights.summary,
            aiEmotion: data.insights.emotion,
            aiAdvice: data.insights.advice,
          } : null);
        }
      } else {
        setError(data.message || 'Failed to generate AI insights');
      }
    } catch (err) {
      console.error('Failed to generate AI insights:', err);
      setError('Failed to generate AI insights. Please try again.');
    } finally {
      setIsGeneratingAI(null);
    }
  };

  // Update journal
  const handleUpdate = async () => {
    if (!editingJournal) return;

    try {
      setIsSaving(true);
      const res = await fetch(`/api/journal/${editingJournal.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editingJournal.title,
          content: editingJournal.content,
          mood: editingJournal.mood,
        }),
      });

      const data = await res.json();

      if (data.success) {
        setSuccess('Journal updated successfully!');
        setEditingJournal(null);
        fetchJournals();
      } else {
        setError(data.message || 'Failed to update journal');
      }
    } catch (err) {
      console.error('Failed to update journal:', err);
      setError('Failed to update journal. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete journal
  const handleDelete = async () => {
    if (!deleteConfirm) return;

    try {
      setIsSaving(true);
      const res = await fetch(`/api/journal/${deleteConfirm.id}`, {
        method: 'DELETE',
      });

      const data = await res.json();

      if (data.success) {
        setSuccess('Journal deleted successfully!');
        setDeleteConfirm(null);
        fetchJournals();
      } else {
        setError(data.message || 'Failed to delete journal');
      }
    } catch (err) {
      console.error('Failed to delete journal:', err);
      setError('Failed to delete journal. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Get mood info
  const getMoodInfo = (moodValue: string | null) => {
    return moodOptions.find((m) => m.value === moodValue) || moodOptions[4];
  };

  // Filter journals
  const filteredJournals = journals.filter((j) => {
    const matchesSearch =
      j.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      j.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMood = !filterMood || j.mood === filterMood;
    return matchesSearch && matchesMood;
  });

  // Format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-6 h-6 text-amber-400" />
            <Badge className="bg-green-500/20 text-green-400">Free Access</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Mind Journal</h1>
          <p className="text-muted-foreground mt-1">
            Your personal journal space. Write, reflect, and grow with AI-powered insights.
          </p>
        </div>
        <Button
          onClick={() => {
            setTitle('');
            setContent('');
            setMood('neutral');
            document.getElementById('journal-input')?.focus();
          }}
          className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Entry
        </Button>
      </div>

      {/* Status Messages */}
      {error && (
        <div className="flex items-center gap-2 p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
          <AlertCircle className="w-5 h-5" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="flex items-center gap-2 p-4 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400">
          <CheckCircle className="w-5 h-5" />
          <span>{success}</span>
        </div>
      )}

      {/* Stats Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <Card className="bg-charcoal-900/50 border-gold-500/10">
          <CardContent className="p-4 text-center">
            <BookOpen className="w-8 h-8 text-amber-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total Entries</p>
          </CardContent>
        </Card>
        <Card className="bg-charcoal-900/50 border-gold-500/10">
          <CardContent className="p-4 text-center">
            <Calendar className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{stats.thisWeek}</p>
            <p className="text-xs text-muted-foreground">This Week</p>
          </CardContent>
        </Card>
        <Card className="bg-charcoal-900/50 border-gold-500/10">
          <CardContent className="p-4 text-center">
            {(() => {
              const topMoodInfo = getMoodInfo(stats.topMood);
              const TopIcon = topMoodInfo.icon;
              return (
                <>
                  <TopIcon className={`w-8 h-8 ${topMoodInfo.color} mx-auto mb-2`} />
                  <p className="text-2xl font-bold text-foreground capitalize">{stats.topMood}</p>
                  <p className="text-xs text-muted-foreground">Top Mood</p>
                </>
              );
            })()}
          </CardContent>
        </Card>
        <Card className="bg-charcoal-900/50 border-gold-500/10">
          <CardContent className="p-4 text-center">
            <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{stats.streak}</p>
            <p className="text-xs text-muted-foreground">Day Streak</p>
          </CardContent>
        </Card>
        <Card className="bg-charcoal-900/50 border-gold-500/10">
          <CardContent className="p-4 text-center">
            <Sparkles className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{stats.aiInsightsGenerated}</p>
            <p className="text-xs text-muted-foreground">AI Insights</p>
          </CardContent>
        </Card>
      </div>

      {/* New Entry Form */}
      <Card className="bg-charcoal-900/50 border-gold-500/10">
        <CardHeader>
          <CardTitle className="text-lg text-foreground flex items-center gap-2">
            <Edit className="w-5 h-5 text-amber-400" />
            Write New Entry
          </CardTitle>
          <CardDescription>
            Express your thoughts freely. All entries are saved to your personal journal.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <Input
              id="journal-input"
              placeholder="Entry title..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-charcoal-900/50 border-gold-500/20 focus:border-gold-500/50"
            />
            <Textarea
              placeholder="What's on your mind today? How are you feeling about your goals, challenges, or progress?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-32 bg-charcoal-900/50 border-gold-500/20 focus:border-gold-500/50 resize-none"
            />
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">How are you feeling?</label>
              <div className="flex flex-wrap gap-2">
                {moodOptions.slice(0, 6).map((m) => {
                  const Icon = m.icon;
                  const isSelected = mood === m.value;
                  return (
                    <button
                      key={m.value}
                      type="button"
                      onClick={() => handleMoodChange(m.value)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm transition-all ${
                        isSelected
                          ? `${m.bg} ${m.color} ring-1 ring-current`
                          : 'bg-charcoal-800 text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {m.label}
                    </button>
                  );
                })}
                <button
                  type="button"
                  onClick={() => setShowMoodPicker(!showMoodPicker)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm bg-charcoal-800 text-muted-foreground hover:text-foreground"
                >
                  <ChevronRight className="w-4 h-4" />
                  More
                </button>
              </div>
              {showMoodPicker && (
                <div className="flex flex-wrap gap-2 pt-2 border-t border-gold-500/10">
                  {moodOptions.slice(6).map((m) => {
                    const Icon = m.icon;
                    const isSelected = mood === m.value;
                    return (
                      <button
                        key={m.value}
                        type="button"
                        onClick={() => {
                          handleMoodChange(m.value);
                          setShowMoodPicker(false);
                        }}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm transition-all ${
                          isSelected
                            ? `${m.bg} ${m.color} ring-1 ring-current`
                            : 'bg-charcoal-800 text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        {m.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
            {/* Mood Score Display */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>Mood Score:</span>
              <Badge className={`${moodScore >= 7 ? 'bg-green-500/20 text-green-400' : moodScore >= 4 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'}`}>
                {moodScore}/10
              </Badge>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Badge variant="outline" className="border-gold-500/30 text-muted-foreground">
              <Calendar className="w-3 h-3 mr-1" />
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
            </Badge>
            <Button
              type="submit"
              disabled={isSaving || !title.trim() || !content.trim()}
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Save Entry
                </>
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search journals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-charcoal-900/50 border-gold-500/20 focus:border-gold-500/50"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={filterMood === null ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilterMood(null)}
            className={filterMood === null ? 'bg-gold-500/20 text-gold-400' : 'border-gold-500/30'}
          >
            All
          </Button>
          {moodOptions.slice(0, 4).map((m) => (
            <Button
              key={m.value}
              variant={filterMood === m.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterMood(m.value)}
              className={filterMood === m.value ? `${m.bg} ${m.color}` : 'border-gold-500/30'}
            >
              <m.icon className="w-4 h-4" />
            </Button>
          ))}
        </div>
      </div>

      {/* Journal Entries */}
      <section>
        <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-gold-400" />
          Your Entries
          <Badge variant="outline" className="ml-auto border-gold-500/30 text-muted-foreground">
            {filteredJournals.length} {filteredJournals.length === 1 ? 'entry' : 'entries'}
          </Badge>
        </h2>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-gold-400" />
          </div>
        ) : filteredJournals.length === 0 ? (
          <Card className="bg-charcoal-900/50 border-gold-500/10">
            <CardContent className="py-12 text-center">
              <BookOpen className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-muted-foreground">
                {searchQuery || filterMood
                  ? 'No journals match your search'
                  : 'No journal entries yet. Start writing your first entry above!'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredJournals.map((journal) => {
              const moodInfo = getMoodInfo(journal.mood);
              const MoodIcon = moodInfo.icon;
              const hasAIInsights = journal.aiSummary || journal.aiEmotion || journal.aiAdvice;
              const isGenerating = isGeneratingAI === journal.id;

              return (
                <Card
                  key={journal.id}
                  className="bg-charcoal-900/50 border-gold-500/10 hover:border-gold-500/30 transition-colors group"
                >
                  <CardContent className="p-4">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`p-1.5 rounded-lg ${moodInfo.bg}`}>
                          <MoodIcon className={`w-4 h-4 ${moodInfo.color}`} />
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground group-hover:text-gold-400 transition-colors">
                            {journal.title}
                          </h3>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(journal.createdAt)} • {moodInfo.label}
                            {hasAIInsights && (
                              <Badge className="ml-2 bg-purple-500/20 text-purple-400 text-[10px]">
                                <Sparkles className="w-2.5 h-2.5 mr-1" />
                                AI
                              </Badge>
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-gold-400"
                          onClick={() => setViewJournal(journal)}
                        >
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-gold-400"
                          onClick={() => setEditingJournal(journal)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-red-400"
                          onClick={() => setDeleteConfirm(journal)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Content */}
                    <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
                      {journal.content}
                    </p>

                    {/* AI Insights Preview */}
                    {hasAIInsights && (
                      <div className="space-y-2 mb-3">
                        {journal.aiSummary && (
                          <div className="flex items-start gap-2 p-2.5 rounded-lg bg-purple-500/10 border border-purple-500/20">
                            <MessageSquare className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                            <p className="text-sm text-purple-300 line-clamp-2">{journal.aiSummary}</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Generate AI Button */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
                        disabled={isGenerating}
                        onClick={() => handleGenerateAIInsight(journal.id)}
                      >
                        {isGenerating ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Generating...
                          </>
                        ) : hasAIInsights ? (
                          <>
                            <Wand2 className="w-4 h-4 mr-2" />
                            Regenerate AI Insights
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Generate AI Insights
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </section>

      {/* View Journal Dialog */}
      <Dialog open={!!viewJournal} onOpenChange={() => setViewJournal(null)}>
        <DialogContent className="bg-charcoal-900 border-gold-500/20 max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-foreground flex items-center gap-2">
              {viewJournal?.title}
            </DialogTitle>
            <DialogDescription className="flex items-center gap-2">
              {viewJournal && (
                <>
                  <span className={`px-2 py-0.5 rounded text-xs ${getMoodInfo(viewJournal.mood).bg} ${getMoodInfo(viewJournal.mood).color}`}>
                    {getMoodInfo(viewJournal.mood).label}
                  </span>
                  <span>•</span>
                  <span>{formatDate(viewJournal.createdAt)}</span>
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          {viewJournal && (
            <div className="space-y-4">
              {/* Content */}
              <p className="text-foreground whitespace-pre-wrap">{viewJournal.content}</p>

              {/* AI Insights */}
              {(viewJournal.aiSummary || viewJournal.aiEmotion || viewJournal.aiAdvice) && (
                <div className="space-y-3 pt-4 border-t border-gold-500/10">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      AI Insights
                    </h4>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs text-purple-400 hover:text-purple-300"
                      onClick={() => handleGenerateAIInsight(viewJournal.id)}
                      disabled={isGeneratingAI === viewJournal.id}
                    >
                      {isGeneratingAI === viewJournal.id ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <Wand2 className="w-3 h-3 mr-1" />
                      )}
                      Regenerate
                    </Button>
                  </div>

                  {viewJournal.aiSummary && (
                    <div className="p-3 rounded-lg bg-charcoal-800/50 border border-gold-500/10">
                      <div className="flex items-center gap-2 mb-1">
                        <MessageSquare className="w-4 h-4 text-amber-400" />
                        <span className="text-sm font-medium text-amber-400">Summary</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{viewJournal.aiSummary}</p>
                    </div>
                  )}

                  {viewJournal.aiEmotion && (
                    <div className="p-3 rounded-lg bg-charcoal-800/50 border border-gold-500/10">
                      <div className="flex items-center gap-2 mb-1">
                        <Heart className="w-4 h-4 text-pink-400" />
                        <span className="text-sm font-medium text-pink-400">Emotional Pattern</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{viewJournal.aiEmotion}</p>
                    </div>
                  )}

                  {viewJournal.aiAdvice && (
                    <div className="p-3 rounded-lg bg-charcoal-800/50 border border-gold-500/10">
                      <div className="flex items-center gap-2 mb-1">
                        <Lightbulb className="w-4 h-4 text-green-400" />
                        <span className="text-sm font-medium text-green-400">Growth Advice</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{viewJournal.aiAdvice}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Generate AI Button if no insights */}
              {!viewJournal.aiSummary && !viewJournal.aiEmotion && !viewJournal.aiAdvice && (
                <Button
                  variant="outline"
                  className="w-full border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
                  onClick={() => handleGenerateAIInsight(viewJournal.id)}
                  disabled={isGeneratingAI === viewJournal.id}
                >
                  {isGeneratingAI === viewJournal.id ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate AI Insights
                    </>
                  )}
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Journal Dialog */}
      <Dialog open={!!editingJournal} onOpenChange={() => setEditingJournal(null)}>
        <DialogContent className="bg-charcoal-900 border-gold-500/20 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-foreground">Edit Entry</DialogTitle>
            <DialogDescription>Update your journal entry</DialogDescription>
          </DialogHeader>
          {editingJournal && (
            <div className="space-y-4">
              <Input
                value={editingJournal.title}
                onChange={(e) => setEditingJournal({ ...editingJournal, title: e.target.value })}
                className="bg-charcoal-800 border-gold-500/20"
              />
              <Textarea
                value={editingJournal.content}
                onChange={(e) => setEditingJournal({ ...editingJournal, content: e.target.value })}
                className="min-h-32 bg-charcoal-800 border-gold-500/20"
              />
              <div className="flex flex-wrap gap-2">
                {moodOptions.slice(0, 6).map((m) => {
                  const Icon = m.icon;
                  const isSelected = editingJournal.mood === m.value;
                  return (
                    <button
                      key={m.value}
                      type="button"
                      onClick={() => setEditingJournal({ ...editingJournal, mood: m.value })}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm transition-all ${
                        isSelected
                          ? `${m.bg} ${m.color} ring-1 ring-current`
                          : 'bg-charcoal-800 text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {m.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingJournal(null)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdate}
              disabled={isSaving}
              className="bg-gradient-to-r from-amber-600 to-orange-600 text-white"
            >
              {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent className="bg-charcoal-900 border-gold-500/20 max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-foreground">Delete Entry?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete your journal entry.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirm(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={isSaving}
            >
              {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
