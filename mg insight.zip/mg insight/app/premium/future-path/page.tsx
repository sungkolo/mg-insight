'use client';

import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  PieChart,
  Pie,
  Cell,
  Legend,
  RadialBarChart,
  RadialBar,
} from 'recharts';
import {
  Sparkles,
  Target,
  Plus,
  Trash2,
  Play,
  RotateCcw,
  TrendingUp,
  TrendingDown,
  Clock,
  Zap,
  Brain,
  Shield,
  Crown,
  Compass,
  GitBranch,
  Calendar,
  DollarSign,
  Briefcase,
  AlertTriangle,
  CheckCircle2,
  Save,
  Database,
  Lightbulb,
  ArrowRight,
  ChevronRight,
  BarChart3,
} from 'lucide-react';
import { useLanguage } from '@/context/language-context';

// Types
type RiskLevel = 'low' | 'medium' | 'high';

interface Decision {
  id: string;
  title: string;
  successProbability: number;
  riskLevel: RiskLevel;
  timeHorizon: number; // years
}

interface SimulationResult {
  id: string;
  goal: string;
  decisions: Decision[];
  overallSuccessProbability: number;
  averageTimeline: number;
  bestPath: Decision[];
  riskScore: number;
  recommendedDecision: Decision | null;
  timelineProjection: TimelinePoint[];
  outcomeDistribution: OutcomeData[];
  createdAt: Date;
}

interface TimelinePoint {
  year: number;
  incomeGrowth: number;
  careerStability: number;
  riskExposure: number;
}

interface OutcomeData {
  name: string;
  value: number;
  color: string;
}

// Risk configurations
const riskConfigs: Record<RiskLevel, { variance: number; color: string; labelKey: string }> = {
  low: { variance: 0.1, color: '#22c55e', labelKey: 'lowRisk' },
  medium: { variance: 0.25, color: '#eab308', labelKey: 'mediumRisk' },
  high: { variance: 0.4, color: '#ef4444', labelKey: 'highRisk' },
};

// Generate unique ID
const generateId = () => crypto.randomUUID();

// Monte Carlo Simulation Engine
function runMonteCarloSimulation(
  decisions: Decision[],
  iterations: number = 10000
): {
  successCount: number;
  averageTimeline: number;
  pathSuccessRates: Map<string, number>;
  timelineData: TimelinePoint[];
} {
  let successCount = 0;
  let totalTimeline = 0;
  const pathSuccessRates = new Map<string, number>();
  const pathAttempts = new Map<string, number>();
  
  // Generate timeline projection data
  const timelineData: TimelinePoint[] = [];
  const maxYears = Math.max(...decisions.map(d => d.timeHorizon), 10);
  
  for (let year = 1; year <= maxYears; year++) {
    let cumulativeSuccess = 0;
    let activeDecisions = 0;
    let totalRisk = 0;
    
    decisions.forEach(decision => {
      if (decision.timeHorizon >= year) {
        const progress = year / decision.timeHorizon;
        const riskVariance = riskConfigs[decision.riskLevel].variance;
        cumulativeSuccess += decision.successProbability * progress;
        activeDecisions++;
        totalRisk += riskVariance * 100;
      }
    });
    
    timelineData.push({
      year,
      incomeGrowth: Math.min(100, cumulativeSuccess * 0.8),
      careerStability: Math.min(100, 50 + cumulativeSuccess * 0.3 - totalRisk),
      riskExposure: Math.min(100, totalRisk + 20),
    });
  }
  
  // Run Monte Carlo iterations
  for (let i = 0; i < iterations; i++) {
    let pathSuccess = true;
    let pathTime = 0;
    const pathKey: string[] = [];
    
    for (const decision of decisions) {
      const variance = riskConfigs[decision.riskLevel].variance;
      const randomVariance = (Math.random() - 0.5) * 2 * variance;
      const effectiveProb = Math.max(0, Math.min(1, decision.successProbability / 100 + randomVariance));
      
      const random = Math.random();
      const decisionSuccess = random <= effectiveProb;
      
      if (!decisionSuccess) {
        pathSuccess = false;
      }
      
      pathTime += decision.timeHorizon * (decisionSuccess ? 1 : 0.5);
      pathKey.push(decision.id);
    }
    
    const key = pathKey.join('-');
    pathAttempts.set(key, (pathAttempts.get(key) || 0) + 1);
    
    if (pathSuccess) {
      successCount++;
      pathSuccessRates.set(key, (pathSuccessRates.get(key) || 0) + 1);
      totalTimeline += pathTime;
    }
  }
  
  // Normalize path success rates
  pathSuccessRates.forEach((count, key) => {
    pathSuccessRates.set(key, (count / (pathAttempts.get(key) || 1)) * 100);
  });
  
  return {
    successCount,
    averageTimeline: successCount > 0 ? totalTimeline / successCount : 0,
    pathSuccessRates,
    timelineData,
  };
}

// Decision Tree Node for visualization
interface TreeNode {
  id: string;
  title: string;
  probability: number;
  x: number;
  y: number;
  children: TreeNode[];
}

export default function FuturePathAI() {
  const { t } = useLanguage();
  
  // State
  const [goal, setGoal] = useState('');
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [isSimulating, setIsSimulating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentResult, setCurrentResult] = useState<SimulationResult | null>(null);
  const [savedSimulations, setSavedSimulations] = useState<SimulationResult[]>([]);
  
  // New decision form
  const [newDecision, setNewDecision] = useState({
    title: '',
    successProbability: 50,
    riskLevel: 'medium' as RiskLevel,
    timeHorizon: 5,
  });
  
  // Add decision
  const addDecision = useCallback(() => {
    if (!newDecision.title.trim()) return;
    
    const decision: Decision = {
      id: generateId(),
      title: newDecision.title,
      successProbability: newDecision.successProbability,
      riskLevel: newDecision.riskLevel,
      timeHorizon: newDecision.timeHorizon,
    };
    
    setDecisions(prev => [...prev, decision]);
    setNewDecision({
      title: '',
      successProbability: 50,
      riskLevel: 'medium',
      timeHorizon: 5,
    });
  }, [newDecision]);
  
  // Remove decision
  const removeDecision = useCallback((id: string) => {
    setDecisions(prev => prev.filter(d => d.id !== id));
  }, []);
  
  // Run simulation
  const runSimulation = useCallback(async () => {
    if (!goal.trim() || decisions.length === 0) return;
    
    setIsSimulating(true);
    setProgress(0);
    setCurrentResult(null);
    
    // Simulate progress
    const progressInterval = setInterval(() => {
      setProgress(prev => Math.min(prev + 5, 95));
    }, 100);
    
    // Run Monte Carlo simulation
    const { successCount, averageTimeline, pathSuccessRates, timelineData } = 
      runMonteCarloSimulation(decisions, 10000);
    
    clearInterval(progressInterval);
    setProgress(100);
    
    // Calculate overall success probability
    const overallSuccessProbability = (successCount / 10000) * 100;
    
    // Find best path
    let bestPathKey = '';
    let bestPathRate = 0;
    pathSuccessRates.forEach((rate, key) => {
      if (rate > bestPathRate) {
        bestPathRate = rate;
        bestPathKey = key;
      }
    });
    
    const bestPath = decisions.filter(d => bestPathKey.includes(d.id));
    
    // Calculate risk score
    const riskScore = decisions.reduce((sum, d) => {
      const riskValue = d.riskLevel === 'high' ? 3 : d.riskLevel === 'medium' ? 2 : 1;
      return sum + riskValue;
    }, 0);
    
    // Find recommended decision
    const recommendedDecision = decisions.reduce((best, d) => {
      const score = d.successProbability / (d.timeHorizon * (d.riskLevel === 'high' ? 1.5 : d.riskLevel === 'medium' ? 1.2 : 1));
      const bestScore = best ? best.successProbability / (best.timeHorizon * (best.riskLevel === 'high' ? 1.5 : best.riskLevel === 'medium' ? 1.2 : 1)) : 0;
      return score > bestScore ? d : best;
    }, null as Decision | null);
    
    // Generate outcome distribution
    const outcomeDistribution: OutcomeData[] = [
      { name: t.successes, value: overallSuccessProbability, color: '#22c55e' },
      { name: t.failures, value: 100 - overallSuccessProbability, color: '#ef4444' },
    ];
    
    const result: SimulationResult = {
      id: generateId(),
      goal,
      decisions: [...decisions],
      overallSuccessProbability,
      averageTimeline,
      bestPath,
      riskScore,
      recommendedDecision,
      timelineProjection: timelineData,
      outcomeDistribution,
      createdAt: new Date(),
    };
    
    setCurrentResult(result);
    setIsSimulating(false);
  }, [goal, decisions, t.successes, t.failures]);
  
  // Save simulation
  const saveSimulation = useCallback(() => {
    if (currentResult) {
      setSavedSimulations(prev => [currentResult, ...prev]);
    }
  }, [currentResult]);
  
  // Reset
  const reset = useCallback(() => {
    setGoal('');
    setDecisions([]);
    setCurrentResult(null);
    setProgress(0);
  }, []);
  
  // Load saved simulation
  const loadSimulation = useCallback((sim: SimulationResult) => {
    setGoal(sim.goal);
    setDecisions(sim.decisions);
    setCurrentResult(sim);
  }, []);
  
  // Delete saved simulation
  const deleteSimulation = useCallback((id: string) => {
    setSavedSimulations(prev => prev.filter(s => s.id !== id));
  }, []);
  
  // Stats for dashboard
  const dashboardStats = useMemo(() => [
    { label: t.decisions, value: decisions.length, icon: GitBranch, color: 'text-cyan-400' },
    { label: t.totalIterations, value: '10,000', icon: Zap, color: 'text-amber-400' },
    { label: t.averageTimeline, value: currentResult ? `${currentResult.averageTimeline.toFixed(1)} ${t.years}` : '-', icon: Clock, color: 'text-purple-400' },
    { label: t.pathsAnalyzed, value: currentResult ? Math.pow(2, decisions.length) : '-', icon: Brain, color: 'text-green-400' },
  ], [decisions.length, currentResult, t]);
  
  // Chart data for probability over time
  const probabilityChartData = useMemo(() => {
    if (!currentResult) return [];
    return currentResult.timelineProjection.map(point => ({
      year: `${t.year} ${point.year}`,
      incomeGrowth: point.incomeGrowth,
      careerStability: point.careerStability,
      riskExposure: point.riskExposure,
    }));
  }, [currentResult, t.year]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        <motion.div
          animate={{ opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 4, ease: 'easeInOut' }}
          className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ opacity: [0.2, 0.3, 0.2] }}
          transition={{ duration: 5, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-0 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10 p-4 lg:p-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Compass className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-white">{t.futurePath}</h1>
                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                  <Crown className="w-3 h-3 mr-1" />
                  {t.premium}
                </Badge>
              </div>
              <p className="text-sm text-zinc-400">
                {t.decisionIntelligence}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={reset}
            className="border-zinc-700 text-zinc-400 hover:text-white"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            {t.reset}
          </Button>
        </motion.div>

        {/* Dashboard Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {dashboardStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-zinc-900/50 border-zinc-800/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <stat.icon className={`w-4 h-4 ${stat.color}`} />
                    <span className="text-xs text-zinc-500">{stat.label}</span>
                  </div>
                  <p className="text-xl font-bold text-white">{stat.value}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Panel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1 space-y-4"
          >
            {/* Goal Input */}
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Target className="w-4 h-4 text-cyan-400" />
                  {t.goal}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder={t.goalPlaceholder}
                  className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500"
                />
              </CardContent>
            </Card>

            {/* Add Decision */}
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Plus className="w-4 h-4 text-emerald-400" />
                  {t.addDecision}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-zinc-400">{t.decisionTitle}</label>
                  <Input
                    value={newDecision.title}
                    onChange={(e) => setNewDecision(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Start a business"
                    className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500"
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm text-zinc-400">{t.successProbability}</label>
                    <span className="text-sm font-medium text-white">{newDecision.successProbability}%</span>
                  </div>
                  <Slider
                    value={[newDecision.successProbability]}
                    onValueChange={([value]) => setNewDecision(prev => ({ ...prev, successProbability: value }))}
                    max={100}
                    step={1}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm text-zinc-400">{t.riskLevel}</label>
                  <Select
                    value={newDecision.riskLevel}
                    onValueChange={(v) => setNewDecision(prev => ({ ...prev, riskLevel: v as RiskLevel }))}
                  >
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-700">
                      <SelectItem value="low">
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-green-400" />
                          {t.lowRisk}
                        </span>
                      </SelectItem>
                      <SelectItem value="medium">
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-yellow-400" />
                          {t.mediumRisk}
                        </span>
                      </SelectItem>
                      <SelectItem value="high">
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-red-400" />
                          {t.highRisk}
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm text-zinc-400">{t.timeHorizon}</label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={newDecision.timeHorizon}
                      onChange={(e) => setNewDecision(prev => ({ ...prev, timeHorizon: parseInt(e.target.value) || 1 }))}
                      className="bg-zinc-800/50 border-zinc-700 text-white"
                      min={1}
                      max={30}
                    />
                    <span className="text-sm text-zinc-400">{t.years}</span>
                  </div>
                </div>
                
                <Button
                  onClick={addDecision}
                  disabled={!newDecision.title.trim()}
                  className="w-full bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {t.addDecision}
                </Button>
              </CardContent>
            </Card>

            {/* Decisions List */}
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <GitBranch className="w-4 h-4 text-purple-400" />
                  {t.decisions} ({decisions.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-64 overflow-y-auto">
                {decisions.length === 0 ? (
                  <p className="text-sm text-zinc-500 text-center py-4">{t.noDecisionsYet}</p>
                ) : (
                  <AnimatePresence>
                    {decisions.map((decision, index) => (
                      <motion.div
                        key={decision.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center justify-between p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-white truncate">{decision.title}</p>
                          <div className="flex items-center gap-2 text-xs text-zinc-500">
                            <span>{decision.successProbability}%</span>
                            <span>•</span>
                            <span className={riskConfigs[decision.riskLevel].color.replace('#', 'text-')}>
                              {decision.riskLevel}
                            </span>
                            <span>•</span>
                            <span>{decision.timeHorizon} {t.years}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeDecision(decision.id)}
                          className="h-8 w-8 p-0 text-zinc-500 hover:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </CardContent>
            </Card>

            {/* Run Simulation Button */}
            <Button
              onClick={runSimulation}
              disabled={isSimulating || !goal.trim() || decisions.length === 0}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white h-12"
            >
              {isSimulating ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  >
                    <Play className="w-5 h-5 mr-2" />
                  </motion.div>
                  {t.running}
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  {t.runSimulation}
                </>
              )}
            </Button>
            
            {isSimulating && (
              <div className="space-y-2">
                <Progress value={progress} className="h-2" />
                <p className="text-xs text-zinc-500 text-center">
                  {t.processingIterations}
                </p>
              </div>
            )}
          </motion.div>

          {/* Results Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2 space-y-4"
          >
            {currentResult ? (
              <>
                {/* Main Result Card */}
                <Card className="bg-zinc-900/50 border-zinc-800/50">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <Target className="w-4 h-4 text-green-400" />
                        {t.simulationResults}
                      </CardTitle>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={saveSimulation}
                        className="border-zinc-700 text-zinc-400 hover:text-white"
                      >
                        <Save className="w-3 h-3 mr-1" />
                        {t.save}
                      </Button>
                    </div>
                    <CardDescription className="text-zinc-400">
                      {currentResult.goal}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                      <div className="text-center p-3 rounded-lg bg-green-500/10">
                        <p className="text-2xl font-bold text-green-400">
                          {currentResult.overallSuccessProbability.toFixed(1)}%
                        </p>
                        <p className="text-xs text-zinc-500">{t.successRate}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-cyan-500/10">
                        <p className="text-2xl font-bold text-cyan-400">
                          {currentResult.averageTimeline.toFixed(1)}
                        </p>
                        <p className="text-xs text-zinc-500">{t.yearsToGoal}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-purple-500/10">
                        <p className="text-2xl font-bold text-purple-400">
                          {currentResult.decisions.length}
                        </p>
                        <p className="text-xs text-zinc-500">{t.decisions}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-amber-500/10">
                        <p className="text-2xl font-bold text-amber-400">
                          {currentResult.riskScore}
                        </p>
                        <p className="text-xs text-zinc-500">{t.riskAnalysis}</p>
                      </div>
                    </div>

                    {/* Most Likely Outcome */}
                    <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500/10 to-emerald-500/5 border border-cyan-500/20 mb-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-emerald-500 flex items-center justify-center flex-shrink-0">
                          <Lightbulb className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-white mb-1">{t.mostLikelyOutcome}</h3>
                          <p className="text-sm text-zinc-300">
                            {currentResult.overallSuccessProbability >= 60 ? (
                              <>
                                {t.successes}! {currentResult.recommendedDecision?.title || 'Your decisions'} has a{' '}
                                <span className="text-green-400 font-medium">
                                  {currentResult.overallSuccessProbability.toFixed(1)}%
                                </span>{' '}
                                {t.probabilityOfSuccess} within{' '}
                                <span className="text-cyan-400 font-medium">
                                  {currentResult.averageTimeline.toFixed(1)} {t.years}
                                </span>.
                              </>
                            ) : (
                              <>
                                {t.warning}. Consider revising your decisions. Current probability is{' '}
                                <span className="text-red-400 font-medium">
                                  {currentResult.overallSuccessProbability.toFixed(1)}%
                                </span>.
                              </>
                            )}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Recommended Decision */}
                    {currentResult.recommendedDecision && (
                      <div className="flex items-center gap-3 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50">
                        <CheckCircle2 className="w-5 h-5 text-green-400" />
                        <div>
                          <p className="text-xs text-zinc-500">{t.recommendedDecision}</p>
                          <p className="font-medium text-white">{currentResult.recommendedDecision.title}</p>
                        </div>
                        <Badge className="bg-green-500/20 text-green-400 ml-auto">
                          {currentResult.recommendedDecision.successProbability}%
                        </Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Timeline Projection Chart */}
                <Card className="bg-zinc-900/50 border-zinc-800/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2 text-base">
                      <Calendar className="w-4 h-4 text-purple-400" />
                      {t.futureTimeline}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={probabilityChartData}>
                          <defs>
                            <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="colorCareer" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="colorRisk" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                          <XAxis dataKey="year" stroke="rgba(255,255,255,0.5)" tick={{ fontSize: 10 }} />
                          <YAxis stroke="rgba(255,255,255,0.5)" tick={{ fontSize: 10 }} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: '#18181b',
                              border: '1px solid rgba(255,255,255,0.1)',
                              borderRadius: '8px',
                            }}
                          />
                          <Legend />
                          <Area type="monotone" dataKey="incomeGrowth" stroke="#22c55e" fill="url(#colorIncome)" name={t.incomeGrowth} />
                          <Area type="monotone" dataKey="careerStability" stroke="#06b6d4" fill="url(#colorCareer)" name={t.careerStability} />
                          <Area type="monotone" dataKey="riskExposure" stroke="#f59e0b" fill="url(#colorRisk)" name={t.riskExposure} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* Charts Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Outcome Distribution Pie Chart */}
                  <Card className="bg-zinc-900/50 border-zinc-800/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        {t.outcomeDistribution}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={currentResult.outcomeDistribution}
                              cx="50%"
                              cy="50%"
                              innerRadius={50}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              {currentResult.outcomeDistribution.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  return (
                                    <div className="bg-zinc-900 border border-zinc-700 rounded-lg p-2">
                                      <p className="text-white font-medium">{payload[0].name}</p>
                                      <p className="text-zinc-400 text-sm">{payload[0].value?.toFixed(1)}%</p>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Decision Success Rates Bar Chart */}
                  <Card className="bg-zinc-900/50 border-zinc-800/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <BarChart3 className="w-4 h-4 text-amber-400" />
                        {t.probabilityGraph}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={currentResult.decisions.map(d => ({
                              name: d.title.length > 10 ? d.title.substring(0, 10) + '...' : d.title,
                              probability: d.successProbability,
                              fill: riskConfigs[d.riskLevel].color,
                            }))}
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                            <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" tick={{ fontSize: 9 }} />
                            <YAxis stroke="rgba(255,255,255,0.5)" domain={[0, 100]} />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: '#18181b',
                                border: '1px solid rgba(255,255,255,0.1)',
                                borderRadius: '8px',
                              }}
                            />
                            <Bar dataKey="probability" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Decision Tree Visualization */}
                <Card className="bg-zinc-900/50 border-zinc-800/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2 text-base">
                      <GitBranch className="w-4 h-4 text-purple-400" />
                      {t.decisionTree}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="relative h-48 overflow-hidden">
                      {/* Simple SVG Decision Tree */}
                      <svg width="100%" height="100%" viewBox="0 0 800 200" className="overflow-visible">
                        {/* Root node */}
                        <motion.g
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0 }}
                        >
                          <circle cx="400" cy="30" r="20" fill="#8b5cf6" />
                          <text x="400" y="35" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">
                            {t.goal.split(' ')[0]}
                          </text>
                        </motion.g>
                        
                        {/* Decision branches */}
                        {currentResult.decisions.map((decision, index) => {
                          const totalDecisions = currentResult.decisions.length;
                          const spacing = 700 / (totalDecisions + 1);
                          const x = 50 + spacing * (index + 1);
                          
                          return (
                            <motion.g
                              key={decision.id}
                              initial={{ opacity: 0, y: -20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.2 + index * 0.1 }}
                            >
                              {/* Connection line */}
                              <line
                                x1="400"
                                y1="50"
                                x2={x}
                                y2="100"
                                stroke={riskConfigs[decision.riskLevel].color}
                                strokeWidth="2"
                                strokeDasharray="5,5"
                              />
                              
                              {/* Decision node */}
                              <circle
                                cx={x}
                                cy="120"
                                r="25"
                                fill={riskConfigs[decision.riskLevel].color}
                                opacity="0.8"
                              />
                              <text
                                x={x}
                                y="116"
                                textAnchor="middle"
                                fill="white"
                                fontSize="8"
                                fontWeight="bold"
                              >
                                {decision.title.substring(0, 8)}
                              </text>
                              <text
                                x={x}
                                y="128"
                                textAnchor="middle"
                                fill="white"
                                fontSize="9"
                              >
                                {decision.successProbability}%
                              </text>
                              
                              {/* Outcome nodes */}
                              <motion.g
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ delay: 0.4 + index * 0.1 }}
                              >
                                <circle cx={x - 15} cy="175" r="12" fill="#22c55e" opacity="0.7" />
                                <text x={x - 15} y="179" textAnchor="middle" fill="white" fontSize="8">✓</text>
                                
                                <circle cx={x + 15} cy="175" r="12" fill="#ef4444" opacity="0.7" />
                                <text x={x + 15} y="179" textAnchor="middle" fill="white" fontSize="8">✗</text>
                                
                                <line x1={x} y1="145" x2={x - 15} y2="163" stroke="#22c55e" strokeWidth="1" />
                                <line x1={x} y1="145" x2={x + 15} y2="163" stroke="#ef4444" strokeWidth="1" />
                              </motion.g>
                            </motion.g>
                          );
                        })}
                      </svg>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-zinc-900/50 border-zinc-800/50 h-full flex items-center justify-center min-h-[500px]">
                <CardContent className="text-center py-12">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-20 h-20 rounded-2xl bg-zinc-800/50 border border-zinc-700 flex items-center justify-center mx-auto mb-4"
                  >
                    <Compass className="w-10 h-10 text-zinc-600" />
                  </motion.div>
                  <h3 className="text-lg font-medium text-white mb-2">{t.visualizeFuture}</h3>
                  <p className="text-sm text-zinc-500 max-w-sm mx-auto">
                    {t.enterYourGoal}
                  </p>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </div>

        {/* Saved Simulations */}
        {savedSimulations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Database className="w-4 h-4 text-blue-400" />
                  {t.savedPaths}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {savedSimulations.map((sim, index) => (
                    <motion.div
                      key={`${sim.id}-${index}`}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                    >
                      <Card className="bg-zinc-800/50 border-zinc-700/50 cursor-pointer hover:border-cyan-500/30 transition-all">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <p className="font-medium text-white truncate max-w-[180px]">{sim.goal}</p>
                              <p className="text-xs text-zinc-500">
                                {sim.createdAt.toLocaleDateString()}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge className="bg-green-500/20 text-green-400">
                                {sim.overallSuccessProbability.toFixed(0)}%
                              </Badge>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  deleteSimulation(sim.id);
                                }}
                                className="h-6 w-6 p-0 text-zinc-500 hover:text-red-400"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <span className="text-zinc-500">{sim.decisions.length} {t.decisions}</span>
                            <ChevronRight className="w-4 h-4 text-cyan-400" />
                            <span className="text-cyan-400">{sim.averageTimeline.toFixed(1)} {t.years}</span>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
