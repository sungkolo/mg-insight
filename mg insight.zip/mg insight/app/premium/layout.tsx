import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { Sparkles, Brain } from 'lucide-react';
import { PremiumHeaderClient } from '@/components/premium/PremiumHeaderClient';
import { PremiumSidebarClient } from '@/components/premium/PremiumSidebarClient';
import { FooterClient } from '@/components/premium/FooterClient';

export default async function PremiumLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Server-side session check - require login but no premium check
  const session = await getServerSession(authOptions);

  // Redirect if not authenticated - all users with account get access
  if (!session || !session.user) {
    redirect('/login?redirect=/premium');
  }

  return (
    <div className="min-h-screen bg-charcoal-950">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-gold-500/3 rounded-full blur-3xl" />
      </div>

      <div className="relative flex">
        {/* Sidebar - Desktop */}
        <aside className="hidden lg:flex flex-col w-72 min-h-screen bg-charcoal-900/30 border-r border-gold-500/10 fixed left-0 top-0">
          {/* Logo & Title */}
          <div className="p-6 border-b border-gold-500/10">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative w-12 h-12">
                <div className="absolute inset-0 gradient-gold rounded-xl rotate-45 group-hover:rotate-[50deg] transition-transform duration-300" />
                <div className="absolute inset-1.5 bg-charcoal-950 rounded-lg rotate-45" />
                <Brain className="absolute inset-0 m-auto w-5 h-5 text-gold-400" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-foreground">MG Insight</h1>
                <span className="text-[10px] text-gold-400 uppercase tracking-wider">Dashboard</span>
              </div>
            </Link>
          </div>

          {/* Sidebar Client Component with translations */}
          <PremiumSidebarClient
            name={session.user.name}
            email={session.user.email}
          />
        </aside>

        {/* Main Content */}
        <main className="flex-1 lg:ml-72">
          {/* Header */}
          <header className="sticky top-0 z-10 bg-charcoal-950/80 backdrop-blur-md border-b border-gold-500/10">
            <div className="px-4 sm:px-6 lg:px-8 py-4">
              <PremiumHeaderClient email={session.user.email} />
            </div>
          </header>

          {/* Page Content */}
          <div className="p-4 sm:p-6 lg:p-8">
            {children}
          </div>

          {/* Footer */}
          <footer className="border-t border-gold-500/10 py-6 px-4 sm:px-6 lg:px-8">
            <FooterClient />
          </footer>
        </main>
      </div>
    </div>
  );
}
