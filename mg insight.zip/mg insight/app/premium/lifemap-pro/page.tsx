'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import {
  Plus,
  Trash2,
  Edit3,
  Check,
  X,
  Map,
  Network,
  GitBranch,
  Clock,
  Target,
  Sparkles,
  Crown,
} from 'lucide-react';
import { useLanguage } from '@/context/language-context';

// Node Type Definition
interface LifeNode {
  id: number;
  title: string;
  description: string;
  probability: number;
  createdAt: Date;
}

// Initial empty state
const initialNodes: LifeNode[] = [];

export default function LifeMapPro() {
  const { t } = useLanguage();
  
  // State
  const [nodes, setNodes] = useState<LifeNode[]>(initialNodes);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  // Statistics calculation
  const totalNodes = nodes.length;
  const connections = 0; // For future implementation
  const decisions = nodes.length;

  // Create new node
  const createNode = useCallback(() => {
    const newNode: LifeNode = {
      id: Date.now(),
      title: t.newNode,
      description: t.enterDescription,
      probability: 50,
      createdAt: new Date(),
    };

    setNodes((prev) => [...prev, newNode]);
    setLastUpdated(new Date());
  }, [t.newNode, t.enterDescription]);

  // Delete node
  const deleteNode = useCallback((id: number) => {
    setNodes((prev) => prev.filter((node) => node.id !== id));
    setLastUpdated(new Date());
  }, []);

  // Start editing
  const startEditing = useCallback((node: LifeNode) => {
    setEditingId(node.id);
    setEditTitle(node.title);
    setEditDescription(node.description);
  }, []);

  // Cancel editing
  const cancelEditing = useCallback(() => {
    setEditingId(null);
    setEditTitle('');
    setEditDescription('');
  }, []);

  // Save edit
  const saveEdit = useCallback((id: number) => {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === id
          ? { ...node, title: editTitle, description: editDescription }
          : node
      )
    );
    setEditingId(null);
    setEditTitle('');
    setEditDescription('');
    setLastUpdated(new Date());
  }, [editTitle, editDescription]);

  // Update probability
  const updateProbability = useCallback((id: number, probability: number) => {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === id ? { ...node, probability } : node
      )
    );
    setLastUpdated(new Date());
  }, []);

  // Format date
  const formatDate = (date: Date) => {
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Stats with translations
  const statsItems = [
    { label: t.totalNodes, value: totalNodes, icon: Network, color: 'text-amber-400' },
    { label: t.connections, value: connections, icon: GitBranch, color: 'text-blue-400' },
    { label: t.decisions, value: decisions, icon: Target, color: 'text-green-400' },
    { label: t.lastUpdated, value: formatDate(lastUpdated), icon: Clock, color: 'text-purple-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 via-zinc-900 to-black">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        <motion.div
          animate={{ opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 4, ease: 'easeInOut' }}
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 5, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 p-6 lg:p-8">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/20"
            >
              <Map className="w-6 h-6 text-white" />
            </motion.div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-2xl font-bold text-white">{t.lifeMapPro}</h1>
                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                  <Crown className="w-3 h-3 mr-1" />
                  {t.premium}
                </Badge>
              </div>
              <p className="text-sm text-zinc-400">
                {t.lifeMap}
              </p>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex items-center gap-2 text-xs text-zinc-500"
          >
            <Clock className="w-3 h-3" />
            <span>{t.lastUpdated}: {lastUpdated.toLocaleTimeString()}</span>
          </motion.div>
        </motion.header>

        {/* Stats Section */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          {statsItems.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="bg-zinc-900/50 border border-zinc-800/50 rounded-xl p-4"
            >
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
                <span className="text-xs text-zinc-500">{stat.label}</span>
              </div>
              <p className="text-xl font-bold text-white">
                {stat.label === t.lastUpdated ? stat.value : stat.value}
              </p>
            </motion.div>
          ))}
        </section>

        {/* Nodes Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-amber-400" />
              {t.lifeMap}
            </h2>
            <Button
              onClick={createNode}
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              {t.newNode}
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence mode="popLayout">
              {nodes.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="col-span-full text-center py-12"
                >
                  <div className="flex items-center justify-center gap-2 text-amber-400 mb-3">
                    <Map className="w-5 h-5" />
                    <Sparkles className="w-5 h-5 text-purple-400" />
                  </div>
                  <p className="text-white mb-2">{t.noData}</p>
                  <p className="text-sm text-zinc-500">
                    {t.addNode}
                  </p>
                </motion.div>
              ) : (
                nodes.map((node) => (
                  <motion.div
                    key={node.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="bg-zinc-900/50 border border-zinc-800/50 rounded-xl overflow-hidden hover:border-zinc-700 transition-all">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500/20 to-orange-500/20 flex items-center justify-center">
                              <Map className="w-4 h-4 text-amber-500" />
                            </div>
                            {editingId === node.id ? (
                              <Input
                                value={editTitle}
                                onChange={(e) => setEditTitle(e.target.value)}
                                className="bg-transparent border-none text-white font-medium focus:ring-2 ring-amber-500/50"
                                autoFocus
                              />
                            ) : (
                              <CardTitle className="text-white text-base">
                                {node.title}
                              </CardTitle>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {editingId === node.id ? (
                          <Input
                            value={editDescription}
                            onChange={(e) => setEditDescription(e.target.value)}
                            className="bg-transparent border-none text-zinc-400 text-sm mb-4"
                            placeholder={t.enterDescription}
                          />
                        ) : (
                          <p className="text-sm text-zinc-400 mb-4">{node.description}</p>
                        )}

                        {/* Probability */}
                        <div className="mb-4">
                          <div className="flex items-center justify-between text-sm mb-2">
                            <span className="text-zinc-500">{t.probability}:</span>
                            <Badge
                              className={
                                node.probability >= 70
                                  ? 'bg-green-500/20 text-green-400'
                                  : node.probability >= 40
                                  ? 'bg-yellow-500/20 text-yellow-400'
                                  : 'bg-red-500/20 text-red-400'
                              }
                            >
                              {node.probability}%
                            </Badge>
                          </div>
                          <Slider
                            value={[node.probability]}
                            onValueChange={([value]) => updateProbability(node.id, value)}
                            max={100}
                            step={1}
                            className="w-full"
                          />
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2 pt-3 border-t border-zinc-800">
                          {editingId === node.id ? (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => saveEdit(node.id)}
                                className="flex-1 text-green-400 hover:bg-green-500/10"
                              >
                                <Check className="w-4 h-4 mr-1" />
                                {t.save}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={cancelEditing}
                                className="flex-1 text-zinc-400 hover:bg-zinc-800"
                              >
                                <X className="w-4 h-4 mr-1" />
                                {t.cancel}
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => startEditing(node)}
                                className="flex-1 text-amber-400 hover:bg-amber-500/10"
                              >
                                <Edit3 className="w-4 h-4 mr-1" />
                                {t.editNode}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteNode(node.id)}
                                className="flex-1 text-red-400 hover:bg-red-500/10"
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                {t.deleteNode}
                              </Button>
                            </>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </section>
      </div>
    </div>
  );
}
