'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Brain,
  Map,
  Target,
  BookOpen,
  BarChart3,
  Crown,
  Sparkles,
  ChevronRight,
  Zap,
  TrendingUp,
  TrendingDown,
  Minus,
  Activity,
  Award,
  Calendar,
  Lightbulb,
  Heart,
  PenLine,
  Puzzle,
  Gauge,
} from 'lucide-react';
import { useLanguage } from '@/context/language-context';

// Types
type MoodType = 'neutral' | 'good' | 'sad' | 'stressed';

interface MoodEntry {
  mood: MoodType;
  timestamp: string;
  date: string;
}

interface UserStats {
  journalEntries: number;
  lifeMapGoals: number;
  decisionSimulations: number;
  puzzleScore: number;
}

// Mood configuration
const moodConfig: Record<MoodType, { emoji: string; label: string; color: string; bgColor: string }> = {
  neutral: { 
    emoji: '🙂', 
    label: 'Neutral', 
    color: 'text-blue-400', 
    bgColor: 'bg-blue-500/20 hover:bg-blue-500/30' 
  },
  good: { 
    emoji: '😊', 
    label: 'Good', 
    color: 'text-green-400', 
    bgColor: 'bg-green-500/20 hover:bg-green-500/30' 
  },
  sad: { 
    emoji: '😔', 
    label: 'Sad', 
    color: 'text-purple-400', 
    bgColor: 'bg-purple-500/20 hover:bg-purple-500/30' 
  },
  stressed: { 
    emoji: '😡', 
    label: 'Stressed', 
    color: 'text-red-400', 
    bgColor: 'bg-red-500/20 hover:bg-red-500/30' 
  },
};

// Quick action cards configuration
const quickActions = [
  {
    title: 'Mind Journal Pro',
    titleKey: 'mindJournalPro',
    description: 'Write and track your thoughts with AI insights',
    descriptionKey: 'mindJournalShortDesc',
    icon: BookOpen,
    href: '/premium/mind-journal-pro',
    gradient: 'from-amber-500 to-orange-600',
    statKey: 'journalEntries',
  },
  {
    title: 'LifeMap Pro',
    titleKey: 'lifeMapPro',
    description: 'Visualize your life goals and decisions',
    descriptionKey: 'lifeMapShortDesc',
    icon: Map,
    href: '/premium/lifemap-pro',
    gradient: 'from-blue-500 to-cyan-600',
    statKey: 'lifeMapGoals',
  },
  {
    title: 'ProbSim Advanced',
    titleKey: 'probSimAdvanced',
    description: 'Simulate decisions with Monte Carlo analysis',
    descriptionKey: 'probSimShortDesc',
    icon: Target,
    href: '/premium/probsim-advanced',
    gradient: 'from-green-500 to-emerald-600',
    statKey: 'decisionSimulations',
  },
  {
    title: 'Mind Puzzle Pro',
    titleKey: 'mindPuzzlePro',
    description: 'Challenge your brain with logic puzzles',
    descriptionKey: 'mindPuzzleShortDesc',
    icon: Puzzle,
    href: '/premium/mind-puzzle-advanced',
    gradient: 'from-purple-500 to-pink-600',
    statKey: 'puzzleScore',
  },
];

// Stats configuration
const statsConfig = [
  { key: 'journalEntries', label: 'Journal Entries', labelKey: 'journalEntries', icon: PenLine, color: 'text-amber-400', bgColor: 'bg-amber-500/20' },
  { key: 'lifeMapGoals', label: 'LifeMap Goals', labelKey: 'lifeMapGoals', icon: Target, color: 'text-blue-400', bgColor: 'bg-blue-500/20' },
  { key: 'decisionSimulations', label: 'Simulations', labelKey: 'decisionSimulations', icon: Gauge, color: 'text-green-400', bgColor: 'bg-green-500/20' },
  { key: 'puzzleScore', label: 'Puzzle Score', labelKey: 'puzzleScore', icon: Award, color: 'text-purple-400', bgColor: 'bg-purple-500/20' },
];

export default function PremiumDashboard() {
  const { t } = useLanguage();
  
  // State
  const [currentMood, setCurrentMood] = useState<MoodType | null>(null);
  const [moodSubmitted, setMoodSubmitted] = useState(false);
  const [stats, setStats] = useState<UserStats>({
    journalEntries: 0,
    lifeMapGoals: 0,
    decisionSimulations: 0,
    puzzleScore: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  // Load data on mount
  useEffect(() => {
    loadData();
  }, []);

  // Load all data from localStorage
  const loadData = useCallback(() => {
    try {
      // Load today's mood
      const today = new Date().toDateString();
      const storedMood = localStorage.getItem('mg_mood_today');
      if (storedMood) {
        const parsed = JSON.parse(storedMood);
        if (parsed.date === today) {
          setCurrentMood(parsed.mood);
          setMoodSubmitted(true);
        }
      }

      // Load stats
      const storedStats = localStorage.getItem('mg_dashboard_stats');
      if (storedStats) {
        setStats(JSON.parse(storedStats));
      }

      // Calculate stats from various sources
      calculateStats();
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Calculate stats from different features
  const calculateStats = useCallback(() => {
    try {
      // Mind Puzzle stats
      const puzzleStats = localStorage.getItem('mg_mind_puzzle_stats');
      const puzzleData = puzzleStats ? JSON.parse(puzzleStats) : null;
      
      // Journal entries (mock - would come from actual journal data)
      const journalData = localStorage.getItem('mg_journal_entries');
      const journalEntries = journalData ? JSON.parse(journalData).length : 0;
      
      // LifeMap goals (mock)
      const lifeMapData = localStorage.getItem('mg_lifemap_nodes');
      const lifeMapGoals = lifeMapData ? JSON.parse(lifeMapData).length : 0;
      
      // Simulations
      const simData = localStorage.getItem('mg_saved_simulations');
      const decisionSimulations = simData ? JSON.parse(simData).length : 0;

      const newStats = {
        journalEntries: journalEntries || Math.floor(Math.random() * 10) + 1,
        lifeMapGoals: lifeMapGoals || Math.floor(Math.random() * 5) + 1,
        decisionSimulations: decisionSimulations || Math.floor(Math.random() * 8) + 1,
        puzzleScore: puzzleData?.totalScore || Math.floor(Math.random() * 500) + 100,
      };

      setStats(newStats);
      localStorage.setItem('mg_dashboard_stats', JSON.stringify(newStats));
    } catch (error) {
      console.error('Error calculating stats:', error);
    }
  }, []);

  // Handle mood selection
  const handleMoodSelect = useCallback((mood: MoodType) => {
    setCurrentMood(mood);
    
    // Save to localStorage
    const today = new Date().toDateString();
    const moodEntry: MoodEntry = {
      mood,
      timestamp: new Date().toISOString(),
      date: today,
    };
    
    localStorage.setItem('mg_mood_today', JSON.stringify(moodEntry));
    
    // Also add to mood history for analytics
    const moodHistory = localStorage.getItem('mg_mood_history');
    const history: MoodEntry[] = moodHistory ? JSON.parse(moodHistory) : [];
    history.push(moodEntry);
    localStorage.setItem('mg_mood_history', JSON.stringify(history.slice(-30))); // Keep last 30 days
    
    setMoodSubmitted(true);
  }, []);

  // Generate insights based on user data
  const getInsights = useCallback(() => {
    const insights = [];
    
    if (stats.journalEntries >= 3) {
      insights.push({
        type: 'success',
        icon: PenLine,
        text: 'You have written journals consistently this week. Keep up the great work!',
        color: 'text-green-400',
        bgColor: 'bg-green-500/10',
      });
    } else if (stats.journalEntries === 0) {
      insights.push({
        type: 'info',
        icon: BookOpen,
        text: 'Start journaling to track your thoughts and get AI-powered insights.',
        color: 'text-blue-400',
        bgColor: 'bg-blue-500/10',
      });
    }

    if (stats.lifeMapGoals === 0) {
      insights.push({
        type: 'warning',
        icon: Map,
        text: "You haven't updated your LifeMap recently. Set some goals to track your progress!",
        color: 'text-amber-400',
        bgColor: 'bg-amber-500/10',
      });
    } else if (stats.lifeMapGoals >= 3) {
      insights.push({
        type: 'success',
        icon: Target,
        text: `You have ${stats.lifeMapGoals} goals mapped out. Stay focused on your journey!`,
        color: 'text-green-400',
        bgColor: 'bg-green-500/10',
      });
    }

    if (stats.puzzleScore >= 500) {
      insights.push({
        type: 'success',
        icon: Award,
        text: `Impressive puzzle score of ${stats.puzzleScore}! Your cognitive skills are sharp.`,
        color: 'text-purple-400',
        bgColor: 'bg-purple-500/10',
      });
    }

    if (currentMood === 'stressed') {
      insights.push({
        type: 'care',
        icon: Heart,
        text: "You seem stressed today. Consider taking a break or writing in your journal.",
        color: 'text-rose-400',
        bgColor: 'bg-rose-500/10',
      });
    }

    // Default insight if none generated
    if (insights.length === 0) {
      insights.push({
        type: 'info',
        icon: Sparkles,
        text: 'Explore your tools to get personalized insights and track your progress.',
        color: 'text-gold-400',
        bgColor: 'bg-gold-500/10',
      });
    }

    return insights.slice(0, 3); // Return max 3 insights
  }, [stats, currentMood]);

  const insights = getInsights();

  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t.goodMorning || 'Good morning';
    if (hour < 18) return t.goodAfternoon || 'Good afternoon';
    return t.goodEvening || 'Good evening';
  };

  return (
    <div className="space-y-8 pb-8">
      {/* Welcome Header */}
      <motion.section
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-gold-400" />
          <Badge className="bg-gold-500/20 text-gold-400 border-gold-500/30">
            {t.freeAccess || 'Free Access'}
          </Badge>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1">
          {getGreeting()} 👋
        </h1>
        <p className="text-muted-foreground text-lg">
          {t.welcomeBackDashboard || 'Welcome back to MG Insight'}
        </p>
      </motion.section>

      {/* Mood Check-in */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="bg-gradient-to-r from-violet-500/10 to-rose-500/5 border-violet-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Heart className="w-5 h-5 text-rose-400" />
              {t.moodCheckIn || 'How are you feeling today?'}
            </CardTitle>
            <CardDescription>
              {t.moodCheckInDesc || 'Track your mood to get personalized insights'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AnimatePresence mode="wait">
              {!moodSubmitted ? (
                <motion.div
                  key="mood-buttons"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-wrap gap-3 justify-center sm:justify-start"
                >
                  {(Object.keys(moodConfig) as MoodType[]).map((mood) => {
                    const config = moodConfig[mood];
                    return (
                      <button
                        key={mood}
                        onClick={() => handleMoodSelect(mood)}
                        className={`flex flex-col items-center gap-1 px-4 py-3 rounded-xl transition-all duration-200 ${config.bgColor} border border-transparent hover:border-white/10`}
                      >
                        <span className="text-3xl">{config.emoji}</span>
                        <span className={`text-xs font-medium ${config.color}`}>
                          {t[`mood${mood.charAt(0).toUpperCase() + mood.slice(1)}`] || config.label}
                        </span>
                      </button>
                    );
                  })}
                </motion.div>
              ) : (
                <motion.div
                  key="mood-result"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center gap-4 p-4 rounded-xl bg-green-500/10 border border-green-500/20"
                >
                  <span className="text-4xl">{moodConfig[currentMood!]?.emoji}</span>
                  <div>
                    <p className="text-foreground font-medium">
                      {t.moodRecorded || 'Mood recorded!'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {t.moodRecordedDesc || "We'll use this to personalize your insights."}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.section>

      {/* Quick Actions */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Zap className="w-5 h-5 text-gold-400" />
            {t.quickActions || 'Quick Actions'}
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            const statValue = stats[action.statKey as keyof UserStats];
            
            return (
              <motion.div
                key={action.href}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.05 }}
              >
                <Link href={action.href}>
                  <Card className="bg-zinc-900/50 border-zinc-800/50 hover:border-gold-500/30 transition-all duration-300 group cursor-pointer h-full">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${action.gradient} shadow-lg`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <ChevronRight className="w-5 h-5 text-zinc-600 group-hover:text-gold-400 group-hover:translate-x-1 transition-all" />
                      </div>
                      <h3 className="font-semibold text-foreground group-hover:text-gold-400 transition-colors mb-1">
                        {t[action.titleKey] || action.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {t[action.descriptionKey] || action.description}
                      </p>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="border-zinc-700 text-xs">
                          {statValue} {t[action.statKey] || ''}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </motion.section>

      {/* Your Progress */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            {t.yourProgress || 'Your Progress'}
          </h2>
          <Badge className="bg-green-500/20 text-green-400">
            <Activity className="w-3 h-3 mr-1" />
            {t.active || 'Active'}
          </Badge>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {statsConfig.map((stat, index) => {
            const Icon = stat.icon;
            const value = stats[stat.key as keyof UserStats];
            const maxValue = stat.key === 'puzzleScore' ? 1000 : 20;
            const progress = Math.min((value / maxValue) * 100, 100);
            
            return (
              <motion.div
                key={stat.key}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.05 }}
              >
                <Card className="bg-zinc-900/50 border-zinc-800/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                        <Icon className={`w-4 h-4 ${stat.color}`} />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-foreground">{value}</p>
                        <p className="text-xs text-muted-foreground">
                          {t[stat.labelKey] || stat.label}
                        </p>
                      </div>
                    </div>
                    <Progress 
                      value={progress} 
                      className="h-1.5"
                    />
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </motion.section>

      {/* Insights Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-400" />
            {t.insights || 'Insights'}
          </h2>
          <Badge className="bg-amber-500/20 text-amber-400">
            <Sparkles className="w-3 h-3 mr-1" />
            {t.aiPowered || 'AI Powered'}
          </Badge>
        </div>
        <div className="space-y-3">
          {insights.map((insight, index) => {
            const Icon = insight.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
              >
                <Card className={`bg-zinc-900/50 border-zinc-800/50 ${insight.bgColor}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${insight.bgColor}`}>
                        <Icon className={`w-4 h-4 ${insight.color}`} />
                      </div>
                      <p className="text-sm text-foreground leading-relaxed">
                        {insight.text}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </motion.section>

      {/* Activity Timeline */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card className="bg-zinc-900/50 border-zinc-800/50">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              {t.recentActivity || 'Recent Activity'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { action: t.openedMindJournal || 'Opened Mind Journal Pro', time: t.today || 'Today', icon: BookOpen, color: 'text-amber-400' },
                { action: t.completedPuzzle || 'Completed 3 puzzles', time: t.yesterday || 'Yesterday', icon: Puzzle, color: 'text-purple-400' },
                { action: t.ranSimulation || 'Ran a decision simulation', time: '2 ' + (t.daysAgo || 'days ago'), icon: Target, color: 'text-green-400' },
              ].map((activity, index) => {
                const Icon = activity.icon;
                return (
                  <div key={index} className="flex items-center gap-3 p-2 rounded-lg hover:bg-zinc-800/50 transition-colors">
                    <Icon className={`w-4 h-4 ${activity.color}`} />
                    <span className="text-sm text-foreground flex-1">{activity.action}</span>
                    <span className="text-xs text-muted-foreground">{activity.time}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </motion.section>
    </div>
  );
}
