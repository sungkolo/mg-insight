'use client';

import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sparkles,
  Target,
  Play,
  RotateCcw,
  TrendingUp,
  TrendingDown,
  Minus,
  Crown,
  Zap,
  Brain,
  Shield,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  Award,
  Gauge,
  ArrowUpRight,
  ArrowDownRight,
  MinusCircle,
} from 'lucide-react';
import { useLanguage } from '@/context/language-context';

// Types
type EffortLevel = 'low' | 'medium' | 'high';

interface DecisionInput {
  title: string;
  probability: number;
  timeHorizon: number;
  effortLevel: EffortLevel;
}

interface SimulationResult {
  decision: DecisionInput;
  adjustedProbability: number;
  bestCase: string;
  normalCase: string;
  worstCase: string;
  insight: string;
  riskLevel: string;
  strategicSuggestion: string;
  expectedOutcome: string;
}

// Effort multipliers
const effortMultipliers: Record<EffortLevel, { value: number; label: string; color: string }> = {
  low: { value: 0.85, label: 'Low', color: 'text-red-400' },
  medium: { value: 1.0, label: 'Medium', color: 'text-yellow-400' },
  high: { value: 1.15, label: 'High', color: 'text-green-400' },
};

// Generate unique ID
const generateId = () => crypto.randomUUID();

// Calculate adjusted probability
function calculateAdjustedProbability(input: DecisionInput): number {
  const effortMultiplier = effortMultipliers[input.effortLevel].value;
  
  // Time horizon factor (longer time = more uncertainty but also more opportunity)
  const timeFactor = input.timeHorizon <= 3 ? 0.95 : input.timeHorizon <= 6 ? 1.0 : 1.05;
  
  // Calculate adjusted probability
  const adjusted = input.probability * effortMultiplier * timeFactor;
  
  return Math.min(Math.max(adjusted, 0), 100);
}

// Generate insight based on probability
function generateInsight(probability: number, t: any): string {
  if (probability > 70) {
    return t.highProbabilityPath || "High probability path. Consistent effort will likely produce strong results.";
  } else if (probability >= 40) {
    return t.moderateProbabilityPath || "Moderate probability. Strategic decisions will determine the outcome.";
  } else {
    return t.highRiskPath || "High risk path. Requires strong commitment and resilience.";
  }
}

// Generate outcomes
function generateOutcomes(
  decision: DecisionInput,
  adjustedProbability: number
): { bestCase: string; normalCase: string; worstCase: string } {
  const bestProb = Math.min(adjustedProbability * 1.25, 98);
  const worstProb = Math.max(adjustedProbability * 0.5, 5);
  
  const bestCase = `Success achieved within ${Math.max(1, Math.round(decision.timeHorizon * 0.7))} years with optimal conditions. Full goal realization with ${bestProb.toFixed(0)}% confidence.`;
  const normalCase = `Goal achieved in approximately ${decision.timeHorizon} years with consistent effort. Expected outcome with ${adjustedProbability.toFixed(0)}% probability.`;
  const worstCase = `Extended timeline of ${Math.round(decision.timeHorizon * 1.5)} years or partial achievement. Challenges may require pivoting. ${worstProb.toFixed(0)}% base scenario.`;
  
  return { bestCase, normalCase, worstCase };
}

// Determine risk level
function getRiskLevel(probability: number): { level: string; color: string; bg: string } {
  if (probability >= 70) {
    return { level: 'Low Risk', color: 'text-green-400', bg: 'bg-green-500/20' };
  } else if (probability >= 40) {
    return { level: 'Medium Risk', color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
  } else {
    return { level: 'High Risk', color: 'text-red-400', bg: 'bg-red-500/20' };
  }
}

// Generate strategic suggestion
function generateStrategicSuggestion(
  decision: DecisionInput,
  adjustedProbability: number
): string {
  if (adjustedProbability >= 70) {
    return `Maintain momentum with your "${decision.title}" decision. Focus on execution and scaling your efforts for maximum impact.`;
  } else if (adjustedProbability >= 40) {
    return `Consider breaking down "${decision.title}" into smaller milestones. Monitor progress quarterly and adjust strategy based on results.`;
  } else {
    return `For "${decision.title}", develop a backup plan and consider starting with a pilot approach. Build skills and resources before full commitment.`;
  }
}

// Generate expected outcome
function generateExpectedOutcome(
  decision: DecisionInput,
  adjustedProbability: number
): string {
  if (adjustedProbability >= 70) {
    return `Likely to succeed within ${decision.timeHorizon} years. High confidence in achieving your goal.`;
  } else if (adjustedProbability >= 40) {
    return `Moderate chance of success. Results depend heavily on execution quality and external factors.`;
  } else {
    return `Challenging path ahead. Success possible but requires exceptional dedication and favorable conditions.`;
  }
}

export default function RealitySimulator() {
  const { t } = useLanguage();
  
  // State
  const [decision, setDecision] = useState<DecisionInput>({
    title: '',
    probability: 50,
    timeHorizon: 5,
    effortLevel: 'medium',
  });
  
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  
  // Run simulation
  const runSimulation = useCallback(() => {
    if (!decision.title.trim()) return;
    
    setIsSimulating(true);
    
    // Simulate processing delay for better UX
    setTimeout(() => {
      const adjustedProbability = calculateAdjustedProbability(decision);
      const outcomes = generateOutcomes(decision, adjustedProbability);
      const riskLevel = getRiskLevel(adjustedProbability);
      const insight = generateInsight(adjustedProbability, t);
      const strategicSuggestion = generateStrategicSuggestion(decision, adjustedProbability);
      const expectedOutcome = generateExpectedOutcome(decision, adjustedProbability);
      
      setResult({
        decision: { ...decision },
        adjustedProbability,
        ...outcomes,
        insight,
        riskLevel: riskLevel.level,
        strategicSuggestion,
        expectedOutcome,
      });
      
      setIsSimulating(false);
    }, 800);
  }, [decision, t]);
  
  // Reset
  const reset = useCallback(() => {
    setDecision({
      title: '',
      probability: 50,
      timeHorizon: 5,
      effortLevel: 'medium',
    });
    setResult(null);
  }, []);
  
  // Risk level for display
  const riskInfo = useMemo(() => {
    if (!result) return null;
    return getRiskLevel(result.adjustedProbability);
  }, [result]);
  
  // Progress bar color
  const progressColor = useMemo(() => {
    if (!result) return 'bg-primary';
    if (result.adjustedProbability >= 70) return 'bg-green-500';
    if (result.adjustedProbability >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  }, [result]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        <motion.div
          animate={{ opacity: [0.15, 0.25, 0.15] }}
          transition={{ duration: 4, ease: 'easeInOut' }}
          className="absolute top-1/4 right-1/4 w-80 h-80 bg-violet-500/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ opacity: [0.15, 0.2, 0.15] }}
          transition={{ duration: 5, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto p-4 lg:p-8 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-3"
        >
          <div className="flex items-center justify-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-rose-600 flex items-center justify-center shadow-lg shadow-violet-500/20">
              <Gauge className="w-7 h-7 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white">
            {t.realitySimulator || 'Reality Simulator'}
          </h1>
          <p className="text-zinc-400 max-w-lg mx-auto">
            {t.realitySimulatorDescription || 'Simulate possible outcomes of your life decisions using probability thinking'}
          </p>
          <Badge className="bg-violet-500/20 text-violet-400 border-violet-500/30">
            <Crown className="w-3 h-3 mr-1" />
            {t.premium || 'Premium'}
          </Badge>
        </motion.div>

        {/* Input Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-violet-400" />
                {t.decisionTitle || 'Decision Input'}
              </CardTitle>
              <CardDescription className="text-zinc-400">
                Enter your decision details to simulate possible outcomes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Decision Title */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-300">
                  {t.decisionTitle || 'Decision Title'}
                </label>
                <Input
                  value={decision.title}
                  onChange={(e) => setDecision(prev => ({ ...prev, title: e.target.value }))}
                  placeholder={t.startBusiness || "e.g., Start a business"}
                  className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:border-violet-500 focus:ring-violet-500/20"
                />
              </div>

              {/* Probability Slider */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium text-zinc-300">
                    {t.successProbability || 'Probability of Success'}
                  </label>
                  <Badge variant="outline" className="border-zinc-700 text-white">
                    {decision.probability}%
                  </Badge>
                </div>
                <Slider
                  value={[decision.probability]}
                  onValueChange={([value]) => setDecision(prev => ({ ...prev, probability: value }))}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-zinc-500">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>

              {/* Time Horizon */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium text-zinc-300">
                    {t.timeHorizon || 'Time Horizon'}
                  </label>
                  <Badge variant="outline" className="border-zinc-700 text-white">
                    {decision.timeHorizon} {t.years || 'years'}
                  </Badge>
                </div>
                <Slider
                  value={[decision.timeHorizon]}
                  onValueChange={([value]) => setDecision(prev => ({ ...prev, timeHorizon: value }))}
                  max={10}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-zinc-500">
                  <span>1 {t.year || 'year'}</span>
                  <span>5 {t.years || 'years'}</span>
                  <span>10 {t.years || 'years'}</span>
                </div>
              </div>

              {/* Effort Level */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-300">
                  {t.effortLevel || 'Effort Level'}
                </label>
                <Select
                  value={decision.effortLevel}
                  onValueChange={(v) => setDecision(prev => ({ ...prev, effortLevel: v as EffortLevel }))}
                >
                  <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-900 border-zinc-700">
                    <SelectItem value="low">
                      <div className="flex items-center gap-2">
                        <MinusCircle className="w-4 h-4 text-red-400" />
                        <span>{t.lowRisk || 'Low Effort'}</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="medium">
                      <div className="flex items-center gap-2">
                        <Minus className="w-4 h-4 text-yellow-400" />
                        <span>{t.mediumRisk || 'Medium Effort'}</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="high">
                      <div className="flex items-center gap-2">
                        <ArrowUpRight className="w-4 h-4 text-green-400" />
                        <span>{t.highRisk || 'High Effort'}</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-2">
                <Button
                  onClick={runSimulation}
                  disabled={isSimulating || !decision.title.trim()}
                  className="flex-1 bg-gradient-to-r from-violet-600 to-rose-600 hover:from-violet-500 hover:to-rose-500 text-white h-12 text-base font-medium"
                >
                  {isSimulating ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      >
                        <Play className="w-5 h-5 mr-2" />
                      </motion.div>
                      {t.simulating || 'Simulating...'}
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      {t.runSimulation || 'Run Reality Simulation'}
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={reset}
                  className="border-zinc-700 text-zinc-400 hover:text-white hover:bg-zinc-800"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Results */}
        <AnimatePresence mode="wait">
          {result && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: 0.1 }}
              className="space-y-4"
            >
              {/* Probability Result Card */}
              <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-sm overflow-hidden">
                <div className={`h-1 ${progressColor}`} style={{ width: `${result.adjustedProbability}%` }} />
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      <Target className="w-5 h-5 text-violet-400" />
                      {t.simulationResults || 'Simulation Results'}
                    </CardTitle>
                    {riskInfo && (
                      <Badge className={`${riskInfo.bg} ${riskInfo.color} border-0`}>
                        {result.riskLevel}
                      </Badge>
                    )}
                  </div>
                  <CardDescription className="text-zinc-400">
                    {result.decision.title}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Probability Display */}
                  <div className="text-center py-4">
                    <motion.div
                      initial={{ scale: 0.5 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 200 }}
                      className="inline-flex items-center justify-center"
                    >
                      <span className={`text-6xl font-bold ${
                        result.adjustedProbability >= 70 ? 'text-green-400' :
                        result.adjustedProbability >= 40 ? 'text-yellow-400' : 'text-red-400'
                      }`}>
                        {result.adjustedProbability.toFixed(0)}%
                      </span>
                    </motion.div>
                    <p className="text-zinc-400 mt-2">{t.successProbability || 'Success Probability'}</p>
                    
                    {/* Progress Bar */}
                    <div className="mt-4 max-w-md mx-auto">
                      <Progress 
                        value={result.adjustedProbability} 
                        className="h-3 bg-zinc-800"
                      />
                    </div>
                  </div>

                  {/* Insight Box */}
                  <div className="p-4 rounded-xl bg-gradient-to-r from-violet-500/10 to-rose-500/5 border border-violet-500/20">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-rose-500 flex items-center justify-center flex-shrink-0">
                        <Lightbulb className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white mb-1">
                          {t.aiInterpretation || 'AI Insight'}
                        </h3>
                        <p className="text-zinc-300 text-sm leading-relaxed">
                          {result.insight}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Outcomes Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Best Case */}
                <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-green-400 flex items-center gap-2 text-sm">
                      <TrendingUp className="w-4 h-4" />
                      {t.bestCase || 'Best Case'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-zinc-300 text-sm leading-relaxed">
                      {result.bestCase}
                    </p>
                  </CardContent>
                </Card>

                {/* Normal Case */}
                <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-yellow-400 flex items-center gap-2 text-sm">
                      <Minus className="w-4 h-4" />
                      {t.normalCase || 'Normal Case'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-zinc-300 text-sm leading-relaxed">
                      {result.normalCase}
                    </p>
                  </CardContent>
                </Card>

                {/* Worst Case */}
                <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-red-400 flex items-center gap-2 text-sm">
                      <TrendingDown className="w-4 h-4" />
                      {t.worstCase || 'Worst Case'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-zinc-300 text-sm leading-relaxed">
                      {result.worstCase}
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Simulation Card */}
              <Card className="bg-zinc-900/80 border-zinc-800 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-violet-400" />
                    {t.simulationCard || 'Simulation Analysis'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Expected Outcome */}
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50">
                    <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-zinc-500 uppercase tracking-wide mb-1">
                        {t.expectedOutcome || 'Expected Outcome'}
                      </p>
                      <p className="text-zinc-200 text-sm">{result.expectedOutcome}</p>
                    </div>
                  </div>

                  {/* Risk Level */}
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50">
                    <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                      result.adjustedProbability >= 70 ? 'text-green-400' :
                      result.adjustedProbability >= 40 ? 'text-yellow-400' : 'text-red-400'
                    }`} />
                    <div>
                      <p className="text-xs text-zinc-500 uppercase tracking-wide mb-1">
                        {t.riskLevel || 'Risk Level'}
                      </p>
                      <p className="text-zinc-200 text-sm">{result.riskLevel} - Based on {result.adjustedProbability.toFixed(0)}% success probability</p>
                    </div>
                  </div>

                  {/* Strategic Suggestion */}
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50">
                    <Brain className="w-5 h-5 text-violet-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-zinc-500 uppercase tracking-wide mb-1">
                        {t.strategicSuggestion || 'Strategic Suggestion'}
                      </p>
                      <p className="text-zinc-200 text-sm">{result.strategicSuggestion}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Decision Summary */}
              <Card className="bg-gradient-to-r from-violet-500/10 to-rose-500/5 border-violet-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-zinc-400">
                      <Zap className="w-4 h-4 text-violet-400" />
                      <span>{t.decision || 'Decision'}: <span className="text-white font-medium">{result.decision.title}</span></span>
                    </div>
                    <div className="flex items-center gap-4 text-zinc-400">
                      <span>{result.decision.timeHorizon} {t.years || 'years'}</span>
                      <span className={effortMultipliers[result.decision.effortLevel].color}>
                        {effortMultipliers[result.decision.effortLevel].label} Effort
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty State */}
        {!result && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-zinc-900/50 border-zinc-800 backdrop-blur-sm">
              <CardContent className="py-12 text-center">
                <motion.div
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-16 h-16 rounded-2xl bg-zinc-800/50 border border-zinc-700 flex items-center justify-center mx-auto mb-4"
                >
                  <Gauge className="w-8 h-8 text-zinc-600" />
                </motion.div>
                <h3 className="text-lg font-medium text-white mb-2">
                  {t.enterDecision || 'Enter Your Decision'}
                </h3>
                <p className="text-sm text-zinc-500 max-w-sm mx-auto">
                  {t.enterDecisionDesc || 'Fill in your decision details above and click "Run Reality Simulation" to see possible outcomes.'}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
