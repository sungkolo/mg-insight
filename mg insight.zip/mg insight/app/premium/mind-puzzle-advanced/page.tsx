'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Brain,
  Play,
  Trophy,
  Clock,
  Star,
  Zap,
  Target,
  RotateCcw,
  ChevronRight,
  Trash2,
  AlertCircle,
} from 'lucide-react';
import { useMindPuzzleStats } from '@/hooks/use-mind-puzzle-stats';

// Puzzle categories with icons and colors
const categories = [
  { 
    id: 'math',
    name: 'Logic Math', 
    description: 'Solve arithmetic problems against the clock',
    icon: Zap, 
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/20',
    href: '/premium/mind-puzzle/play/math',
    difficulty: 'Easy'
  },
  { 
    id: 'memory',
    name: 'Memory Challenge', 
    description: 'Remember and recall number sequences',
    icon: Brain, 
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/20',
    href: '/premium/mind-puzzle/play/memory',
    difficulty: 'Medium'
  },
  { 
    id: 'pattern',
    name: 'Pattern Recognition', 
    description: 'Find the next number in sequences',
    icon: Target, 
    color: 'text-green-400',
    bgColor: 'bg-green-500/20',
    href: '/premium/mind-puzzle/play/pattern',
    difficulty: 'Hard'
  },
];

export default function MindPuzzleAdvancedPage() {
  const router = useRouter();
  const { stats, isLoaded, resetStats, getAccuracy, getAverageTime } = useMindPuzzleStats();
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Calculate derived stats
  const accuracy = getAccuracy();
  const avgTime = getAverageTime();

  // Format time for display
  const formatTime = (seconds: number) => {
    if (seconds < 60) {
      return `${seconds}s`;
    }
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  // Handle reset stats
  const handleResetStats = () => {
    if (showResetConfirm) {
      resetStats();
      setShowResetConfirm(false);
    } else {
      setShowResetConfirm(true);
      // Auto-hide after 5 seconds
      setTimeout(() => setShowResetConfirm(false), 5000);
    }
  };

  // Stats cards data
  const statsCards = [
    {
      label: 'Total Score',
      value: stats.totalScore.toLocaleString(),
      icon: Trophy,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/10',
    },
    {
      label: 'Completed',
      value: stats.completed.toString(),
      icon: Star,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10',
    },
    {
      label: 'Avg Time',
      value: formatTime(avgTime),
      icon: Clock,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
    },
    {
      label: 'Accuracy',
      value: `${accuracy}%`,
      icon: Zap,
      color: 'text-green-400',
      bgColor: 'bg-green-500/10',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-6 h-6 text-purple-400" />
            <Badge className="bg-purple-500/20 text-purple-400">Pro Feature</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Mind Puzzle Advanced</h1>
          <p className="text-muted-foreground mt-1">
            Challenge your mind with brain training puzzles and track your cognitive progress.
          </p>
        </div>
        <Button 
          onClick={() => router.push('/premium/mind-puzzle/play')}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
        >
          <Play className="w-4 h-4 mr-2" />
          Quick Play
        </Button>
      </motion.div>

      {/* Stats Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 sm:grid-cols-4 gap-4"
      >
        {statsCards.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 + index * 0.05 }}
          >
            <Card className="bg-zinc-900/50 border-zinc-800/50 hover:border-zinc-700/50 transition-colors">
              <CardContent className="p-4 text-center">
                <div className={`w-12 h-12 rounded-xl ${stat.bgColor} flex items-center justify-center mx-auto mb-3`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {isLoaded ? stat.value : '...'}
                </p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Game Modes */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <h2 className="text-lg font-semibold text-foreground mb-4">Game Modes</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {categories.map((category, index) => {
            const Icon = category.icon;
            const gamesPlayed = stats.gamesPlayed[category.id as keyof typeof stats.gamesPlayed];
            const highScore = stats.highScores[category.id as keyof typeof stats.highScores];
            
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
              >
                <Card 
                  className="bg-zinc-900/50 border-zinc-800/50 hover:border-purple-500/30 transition-all cursor-pointer group"
                  onClick={() => router.push(category.href)}
                >
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`p-3 rounded-xl ${category.bgColor}`}>
                        <Icon className={`w-6 h-6 ${category.color}`} />
                      </div>
                      <Badge className={
                        category.difficulty === 'Easy' ? 'bg-green-500/20 text-green-400' :
                        category.difficulty === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }>
                        {category.difficulty}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-foreground group-hover:text-purple-400 transition-colors mb-1">
                      {category.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {category.description}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-3">
                        <span className="text-muted-foreground">
                          Played: <span className="text-foreground font-medium">{gamesPlayed}</span>
                        </span>
                        <span className="text-muted-foreground">
                          Best: <span className="text-foreground font-medium">{highScore}</span>
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-purple-400 transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </motion.section>

      {/* Recent Activity Summary */}
      {isLoaded && stats.completed > 0 && (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-lg font-semibold text-foreground mb-4">Performance Summary</h2>
          <Card className="bg-zinc-900/50 border-zinc-800/50">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                {/* Accuracy Progress */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Overall Accuracy</span>
                    <span className="text-lg font-bold text-foreground">{accuracy}%</span>
                  </div>
                  <Progress 
                    value={accuracy} 
                    className="h-2"
                  />
                  <p className="text-xs text-muted-foreground">
                    {stats.correctAnswers} correct out of {stats.totalAttempts} attempts
                  </p>
                </div>

                {/* Time Stats */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Time Played</span>
                    <span className="text-lg font-bold text-foreground">{formatTime(stats.totalTime)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-blue-400" />
                    <span className="text-muted-foreground">
                      Avg: {formatTime(avgTime)} per game
                    </span>
                  </div>
                </div>

                {/* Games Breakdown */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Games Played</span>
                    <span className="text-lg font-bold text-foreground">{stats.completed}</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Zap className="w-3 h-3 text-blue-400" />
                      Math: {stats.gamesPlayed.math}
                    </span>
                    <span className="flex items-center gap-1">
                      <Brain className="w-3 h-3 text-purple-400" />
                      Memory: {stats.gamesPlayed.memory}
                    </span>
                    <span className="flex items-center gap-1">
                      <Target className="w-3 h-3 text-green-400" />
                      Pattern: {stats.gamesPlayed.pattern}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>
      )}

      {/* Empty State */}
      {isLoaded && stats.completed === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-zinc-900/50 border-zinc-800/50 border-dashed">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-purple-500/10 flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">No games played yet</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto mb-4">
                Start playing to track your progress! Your stats will appear here after you complete games.
              </p>
              <Button
                onClick={() => router.push('/premium/mind-puzzle/play')}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Playing
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="flex flex-wrap gap-3"
      >
        <Button 
          variant="outline" 
          onClick={handleResetStats}
          className={`border-zinc-700 ${showResetConfirm ? 'text-red-400 border-red-500/50 hover:bg-red-500/10' : 'text-zinc-400 hover:text-white'}`}
        >
          {showResetConfirm ? (
            <>
              <AlertCircle className="w-4 h-4 mr-2" />
              Click again to confirm
            </>
          ) : (
            <>
              <Trash2 className="w-4 h-4 mr-2" />
              Reset Stats
            </>
          )}
        </Button>
        <Button 
          variant="outline" 
          onClick={() => router.push('/premium/mind-puzzle/play')}
          className="border-zinc-700 text-muted-foreground hover:text-foreground"
        >
          Play Games
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </motion.div>
    </div>
  );
}
