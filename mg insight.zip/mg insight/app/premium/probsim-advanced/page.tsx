'use client';

import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  Play,
  RotateCcw,
  TrendingUp,
  Target,
  Zap,
  Brain,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  Sparkles,
  Save,
  Trash2,
  ChevronRight,
  Database,
  Lightbulb,
  Shield,
  Crown,
} from 'lucide-react';
import { useLanguage } from '@/context/language-context';

// Types
type RiskFactor = 'low' | 'medium' | 'high';

interface SimulationConfig {
  id: string;
  scenarioName: string;
  baseProbability: number;
  riskFactor: RiskFactor;
  iterations: number;
  createdAt: Date;
}

interface SimulationResult {
  id: string;
  config: SimulationConfig;
  totalRuns: number;
  successes: number;
  failures: number;
  successProbability: number;
  failureProbability: number;
  expectedOutcome: string;
  distribution: DistributionPoint[];
  confidenceInterval: {
    lower: number;
    upper: number;
  };
  insight: string;
  createdAt: Date;
}

interface DistributionPoint {
  iteration: number;
  cumulativeSuccess: number;
  probability: number;
}

// Generate unique ID using crypto.randomUUID for guaranteed uniqueness
const generateId = () => crypto.randomUUID();

// Monte Carlo Simulation Engine
function runMonteCarloSimulation(
  baseProbability: number,
  riskFactor: RiskFactor,
  iterations: number
): { successes: number; distribution: DistributionPoint[] } {
  const adjustedProb = baseProbability / 100;
  const riskVariances = { low: 0.05, medium: 0.15, high: 0.30 };
  const variance = riskVariances[riskFactor];
  let successes = 0;
  const distribution: DistributionPoint[] = [];
  const sampleInterval = Math.max(1, Math.floor(iterations / 100));

  for (let i = 1; i <= iterations; i++) {
    const randomVariance = (Math.random() - 0.5) * 2 * variance;
    const effectiveProb = Math.max(0, Math.min(1, adjustedProb + randomVariance));
    
    const random = Math.random();
    if (random <= effectiveProb) {
      successes++;
    }

    if (i % sampleInterval === 0 || i === iterations) {
      distribution.push({
        iteration: i,
        cumulativeSuccess: successes,
        probability: (successes / i) * 100,
      });
    }
  }

  return { successes, distribution };
}

export default function ProbSimAdvanced() {
  const { t } = useLanguage();
  
  // Risk factor adjustments with translations
  const riskAdjustments: Record<RiskFactor, { variance: number; label: string; color: string }> = {
    low: { variance: 0.05, label: t.lowRisk, color: 'text-green-400' },
    medium: { variance: 0.15, label: t.mediumRisk, color: 'text-yellow-400' },
    high: { variance: 0.30, label: t.highRisk, color: 'text-red-400' },
  };

  // Example scenarios with translations
  const exampleScenarios = [
    {
      name: t.careerChange,
      probability: 65,
      risk: 'medium' as RiskFactor,
      description: t.careerChangeDesc,
    },
    {
      name: t.startupLaunch,
      probability: 35,
      risk: 'high' as RiskFactor,
      description: t.startupLaunchDesc,
    },
    {
      name: t.investmentDecision,
      probability: 72,
      risk: 'medium' as RiskFactor,
      description: t.investmentDecisionDesc,
    },
    {
      name: t.educationPath,
      probability: 85,
      risk: 'low' as RiskFactor,
      description: t.educationPathDesc,
    },
  ];

  // Form state
  const [scenarioName, setScenarioName] = useState('');
  const [baseProbability, setBaseProbability] = useState(50);
  const [riskFactor, setRiskFactor] = useState<RiskFactor>('medium');
  const [iterations, setIterations] = useState(10000);
  
  // Simulation state
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentResult, setCurrentResult] = useState<SimulationResult | null>(null);
  const [savedSimulations, setSavedSimulations] = useState<SimulationResult[]>([]);
  
  // Calculate dashboard stats
  const stats = useMemo(() => {
    const totalRuns = savedSimulations.reduce((sum, s) => sum + s.totalRuns, 0);
    const avgProbability = savedSimulations.length > 0
      ? savedSimulations.reduce((sum, s) => sum + s.successProbability, 0) / savedSimulations.length
      : 0;
    const totalIterations = savedSimulations.reduce((sum, s) => sum + s.config.iterations, 0);
    
    return {
      totalSimulations: savedSimulations.length,
      totalRuns,
      avgProbability: avgProbability.toFixed(1),
      totalIterations,
    };
  }, [savedSimulations]);

  // Generate AI Insight with translations
  const generateInsight = useCallback((result: SimulationResult): string => {
    const successRate = result.successProbability;
    const risk = result.config.riskFactor;
    
    let insight = `Based on ${result.totalRuns.toLocaleString()} Monte Carlo simulations, `;
    
    if (successRate >= 80) {
      insight += `the scenario shows a highly favorable ${successRate.toFixed(1)}% success probability. `;
      insight += `This indicates strong potential for positive outcomes. `;
    } else if (successRate >= 60) {
      insight += `the scenario shows a ${successRate.toFixed(1)}% success probability. `;
      insight += `The odds are favorable but success is not guaranteed. `;
    } else if (successRate >= 40) {
      insight += `the scenario shows a ${successRate.toFixed(1)}% success probability. `;
      insight += `Results are uncertain - consider additional preparation. `;
    } else {
      insight += `the scenario shows a challenging ${successRate.toFixed(1)}% success probability. `;
      insight += `Significant effort or strategy adjustment may be needed. `;
    }
    
    if (risk === 'high') {
      insight += `The ${riskAdjustments[risk].label.toLowerCase()} risk factor introduces significant volatility. `;
      insight += `Consider risk mitigation strategies.`;
    } else if (risk === 'medium') {
      insight += `The ${riskAdjustments[risk].label.toLowerCase()} risk factor suggests moderate uncertainty.`;
    } else {
      insight += `The ${riskAdjustments[risk].label.toLowerCase()} risk factor indicates stable conditions.`;
    }
    
    return insight;
  }, [riskAdjustments]);
  
  // Run simulation
  const runSimulation = useCallback(async () => {
    if (!scenarioName.trim()) return;
    
    setIsRunning(true);
    setProgress(0);
    setCurrentResult(null);
    
    const config: SimulationConfig = {
      id: generateId(),
      scenarioName,
      baseProbability,
      riskFactor,
      iterations,
      createdAt: new Date(),
    };
    
    const progressInterval = setInterval(() => {
      setProgress((prev) => Math.min(prev + 10, 90));
    }, 200);
    
    const { successes, distribution } = runMonteCarloSimulation(
      baseProbability,
      riskFactor,
      iterations
    );
    
    clearInterval(progressInterval);
    setProgress(100);
    
    const failures = iterations - successes;
    const successProbability = (successes / iterations) * 100;
    const failureProbability = 100 - successProbability;
    
    const stdError = Math.sqrt((successProbability * failureProbability) / iterations);
    const confidenceInterval = {
      lower: Math.max(0, successProbability - 1.96 * stdError),
      upper: Math.min(100, successProbability + 1.96 * stdError),
    };
    
    const result: SimulationResult = {
      id: generateId(),
      config,
      totalRuns: iterations,
      successes,
      failures,
      successProbability,
      failureProbability,
      expectedOutcome: successProbability >= 50 ? 'Success' : 'Failure',
      distribution,
      confidenceInterval,
      insight: '',
      createdAt: new Date(),
    };
    
    result.insight = generateInsight(result);
    
    setCurrentResult(result);
    setIsRunning(false);
  }, [scenarioName, baseProbability, riskFactor, iterations, generateInsight]);
  
  const saveSimulation = useCallback(() => {
    if (currentResult) {
      setSavedSimulations((prev) => [currentResult, ...prev]);
    }
  }, [currentResult]);
  
  const loadExample = useCallback((example: typeof exampleScenarios[0]) => {
    setScenarioName(example.name);
    setBaseProbability(example.probability);
    setRiskFactor(example.risk);
  }, [exampleScenarios]);
  
  const resetForm = useCallback(() => {
    setScenarioName('');
    setBaseProbability(50);
    setRiskFactor('medium');
    setIterations(10000);
    setCurrentResult(null);
    setProgress(0);
  }, []);
  
  const deleteSimulation = useCallback((id: string) => {
    setSavedSimulations((prev) => prev.filter((s) => s.id !== id));
  }, []);
  
  // Chart data
  const pieData = currentResult ? [
    { name: t.successes, value: currentResult.successProbability, color: '#22c55e' },
    { name: t.failures, value: currentResult.failureProbability, color: '#ef4444' },
  ] : [];
  
  const barData = currentResult ? [
    { name: t.successes, value: currentResult.successes, fill: '#22c55e' },
    { name: t.failures, value: currentResult.failures, fill: '#ef4444' },
  ] : [];

  // Dashboard stats with translations
  const dashboardStats = [
    { label: t.totalRuns, value: stats.totalRuns.toLocaleString(), icon: Database, color: 'text-blue-400' },
    { label: t.avgProbability, value: `${stats.avgProbability}%`, icon: Target, color: 'text-amber-400' },
    { label: t.activeModels, value: stats.totalSimulations, icon: Brain, color: 'text-purple-400' },
    { label: t.iterations, value: stats.totalIterations.toLocaleString(), icon: Zap, color: 'text-green-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        <motion.div
          animate={{ opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 4, ease: 'easeInOut' }}
          className="absolute top-0 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ opacity: [0.2, 0.3, 0.2] }}
          transition={{ duration: 5, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-0 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10 p-4 lg:p-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-white">{t.probSimAdvanced}</h1>
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                  <Crown className="w-3 h-3 mr-1" />
                  {t.premium}
                </Badge>
              </div>
              <p className="text-sm text-zinc-400">
                {t.monteCarloSimulation}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={resetForm}
            className="border-zinc-700 text-zinc-400 hover:text-white"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            {t.reset}
          </Button>
        </motion.div>

        {/* Dashboard Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {dashboardStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-zinc-900/50 border-zinc-800/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <stat.icon className={`w-4 h-4 ${stat.color}`} />
                    <span className="text-xs text-zinc-500">{stat.label}</span>
                  </div>
                  <p className="text-xl font-bold text-white">{stat.value}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1 space-y-4"
          >
            {/* Simulation Setup */}
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Target className="w-4 h-4 text-purple-400" />
                  {t.simulationSetup}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Scenario Name */}
                <div className="space-y-2">
                  <label className="text-sm text-zinc-400">{t.scenarioName}</label>
                  <Input
                    value={scenarioName}
                    onChange={(e) => setScenarioName(e.target.value)}
                    placeholder={t.enterScenarioName}
                    className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500"
                  />
                </div>

                {/* Base Probability */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <label className="text-sm text-zinc-400">{t.baseProbability}</label>
                    <span className="text-sm font-medium text-white">{baseProbability}%</span>
                  </div>
                  <Slider
                    value={[baseProbability]}
                    onValueChange={([value]) => setBaseProbability(value)}
                    max={100}
                    step={1}
                  />
                </div>

                {/* Risk Factor */}
                <div className="space-y-2">
                  <label className="text-sm text-zinc-400">{t.riskFactor}</label>
                  <Select value={riskFactor} onValueChange={(v) => setRiskFactor(v as RiskFactor)}>
                    <SelectTrigger className="bg-zinc-800/50 border-zinc-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-700">
                      <SelectItem value="low">
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-green-400" />
                          {t.lowRisk}
                        </span>
                      </SelectItem>
                      <SelectItem value="medium">
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-yellow-400" />
                          {t.mediumRisk}
                        </span>
                      </SelectItem>
                      <SelectItem value="high">
                        <span className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-red-400" />
                          {t.highRisk}
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Iterations */}
                <div className="space-y-2">
                  <label className="text-sm text-zinc-400">{t.iterations}</label>
                  <Input
                    type="number"
                    value={iterations}
                    onChange={(e) => setIterations(Math.max(100, Math.min(100000, parseInt(e.target.value) || 10000)))}
                    className="bg-zinc-800/50 border-zinc-700 text-white"
                  />
                  <p className="text-xs text-zinc-500">{t.range}: 100 - 100,000</p>
                </div>

                {/* Run Button */}
                <Button
                  onClick={runSimulation}
                  disabled={isRunning || !scenarioName.trim()}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
                >
                  {isRunning ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      >
                        <Play className="w-4 h-4 mr-2" />
                      </motion.div>
                      {t.running}
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      {t.runSimulation}
                    </>
                  )}
                </Button>

                {/* Progress */}
                {isRunning && (
                  <div className="space-y-2">
                    <Progress value={progress} className="h-2" />
                    <p className="text-xs text-zinc-500 text-center">
                      {t.processingIterations.replace('iterations', iterations.toLocaleString())}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Example Scenarios */}
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Lightbulb className="w-4 h-4 text-amber-400" />
                  {t.exampleScenarios}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {exampleScenarios.map((example) => (
                  <button
                    key={example.name}
                    onClick={() => loadExample(example)}
                    className="w-full p-3 rounded-lg bg-zinc-800/50 border border-zinc-700/50 hover:border-purple-500/30 text-left transition-all group"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-white group-hover:text-purple-400 transition-colors">
                          {example.name}
                        </p>
                        <p className="text-xs text-zinc-500">{example.description}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-zinc-500 group-hover:text-purple-400" />
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Results Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2 space-y-4"
          >
            {currentResult ? (
              <>
                {/* Result Summary */}
                <Card className="bg-zinc-900/50 border-zinc-800/50">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <BarChart3 className="w-4 h-4 text-green-400" />
                        {currentResult.config.scenarioName}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className={riskAdjustments[currentResult.config.riskFactor].color}>
                          {riskAdjustments[currentResult.config.riskFactor].label}
                        </Badge>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={saveSimulation}
                          className="border-zinc-700 text-zinc-400 hover:text-white"
                        >
                          <Save className="w-3 h-3 mr-1" />
                          {t.save}
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                      <div className="text-center p-3 rounded-lg bg-zinc-800/50">
                        <p className="text-2xl font-bold text-white">
                          {currentResult.totalRuns.toLocaleString()}
                        </p>
                        <p className="text-xs text-zinc-500">{t.totalRuns}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-green-500/10">
                        <p className="text-2xl font-bold text-green-400">
                          {currentResult.successes.toLocaleString()}
                        </p>
                        <p className="text-xs text-zinc-500">{t.successes}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-red-500/10">
                        <p className="text-2xl font-bold text-red-400">
                          {currentResult.failures.toLocaleString()}
                        </p>
                        <p className="text-xs text-zinc-500">{t.failures}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-purple-500/10">
                        <p className={`text-2xl font-bold ${currentResult.successProbability >= 50 ? 'text-green-400' : 'text-red-400'}`}>
                          {currentResult.successProbability.toFixed(1)}%
                        </p>
                        <p className="text-xs text-zinc-500">{t.successRate}</p>
                      </div>
                    </div>

                    {/* Confidence Interval */}
                    <div className="p-4 rounded-lg bg-zinc-800/50 mb-4">
                      <p className="text-sm text-zinc-400 mb-2">{t.confidenceInterval}</p>
                      <div className="flex items-center gap-4">
                        <span className="text-lg font-bold text-white">
                          {currentResult.confidenceInterval.lower.toFixed(1)}%
                        </span>
                        <div className="flex-1 h-2 bg-zinc-700 rounded-full relative">
                          <div
                            className="absolute h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                            style={{
                              left: `${currentResult.confidenceInterval.lower}%`,
                              width: `${currentResult.confidenceInterval.upper - currentResult.confidenceInterval.lower}%`,
                            }}
                          />
                        </div>
                        <span className="text-lg font-bold text-white">
                          {currentResult.confidenceInterval.upper.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Charts */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Pie Chart */}
                  <Card className="bg-zinc-900/50 border-zinc-800/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <PieChartIcon className="w-4 h-4 text-purple-400" />
                        {t.successVsFailure}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={pieData}
                              cx="50%"
                              cy="50%"
                              innerRadius={50}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              {pieData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  return (
                                    <div className="bg-zinc-900 border border-zinc-700 rounded-lg p-2">
                                      <p className="text-white font-medium">{payload[0].name}</p>
                                      <p className="text-zinc-400 text-sm">{payload[0].value?.toFixed(1)}%</p>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Bar Chart */}
                  <Card className="bg-zinc-900/50 border-zinc-800/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2 text-base">
                        <BarChart3 className="w-4 h-4 text-amber-400" />
                        {t.resultsDistribution}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={barData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                            <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                            <YAxis stroke="rgba(255,255,255,0.5)" />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: '#18181b',
                                border: '1px solid rgba(255,255,255,0.1)',
                                borderRadius: '8px',
                              }}
                            />
                            <Bar dataKey="value" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Monte Carlo Distribution Curve */}
                <Card className="bg-zinc-900/50 border-zinc-800/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2 text-base">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      {t.monteCarloDistributionCurve}
                    </CardTitle>
                    <CardDescription>
                      {t.probabilityConvergence} {iterations.toLocaleString()} iterations
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={currentResult.distribution}>
                          <defs>
                            <linearGradient id="colorProb" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                          <XAxis
                            dataKey="iteration"
                            stroke="rgba(255,255,255,0.5)"
                            tick={{ fontSize: 10 }}
                          />
                          <YAxis
                            domain={[0, 100]}
                            stroke="rgba(255,255,255,0.5)"
                            tick={{ fontSize: 10 }}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: '#18181b',
                              border: '1px solid rgba(255,255,255,0.1)',
                              borderRadius: '8px',
                            }}
                            formatter={(value: number) => [`${value.toFixed(1)}%`, 'Probability']}
                          />
                          <Area
                            type="monotone"
                            dataKey="probability"
                            stroke="#a855f7"
                            strokeWidth={2}
                            fill="url(#colorProb)"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Insight */}
                <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/5 border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white mb-2 flex items-center gap-2">
                          {t.aiInterpretation}
                          <Badge className="bg-purple-500/20 text-purple-400 text-[10px]">{t.autoGenerated}</Badge>
                        </h3>
                        <p className="text-zinc-300 leading-relaxed">{currentResult.insight}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="bg-zinc-900/50 border-zinc-800/50 h-full flex items-center justify-center min-h-[400px]">
                <CardContent className="text-center py-12">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-20 h-20 rounded-2xl bg-zinc-800/50 border border-zinc-700 flex items-center justify-center mx-auto mb-4"
                  >
                    <Activity className="w-10 h-10 text-zinc-600" />
                  </motion.div>
                  <h3 className="text-lg font-medium text-white mb-2">{t.noSimulationYet}</h3>
                  <p className="text-sm text-zinc-500 max-w-sm mx-auto">
                    {t.noSimulationDescription}
                  </p>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </div>

        {/* Saved Simulations */}
        {savedSimulations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-zinc-900/50 border-zinc-800/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Database className="w-4 h-4 text-blue-400" />
                  {t.savedSimulations}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {savedSimulations.map((sim, index) => (
                    <motion.div
                      key={`${sim.id || 'sim'}-${index}`}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                    >
                      <Card className="bg-zinc-800/50 border-zinc-700/50">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <p className="font-medium text-white">{sim.config.scenarioName}</p>
                              <p className="text-xs text-zinc-500">
                                {sim.createdAt.toLocaleDateString()}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteSimulation(sim.id)}
                              className="h-6 w-6 p-0 text-zinc-500 hover:text-red-400"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <span className="text-zinc-500">{t.successRate}:</span>
                              <span className={`ml-1 font-medium ${sim.successProbability >= 50 ? 'text-green-400' : 'text-red-400'}`}>
                                {sim.successProbability.toFixed(1)}%
                              </span>
                            </div>
                            <div>
                              <span className="text-zinc-500">{t.iterations}:</span>
                              <span className="ml-1 font-medium text-white">{sim.config.iterations.toLocaleString()}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}
