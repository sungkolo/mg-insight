'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import {
  BarChart3,
  Activity,
  Calendar,
  Loader2,
  AlertCircle,
  Lightbulb,
  TrendingUp,
} from 'lucide-react';

// Types
interface WeeklyDataItem {
  day: string;
  date: string;
  mood: number;
  entries: number;
}

interface Stats {
  totalEntries: number;
  avgMoodScore: number;
  hasData: boolean;
}

interface AnalyticsResponse {
  success: boolean;
  weeklyData: WeeklyDataItem[];
  stats: Stats;
  error?: string;
  message?: string;
}

// Mood color based on score (1-10)
const getMoodColor = (score: number): string => {
  if (score === 0) return '#374151'; // gray - no data
  if (score >= 8) return '#22c55e'; // green - excellent
  if (score >= 6) return '#eab308'; // yellow - good
  if (score >= 4) return '#f97316'; // orange - neutral
  return '#ef4444'; // red - low
};

// Get mood label based on score
const getMoodLabel = (score: number): string => {
  if (score === 0) return 'No Data';
  if (score >= 9) return 'Excellent';
  if (score >= 7) return 'Good';
  if (score >= 5) return 'Neutral';
  if (score >= 3) return 'Low';
  return 'Very Low';
};

export default function MoodAnalyticsPage() {
  const [weeklyData, setWeeklyData] = useState<WeeklyDataItem[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalEntries: 0,
    avgMoodScore: 0,
    hasData: false,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const res = await fetch('/api/analytics/mood');
      const data: AnalyticsResponse = await res.json();

      if (data.success) {
        setWeeklyData(data.weeklyData);
        setStats(data.stats);
      } else {
        setError(data.message || data.error || 'Failed to load analytics');
      }
    } catch (err) {
      console.error('Failed to fetch analytics:', err);
      setError('Failed to load analytics. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin text-yellow-400 mx-auto" />
          <p className="text-muted-foreground">Loading your mood analytics...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="bg-gray-900/50 border-red-500/20 max-w-md">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <p className="text-red-400 mb-4">{error}</p>
            <button
              onClick={fetchData}
              className="px-4 py-2 rounded-lg bg-yellow-600 text-white hover:bg-yellow-500 transition-colors"
            >
              Try Again
            </button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate average for display
  const avgMood = stats.avgMoodScore;
  const avgMoodColor = getMoodColor(avgMood);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-6 h-6 text-yellow-400" />
            <Badge className="bg-yellow-500/20 text-yellow-400">Pro Feature</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Mood Analytics Pro</h1>
          <p className="text-muted-foreground mt-1">
            Track your emotional well-being over the past 7 days.
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Entries */}
        <Card className="bg-gray-900/50 border-yellow-500/10 hover:border-yellow-500/30 transition-colors">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Entries</p>
                <p className="text-3xl font-bold text-foreground">{stats.totalEntries}</p>
              </div>
              <div className="p-3 rounded-xl bg-yellow-500/20">
                <Calendar className="w-6 h-6 text-yellow-400" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              Journal entries this week
            </p>
          </CardContent>
        </Card>

        {/* Average Mood */}
        <Card className="bg-gray-900/50 border-yellow-500/10 hover:border-yellow-500/30 transition-colors">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Average Mood</p>
                <div className="flex items-baseline gap-1">
                  <p className="text-3xl font-bold text-foreground">{avgMood}</p>
                  <span className="text-sm text-muted-foreground">/ 10</span>
                </div>
              </div>
              <div className="p-3 rounded-xl" style={{ backgroundColor: `${avgMoodColor}20` }}>
                <Activity className="w-6 h-6" style={{ color: avgMoodColor }} />
              </div>
            </div>
            <div className="mt-3">
              <Badge style={{ backgroundColor: `${avgMoodColor}20`, color: avgMoodColor, border: 'none' }}>
                {getMoodLabel(avgMood)}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Mood Status */}
        <Card className="bg-gray-900/50 border-yellow-500/10 hover:border-yellow-500/30 transition-colors">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Status</p>
                <p className="text-3xl font-bold text-foreground">
                  {stats.hasData ? 'Active' : 'No Data'}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-purple-500/20">
                <TrendingUp className="w-6 h-6 text-purple-400" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              {stats.hasData ? 'Keep journaling!' : 'Start writing to track'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Activity Chart */}
      <Card className="bg-gray-900/50 border-yellow-500/10">
        <CardHeader>
          <CardTitle className="text-lg text-foreground flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-yellow-400" />
            Weekly Activity
          </CardTitle>
          <CardDescription>
            Your mood scores for the past 7 days (scale 1-10)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {stats.hasData ? (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="day" 
                    stroke="#9ca3af" 
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="#9ca3af" 
                    fontSize={12}
                    domain={[0, 10]}
                    ticks={[0, 2, 4, 6, 8, 10]}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#fff',
                    }}
                    formatter={(value: number, name: string) => [
                      name === 'mood' ? `${value}/10` : value,
                      name === 'mood' ? 'Mood Score' : 'Entries',
                    ]}
                    labelFormatter={(label, payload) => {
                      const data = payload?.[0]?.payload as WeeklyDataItem | undefined;
                      return data ? `${label} (${data.date})` : label;
                    }}
                  />
                  <Bar dataKey="mood" radius={[4, 4, 0, 0]}>
                    {weeklyData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getMoodColor(entry.mood)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-72 flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
                <p className="text-muted-foreground text-lg">Belum ada data mood minggu ini</p>
                <p className="text-muted-foreground text-sm mt-2">
                  Start journaling to see your mood trends
                </p>
                <a
                  href="/premium/mind-journal-pro"
                  className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-lg bg-gradient-to-r from-yellow-600 to-orange-600 text-white hover:from-yellow-500 hover:to-orange-500 transition-all"
                >
                  <Lightbulb className="w-4 h-4" />
                  Start Journaling
                </a>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Daily Breakdown */}
      {stats.hasData && (
        <Card className="bg-gray-900/50 border-yellow-500/10">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Activity className="w-5 h-5 text-purple-400" />
              Daily Breakdown
            </CardTitle>
            <CardDescription>
              Detailed view of your daily mood scores
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2">
              {weeklyData.map((item, index) => (
                <div
                  key={index}
                  className="text-center p-3 rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors"
                >
                  <p className="text-xs text-muted-foreground mb-1">{item.day}</p>
                  <p 
                    className="text-xl font-bold"
                    style={{ color: getMoodColor(item.mood) }}
                  >
                    {item.mood > 0 ? item.mood : '-'}
                  </p>
                  {item.entries > 0 && (
                    <p className="text-[10px] text-muted-foreground mt-1">
                      {item.entries} {item.entries === 1 ? 'entry' : 'entries'}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Insights Card */}
      {stats.hasData && (
        <Card className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-yellow-500/20">
                <Lightbulb className="w-6 h-6 text-yellow-400" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Your Mood Insight</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {avgMood >= 7 ? (
                    <>
                      Great job! Your average mood this week is {avgMood}/10, indicating positive 
                      emotional well-being. Keep up the good habits and continue journaling to 
                      maintain this positive trend.
                    </>
                  ) : avgMood >= 4 ? (
                    <>
                      Your average mood this week is {avgMood}/10. This is a moderate score.
                      Consider what activities or situations might be affecting your mood and
                      try to incorporate more activities that bring you joy.
                    </>
                  ) : (
                    <>
                      Your average mood this week is {avgMood}/10. This suggests you might be
                      going through a challenging time. Consider practicing self-care, talking
                      to someone you trust, or seeking professional support if needed.
                    </>
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
