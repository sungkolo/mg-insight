'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Target,
  Trophy,
  TrendingUp,
  RotateCcw,
  ArrowLeft,
  CheckCircle,
  XCircle,
  Sparkles,
  Play,
  Zap,
  Home,
} from 'lucide-react';
import { useMindPuzzleStats } from '@/hooks/use-mind-puzzle-stats';

interface PatternProblem {
  sequence: number[];
  answer: number;
  rule: string;
}

export default function PatternModePage() {
  const router = useRouter();
  const { handlePuzzleComplete } = useMindPuzzleStats();
  
  // Game state
  const [problem, setProblem] = useState<PatternProblem | null>(null);
  const [userAnswer, setUserAnswer] = useState<string>('');
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [highScore, setHighScore] = useState(0);
  const [highLevel, setHighLevel] = useState(0);
  
  // Timer tracking
  const [gameStartTime, setGameStartTime] = useState<number>(0);
  const [totalGameTime, setTotalGameTime] = useState<number>(0);
  
  // Track correct answers for stats
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [totalAttempts, setTotalAttempts] = useState(0);

  // Pattern generators by difficulty
  const patternGenerators = [
    // Level 1-3: Simple addition
    () => {
      const start = Math.floor(Math.random() * 10) + 1;
      const step = Math.floor(Math.random() * 5) + 2;
      const sequence = [start, start + step, start + step * 2, start + step * 3];
      return { sequence, answer: start + step * 4, rule: `+${step} each time` };
    },
    // Level 4-6: Multiplication
    () => {
      const start = Math.floor(Math.random() * 3) + 2;
      const mult = Math.floor(Math.random() * 2) + 2;
      const sequence = [start, start * mult, start * mult * mult, start * mult * mult * mult];
      return { sequence, answer: start * mult * mult * mult * mult, rule: `×${mult} each time` };
    },
    // Level 7-9: Square numbers
    () => {
      const start = Math.floor(Math.random() * 3) + 1;
      const sequence = [start * start, (start + 1) * (start + 1), (start + 2) * (start + 2), (start + 3) * (start + 3)];
      return { sequence, answer: (start + 4) * (start + 4), rule: 'Square numbers' };
    },
    // Level 10+: Fibonacci-like
    () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const sequence = [a, b, a + b, a + b + b];
      return { sequence, answer: a + b + b + a + b + b, rule: 'Fibonacci-style (sum of previous two)' };
    },
  ];

  // Generate pattern problem based on level
  const generateProblem = useCallback((): PatternProblem => {
    const difficultyIndex = Math.min(Math.floor((level - 1) / 3), patternGenerators.length - 1);
    return patternGenerators[difficultyIndex]();
  }, [level]);

  // Start game
  const startGame = useCallback(() => {
    setGameStarted(true);
    setScore(0);
    setLevel(1);
    setGameOver(false);
    setShowResult(false);
    setIsCorrect(null);
    setCorrectAnswers(0);
    setTotalAttempts(0);
    setGameStartTime(Date.now());
    setTotalGameTime(0);
    const newProblem = patternGenerators[0]();
    setProblem(newProblem);
    setUserAnswer('');
  }, []);

  // End game and save stats
  const endGame = useCallback((finalScore: number, correct: number, total: number) => {
    // Calculate time spent
    const timeSpent = Math.round((Date.now() - gameStartTime) / 1000);
    setTotalGameTime(timeSpent);
    
    // Update high score and level
    setHighScore((prev) => Math.max(prev, finalScore));
    setHighLevel((prev) => Math.max(prev, level));
    
    // Save stats to global storage
    handlePuzzleComplete({
      gameMode: 'pattern',
      score: finalScore,
      correct: correct,
      total: total,
      timeSpent: timeSpent,
    });
    
    setGameOver(true);
  }, [level, gameStartTime, handlePuzzleComplete]);

  // Check answer
  const checkAnswer = useCallback(() => {
    if (!problem) return;
    
    const userNum = parseInt(userAnswer, 10);
    const correct = userNum === problem.answer;
    
    setIsCorrect(correct);
    setShowResult(true);
    setTotalAttempts((prev) => prev + 1);
    
    if (correct) {
      const pointsEarned = level * 10;
      const newScore = score + pointsEarned;
      setScore(newScore);
      setCorrectAnswers((prev) => prev + 1);
      setLevel((prev) => prev + 1);
      
      // Next level after delay
      setTimeout(() => {
        setShowResult(false);
        setProblem(generateProblem());
        setUserAnswer('');
      }, 1500);
    } else {
      // Game over
      setTimeout(() => {
        endGame(score, correctAnswers, totalAttempts + 1);
      }, 1500);
    }
  }, [problem, userAnswer, level, score, correctAnswers, totalAttempts, generateProblem, endGame]);

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9-]/g, '');
    setUserAnswer(value);
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userAnswer !== '') {
      checkAnswer();
    }
  };

  // Reset game
  const resetGame = () => {
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setLevel(1);
    setProblem(null);
    setUserAnswer('');
    setIsCorrect(null);
    setShowResult(false);
    setCorrectAnswers(0);
    setTotalAttempts(0);
  };

  // Get difficulty label
  const getDifficultyLabel = () => {
    if (level <= 3) return { label: 'Easy', color: 'text-green-400', bg: 'bg-green-500/20' };
    if (level <= 6) return { label: 'Medium', color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
    if (level <= 9) return { label: 'Hard', color: 'text-orange-400', bg: 'bg-orange-500/20' };
    return { label: 'Expert', color: 'text-red-400', bg: 'bg-red-500/20' };
  };

  const difficulty = getDifficultyLabel();

  // Calculate accuracy for display
  const accuracy = totalAttempts > 0 ? Math.round((correctAnswers / totalAttempts) * 100) : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-6 h-6 text-green-400" />
            <Badge className="bg-green-500/20 text-green-400">Pattern Mode</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Pattern Challenge</h1>
          <p className="text-muted-foreground mt-1">
            Find the next number in the sequence!
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => router.push('/premium/mind-puzzle/play')}
            className="border-green-500/30 text-green-400 hover:bg-green-500/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            variant="outline"
            onClick={() => router.push('/premium/mind-puzzle-advanced')}
            className="border-teal-500/30 text-teal-400 hover:bg-teal-500/10"
          >
            <Home className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-gray-900/50 border-green-500/10">
          <CardContent className="p-4 text-center">
            <Trophy className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Score</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-green-500/10">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{level}</p>
            <p className="text-xs text-muted-foreground">Level</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-green-500/10">
          <CardContent className="p-4 text-center">
            <Sparkles className={`w-6 h-6 ${difficulty.color} mx-auto mb-2`} />
            <Badge className={`${difficulty.bg} ${difficulty.color} border-0`}>
              {difficulty.label}
            </Badge>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-green-500/10">
          <CardContent className="p-4 text-center">
            <Trophy className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{highLevel}</p>
            <p className="text-xs text-muted-foreground">Best Level</p>
          </CardContent>
        </Card>
      </div>

      {/* Game Area */}
      <Card className="bg-gray-900/50 border-green-500/10">
        <CardContent className="p-8">
          {!gameStarted ? (
            // Start Screen
            <div className="text-center space-y-6">
              <div className="p-6 rounded-2xl bg-green-500/10 inline-block">
                <Target className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-foreground mb-2">Ready to Find Patterns?</h2>
                <p className="text-muted-foreground text-sm max-w-md">
                  Identify the pattern in each number sequence and find what comes next.
                  Difficulty increases as you progress!
                </p>
              </div>
              <Button
                onClick={startGame}
                size="lg"
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Game
              </Button>
            </div>
          ) : gameOver ? (
            // Game Over Screen
            <div className="text-center space-y-6">
              <div className="p-6 rounded-2xl bg-yellow-500/10 inline-block">
                <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-foreground mb-2">Game Over!</h2>
                <div className="space-y-2">
                  <p className="text-3xl font-bold text-yellow-400">{score} Points</p>
                  <p className="text-muted-foreground">
                    You reached <span className="text-green-400 font-bold">Level {level}</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    The answer was: <span className="text-green-400 font-bold">{problem?.answer}</span>
                  </p>
                  <p className="text-xs text-muted-foreground italic">
                    Pattern: {problem?.rule}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Time: {totalGameTime}s
                  </p>
                </div>
              </div>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={resetGame}
                  variant="outline"
                  className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Main Menu
                </Button>
                <Button
                  onClick={startGame}
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white"
                >
                  Play Again
                </Button>
              </div>
            </div>
          ) : showResult ? (
            // Result Display
            <div className="text-center space-y-6">
              {isCorrect ? (
                <div className="p-6 rounded-2xl bg-green-500/10 inline-block">
                  <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-green-400">
                    Correct! +{level * 10} Points
                  </h2>
                  <p className="text-muted-foreground mt-2">
                    Moving to Level {level + 1}...
                  </p>
                </div>
              ) : (
                <div className="p-6 rounded-2xl bg-red-500/10 inline-block">
                  <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-red-400">Wrong!</h2>
                  <p className="text-muted-foreground mt-2">
                    Your answer: <span className="text-red-400">{userAnswer}</span>
                  </p>
                  <p className="text-muted-foreground">
                    Correct: <span className="text-green-400 font-bold">{problem?.answer}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-2 italic">
                    Pattern: {problem?.rule}
                  </p>
                </div>
              )}
            </div>
          ) : (
            // Game Screen
            <div className="text-center space-y-6">
              {/* Level Badge */}
              <Badge className={`${difficulty.bg} ${difficulty.color} text-sm`}>
                Level {level} • {difficulty.label}
              </Badge>

              {/* Sequence Display */}
              <div className="p-6 rounded-2xl bg-green-500/10 inline-block">
                <div className="flex items-center justify-center gap-3 flex-wrap">
                  {problem?.sequence.map((num, idx) => (
                    <div
                      key={idx}
                      className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-green-500/20 border border-green-500/30 flex items-center justify-center text-xl sm:text-2xl font-bold text-green-400"
                    >
                      {num}
                    </div>
                  ))}
                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gray-700/50 border-2 border-dashed border-green-500/30 flex items-center justify-center text-xl sm:text-2xl font-bold text-muted-foreground">
                    ?
                  </div>
                </div>
              </div>

              {/* Input */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm text-muted-foreground">
                    {level * 10} points for correct answer
                  </span>
                </div>
                <Input
                  type="text"
                  value={userAnswer}
                  onChange={handleInputChange}
                  placeholder="Next number..."
                  className="text-center text-3xl bg-gray-800 border-green-500/30 focus:border-green-500 max-w-xs mx-auto"
                  autoFocus
                />
                <Button
                  type="submit"
                  disabled={userAnswer === ''}
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white"
                >
                  Submit
                </Button>
              </form>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-gray-900/50 border-green-500/10">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">Pattern Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3 rounded-lg bg-gray-800/50">
              <p className="font-medium text-foreground mb-1">Addition Pattern</p>
              <p className="text-sm text-muted-foreground">Example: 2, 4, 6, 8, ? (Answer: 10)</p>
            </div>
            <div className="p-3 rounded-lg bg-gray-800/50">
              <p className="font-medium text-foreground mb-1">Multiplication Pattern</p>
              <p className="text-sm text-muted-foreground">Example: 2, 4, 8, 16, ? (Answer: 32)</p>
            </div>
            <div className="p-3 rounded-lg bg-gray-800/50">
              <p className="font-medium text-foreground mb-1">Square Numbers</p>
              <p className="text-sm text-muted-foreground">Example: 1, 4, 9, 16, ? (Answer: 25)</p>
            </div>
            <div className="p-3 rounded-lg bg-gray-800/50">
              <p className="font-medium text-foreground mb-1">Fibonacci-style</p>
              <p className="text-sm text-muted-foreground">Example: 1, 1, 2, 3, ? (Answer: 5)</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-4">
            <strong>Tip:</strong> One wrong answer ends the game. Difficulty increases every 3 levels!
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
