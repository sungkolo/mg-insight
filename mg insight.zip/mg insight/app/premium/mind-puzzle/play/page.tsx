'use client';

import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Brain,
  Calculator,
  Pattern,
  Sparkles,
  Clock,
  Target,
  Trophy,
  ArrowRight,
} from 'lucide-react';

export default function PuzzlePlayPage() {
  const router = useRouter();

  const gameModes = [
    {
      id: 'memory',
      title: 'Memory Mode',
      description: 'Remember and recall sequences of numbers. Test your short-term memory!',
      icon: Brain,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20',
      borderColor: 'border-purple-500/30 hover:border-purple-500/50',
      stats: '5 numbers • 3 seconds',
      difficulty: 'Medium',
      href: '/premium/mind-puzzle/play/memory',
    },
    {
      id: 'math',
      title: 'Logic Math Mode',
      description: 'Solve arithmetic problems against the clock. Quick thinking required!',
      icon: Calculator,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20',
      borderColor: 'border-blue-500/30 hover:border-blue-500/50',
      stats: '10 seconds per question',
      difficulty: 'Easy',
      href: '/premium/mind-puzzle/play/math',
    },
    {
      id: 'pattern',
      title: 'Pattern Mode',
      description: 'Find the next number in the sequence. Difficulty increases each round!',
      icon: Target,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20',
      borderColor: 'border-green-500/30 hover:border-green-500/50',
      stats: 'Progressive difficulty',
      difficulty: 'Hard',
      href: '/premium/mind-puzzle/play/pattern',
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-6 h-6 text-yellow-400" />
            <Badge className="bg-yellow-500/20 text-yellow-400">Pro Feature</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Mind Puzzle Pro</h1>
          <p className="text-muted-foreground mt-1">
            Choose a game mode and challenge your brain!
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => router.push('/premium/mind-puzzle-advanced')}
          className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
        >
          Back to Overview
        </Button>
      </div>

      {/* Stats Banner */}
      <Card className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <Trophy className="w-8 h-8 text-yellow-400" />
              <div>
                <p className="text-sm text-muted-foreground">Daily Challenge</p>
                <p className="font-semibold text-foreground">Play all 3 modes to unlock bonus!</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-400">3</p>
                <p className="text-xs text-muted-foreground">Modes</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-400">∞</p>
                <p className="text-xs text-muted-foreground">Rounds</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Game Mode Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {gameModes.map((mode) => {
          const Icon = mode.icon;
          return (
            <Card
              key={mode.id}
              className={`bg-gray-900/50 ${mode.borderColor} cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg group`}
              onClick={() => router.push(mode.href)}
            >
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <div className={`p-3 rounded-xl ${mode.bgColor}`}>
                    <Icon className={`w-6 h-6 ${mode.color}`} />
                  </div>
                  <Badge 
                    variant="outline" 
                    className={
                      mode.difficulty === 'Easy' ? 'border-green-500/30 text-green-400' :
                      mode.difficulty === 'Medium' ? 'border-yellow-500/30 text-yellow-400' :
                      'border-red-500/30 text-red-400'
                    }
                  >
                    {mode.difficulty}
                  </Badge>
                </div>
                <CardTitle className="text-lg text-foreground group-hover:text-yellow-400 transition-colors">
                  {mode.title}
                </CardTitle>
                <CardDescription>
                  {mode.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>{mode.stats}</span>
                  </div>
                  <ArrowRight className={`w-5 h-5 ${mode.color} group-hover:translate-x-1 transition-transform`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Instructions */}
      <Card className="bg-gray-900/50 border-yellow-500/10">
        <CardHeader>
          <CardTitle className="text-lg text-foreground flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            How to Play
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-sm font-bold text-purple-400">1</div>
                <span className="font-medium text-foreground">Memory Mode</span>
              </div>
              <p className="text-sm text-muted-foreground pl-8">
                Memorize 5 numbers shown for 3 seconds, then recall them in order.
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-sm font-bold text-blue-400">2</div>
                <span className="font-medium text-foreground">Math Mode</span>
              </div>
              <p className="text-sm text-muted-foreground pl-8">
                Solve arithmetic problems within 10 seconds. Fast thinking wins!
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center text-sm font-bold text-green-400">3</div>
                <span className="font-medium text-foreground">Pattern Mode</span>
              </div>
              <p className="text-sm text-muted-foreground pl-8">
                Find the next number in the pattern. Difficulty increases each round.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
