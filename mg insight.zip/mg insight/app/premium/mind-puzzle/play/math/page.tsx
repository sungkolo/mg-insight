'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import {
  Calculator,
  Trophy,
  Clock,
  RotateCcw,
  ArrowLeft,
  CheckCircle,
  XCircle,
  Play,
  Zap,
  Home,
} from 'lucide-react';
import { useMindPuzzleStats } from '@/hooks/use-mind-puzzle-stats';

interface MathProblem {
  question: string;
  answer: number;
}

// Generate random math problem
function generateProblem(): MathProblem {
  const operations = ['+', '-', '×'];
  const op = operations[Math.floor(Math.random() * operations.length)];
  
  let num1: number, num2: number, answer: number;
  
  switch (op) {
    case '+':
      num1 = Math.floor(Math.random() * 50) + 1;
      num2 = Math.floor(Math.random() * 50) + 1;
      answer = num1 + num2;
      break;
    case '-':
      num1 = Math.floor(Math.random() * 50) + 10;
      num2 = Math.floor(Math.random() * num1);
      answer = num1 - num2;
      break;
    case '×':
      num1 = Math.floor(Math.random() * 12) + 1;
      num2 = Math.floor(Math.random() * 12) + 1;
      answer = num1 * num2;
      break;
    default:
      num1 = 1;
      num2 = 1;
      answer = 2;
  }
  
  return {
    question: `${num1} ${op} ${num2}`,
    answer,
  };
}

export default function MathModePage() {
  const router = useRouter();
  const { handlePuzzleComplete } = useMindPuzzleStats();
  
  // Game state
  const [problem, setProblem] = useState<MathProblem | null>(null);
  const [userAnswer, setUserAnswer] = useState<string>('');
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [timer, setTimer] = useState(10);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [highScore, setHighScore] = useState(0);
  
  // Timer tracking
  const [gameStartTime, setGameStartTime] = useState<number>(0);
  const [totalGameTime, setTotalGameTime] = useState<number>(0);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const gameActiveRef = useRef(false);

  // Timer effect
  useEffect(() => {
    if (gameStarted && !gameOver && !showResult && gameActiveRef.current) {
      timerRef.current = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            // Time's up - wrong answer
            clearInterval(timerRef.current!);
            setIsCorrect(false);
            setShowResult(true);
            setStreak(0);
            setTotalQuestions((t) => t + 1);
            
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [gameStarted, gameOver, showResult, problem]);

  // Handle timeout - move to next question
  useEffect(() => {
    if (timer === 0 && showResult && !isCorrect) {
      const timeout = setTimeout(() => {
        setShowResult(false);
        setProblem(generateProblem());
        setUserAnswer('');
        setTimer(10);
      }, 1500);
      
      return () => clearTimeout(timeout);
    }
  }, [timer, showResult, isCorrect]);

  // Start game
  const startGame = useCallback(() => {
    gameActiveRef.current = true;
    setGameStarted(true);
    setScore(0);
    setStreak(0);
    setTotalQuestions(0);
    setCorrectAnswers(0);
    setGameOver(false);
    setShowResult(false);
    setProblem(generateProblem());
    setUserAnswer('');
    setTimer(10);
    setGameStartTime(Date.now());
    setTotalGameTime(0);
  }, []);

  // End game and save stats
  const endGame = useCallback(() => {
    gameActiveRef.current = false;
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    // Calculate time spent
    const timeSpent = Math.round((Date.now() - gameStartTime) / 1000);
    setTotalGameTime(timeSpent);
    
    // Update high score
    setHighScore((prev) => Math.max(prev, score));
    
    // Save stats to global storage
    handlePuzzleComplete({
      gameMode: 'math',
      score: score,
      correct: correctAnswers,
      total: totalQuestions,
      timeSpent: timeSpent,
    });
    
    setGameOver(true);
  }, [score, correctAnswers, totalQuestions, gameStartTime, handlePuzzleComplete]);

  // Check answer
  const checkAnswer = useCallback(() => {
    if (!problem) return;
    
    gameActiveRef.current = false;
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    const userNum = parseInt(userAnswer, 10);
    const correct = userNum === problem.answer;
    
    setIsCorrect(correct);
    setShowResult(true);
    setTotalQuestions((prev) => prev + 1);
    
    if (correct) {
      setScore((prev) => prev + 5 + streak);
      setStreak((prev) => prev + 1);
      setCorrectAnswers((prev) => prev + 1);
      
      // Next question after delay
      setTimeout(() => {
        gameActiveRef.current = true;
        setShowResult(false);
        setProblem(generateProblem());
        setUserAnswer('');
        setTimer(10);
      }, 1000);
    } else {
      setStreak(0);
    }
  }, [problem, userAnswer, streak]);

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9-]/g, '');
    setUserAnswer(value);
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userAnswer !== '' && !showResult) {
      checkAnswer();
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Reset game
  const resetGame = () => {
    gameActiveRef.current = false;
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setStreak(0);
    setTotalQuestions(0);
    setCorrectAnswers(0);
    setProblem(null);
    setUserAnswer('');
    setIsCorrect(null);
    setShowResult(false);
    setTimer(10);
  };

  // Calculate accuracy for display
  const accuracy = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Calculator className="w-6 h-6 text-blue-400" />
            <Badge className="bg-blue-500/20 text-blue-400">Math Mode</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Logic Math Challenge</h1>
          <p className="text-muted-foreground mt-1">
            Solve math problems before time runs out!
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => router.push('/premium/mind-puzzle/play')}
            className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            variant="outline"
            onClick={() => router.push('/premium/mind-puzzle-advanced')}
            className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
          >
            <Home className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-gray-900/50 border-blue-500/10">
          <CardContent className="p-4 text-center">
            <Trophy className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Score</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-blue-500/10">
          <CardContent className="p-4 text-center">
            <Zap className="w-6 h-6 text-orange-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{streak}</p>
            <p className="text-xs text-muted-foreground">Streak</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-blue-500/10">
          <CardContent className="p-4 text-center">
            <CheckCircle className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{correctAnswers}/{totalQuestions}</p>
            <p className="text-xs text-muted-foreground">Correct</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-blue-500/10">
          <CardContent className="p-4 text-center">
            <Trophy className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{highScore}</p>
            <p className="text-xs text-muted-foreground">Best</p>
          </CardContent>
        </Card>
      </div>

      {/* Game Area */}
      <Card className="bg-gray-900/50 border-blue-500/10">
        <CardContent className="p-8">
          {!gameStarted ? (
            // Start Screen
            <div className="text-center space-y-6">
              <div className="p-6 rounded-2xl bg-blue-500/10 inline-block">
                <Calculator className="w-16 h-16 text-blue-400 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-foreground mb-2">Ready for Mental Math?</h2>
                <p className="text-muted-foreground text-sm max-w-md">
                  Solve as many math problems as you can within 10 seconds each. 
                  Build streaks for bonus points!
                </p>
              </div>
              <Button
                onClick={startGame}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Game
              </Button>
            </div>
          ) : gameOver ? (
            // Game Over Screen
            <div className="text-center space-y-6">
              <div className="p-6 rounded-2xl bg-yellow-500/10 inline-block">
                <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-foreground mb-2">Great Effort!</h2>
                <div className="space-y-2">
                  <p className="text-3xl font-bold text-yellow-400">{score} Points</p>
                  <p className="text-muted-foreground">
                    {correctAnswers} correct out of {totalQuestions} questions
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Accuracy: {accuracy}%
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Time: {totalGameTime}s
                  </p>
                </div>
              </div>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={resetGame}
                  variant="outline"
                  className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Main Menu
                </Button>
                <Button
                  onClick={startGame}
                  className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white"
                >
                  Play Again
                </Button>
              </div>
            </div>
          ) : showResult ? (
            // Result Display
            <div className="text-center space-y-6">
              {isCorrect ? (
                <div className="p-6 rounded-2xl bg-green-500/10 inline-block">
                  <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-green-400">
                    Correct! +{5 + Math.max(0, streak - 1)} Points
                  </h2>
                </div>
              ) : (
                <div className="p-6 rounded-2xl bg-red-500/10 inline-block">
                  <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-red-400">
                    {timer === 0 ? 'Time\'s Up!' : 'Wrong!'}
                  </h2>
                  <p className="text-muted-foreground mt-2">
                    Answer: <span className="text-blue-400 font-bold">{problem?.answer}</span>
                  </p>
                </div>
              )}
            </div>
          ) : (
            // Game Screen
            <div className="text-center space-y-6">
              {/* Timer */}
              <div className="w-full max-w-md mx-auto">
                <div className="flex items-center justify-between mb-2">
                  <Clock className={`w-5 h-5 ${timer <= 3 ? 'text-red-400 animate-pulse' : 'text-blue-400'}`} />
                  <span className={`text-sm font-bold ${timer <= 3 ? 'text-red-400' : 'text-blue-400'}`}>
                    {timer}s
                  </span>
                </div>
                <Progress 
                  value={(timer / 10) * 100} 
                  className={`h-2 ${timer <= 3 ? 'bg-red-500/20' : 'bg-blue-500/20'}`}
                />
              </div>

              {/* Question */}
              <div className="p-6 rounded-2xl bg-blue-500/10 inline-block">
                <p className="text-4xl sm:text-5xl font-bold text-foreground tracking-wider">
                  {problem?.question} = ?
                </p>
              </div>

              {/* Input */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  type="text"
                  value={userAnswer}
                  onChange={handleInputChange}
                  placeholder="Your answer..."
                  className="text-center text-3xl bg-gray-800 border-blue-500/30 focus:border-blue-500 max-w-xs mx-auto"
                  autoFocus
                />
                <Button
                  type="submit"
                  disabled={userAnswer === ''}
                  className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white"
                >
                  Submit
                </Button>
              </form>

              {/* Streak Bonus Info */}
              {streak > 0 && (
                <p className="text-sm text-yellow-400">
                  🔥 Streak Bonus: +{streak} points!
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-gray-900/50 border-blue-500/10">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">How to Play</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-muted-foreground">
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400 mt-0.5">1</div>
              <span>You have 10 seconds to answer each math problem</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400 mt-0.5">2</div>
              <span>Correct answers give +5 points plus streak bonus</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400 mt-0.5">3</div>
              <span>Build streaks for extra points!</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400 mt-0.5">4</div>
              <span>Wrong answers or timeouts reset your streak</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* End Game Button */}
      {gameStarted && !gameOver && (
        <div className="text-center">
          <Button
            variant="outline"
            onClick={endGame}
            className="border-red-500/30 text-red-400 hover:bg-red-500/10"
          >
            End Game & Save Score
          </Button>
        </div>
      )}
    </div>
  );
}
