'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Brain,
  Trophy,
  Clock,
  RotateCcw,
  ArrowLeft,
  CheckCircle,
  XCircle,
  Sparkles,
  Play,
  Home,
} from 'lucide-react';
import { useMindPuzzleStats } from '@/hooks/use-mind-puzzle-stats';

export default function MemoryModePage() {
  const router = useRouter();
  const { handlePuzzleComplete } = useMindPuzzleStats();
  
  // Game state
  const [sequence, setSequence] = useState<number[]>([]);
  const [userInput, setUserInput] = useState<string>('');
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(1);
  const [showSequence, setShowSequence] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [countdown, setCountdown] = useState(3);
  const [highScore, setHighScore] = useState(0);
  
  // Timer tracking
  const [gameStartTime, setGameStartTime] = useState<number>(0);
  const [totalGameTime, setTotalGameTime] = useState<number>(0);
  
  // Track correct answers for stats
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [totalAttempts, setTotalAttempts] = useState(0);

  // Generate new sequence
  const generateSequence = useCallback(() => {
    const newSequence: number[] = [];
    for (let i = 0; i < 5; i++) {
      newSequence.push(Math.floor(Math.random() * 9) + 1);
    }
    return newSequence;
  }, []);

  // Start new round
  const startRound = useCallback(() => {
    const newSequence = generateSequence();
    setSequence(newSequence);
    setUserInput('');
    setIsCorrect(null);
    setShowSequence(true);
    setCountdown(3);

    // Countdown timer
    let count = 3;
    const countdownInterval = setInterval(() => {
      count--;
      setCountdown(count);
      if (count <= 0) {
        clearInterval(countdownInterval);
        setShowSequence(false);
      }
    }, 1000);
  }, [generateSequence]);

  // Start game
  const startGame = useCallback(() => {
    setGameStarted(true);
    setScore(0);
    setRound(1);
    setGameOver(false);
    setCorrectAnswers(0);
    setTotalAttempts(0);
    setGameStartTime(Date.now());
    setTotalGameTime(0);
    startRound();
  }, [startRound]);

  // End game and save stats
  const endGame = useCallback((finalScore: number, correct: number, total: number) => {
    // Calculate time spent
    const timeSpent = Math.round((Date.now() - gameStartTime) / 1000);
    setTotalGameTime(timeSpent);
    
    // Update high score
    setHighScore((prev) => Math.max(prev, finalScore));
    
    // Save stats to global storage
    handlePuzzleComplete({
      gameMode: 'memory',
      score: finalScore,
      correct: correct,
      total: total,
      timeSpent: timeSpent,
    });
    
    setGameOver(true);
  }, [gameStartTime, handlePuzzleComplete]);

  // Check answer
  const checkAnswer = useCallback(() => {
    const userNumbers = userInput.split('').map(Number);
    const correct = sequence.every((num, idx) => num === userNumbers[idx]);
    
    setIsCorrect(correct);
    setTotalAttempts((prev) => prev + 1);
    
    if (correct) {
      const newScore = score + 10;
      setScore(newScore);
      setCorrectAnswers((prev) => prev + 1);
      // Next round after delay
      setTimeout(() => {
        setRound((prev) => prev + 1);
        startRound();
      }, 1500);
    } else {
      // End game on wrong answer
      endGame(score, correctAnswers, totalAttempts + 1);
    }
  }, [sequence, userInput, score, correctAnswers, totalAttempts, startRound, endGame]);

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '').slice(0, 5);
    setUserInput(value);
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userInput.length === 5) {
      checkAnswer();
    }
  };

  // Reset game
  const resetGame = () => {
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setRound(1);
    setSequence([]);
    setUserInput('');
    setIsCorrect(null);
    setCorrectAnswers(0);
    setTotalAttempts(0);
  };

  // Calculate accuracy for display
  const accuracy = totalAttempts > 0 ? Math.round((correctAnswers / totalAttempts) * 100) : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-6 h-6 text-purple-400" />
            <Badge className="bg-purple-500/20 text-purple-400">Memory Mode</Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Memory Challenge</h1>
          <p className="text-muted-foreground mt-1">
            Remember and recall the sequence of numbers!
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => router.push('/premium/mind-puzzle/play')}
            className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            variant="outline"
            onClick={() => router.push('/premium/mind-puzzle-advanced')}
            className="border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10"
          >
            <Home className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-gray-900/50 border-purple-500/10">
          <CardContent className="p-4 text-center">
            <Trophy className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{score}</p>
            <p className="text-xs text-muted-foreground">Score</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-purple-500/10">
          <CardContent className="p-4 text-center">
            <Sparkles className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{round}</p>
            <p className="text-xs text-muted-foreground">Round</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900/50 border-purple-500/10">
          <CardContent className="p-4 text-center">
            <Trophy className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-foreground">{highScore}</p>
            <p className="text-xs text-muted-foreground">Best</p>
          </CardContent>
        </Card>
      </div>

      {/* Game Area */}
      <Card className="bg-gray-900/50 border-purple-500/10">
        <CardContent className="p-8">
          {!gameStarted ? (
            // Start Screen
            <div className="text-center space-y-6">
              <div className="p-6 rounded-2xl bg-purple-500/10 inline-block">
                <Brain className="w-16 h-16 text-purple-400 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-foreground mb-2">Ready to Test Your Memory?</h2>
                <p className="text-muted-foreground text-sm max-w-md">
                  You will see 5 numbers for 3 seconds. Remember them and enter the sequence in order!
                </p>
              </div>
              <Button
                onClick={startGame}
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Game
              </Button>
            </div>
          ) : gameOver ? (
            // Game Over Screen
            <div className="text-center space-y-6">
              <div className="p-6 rounded-2xl bg-red-500/10 inline-block">
                <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-foreground mb-2">Game Over!</h2>
                <p className="text-muted-foreground mb-4">
                  The correct sequence was: <span className="text-purple-400 font-bold">{sequence.join(' ')}</span>
                </p>
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-yellow-400">Final Score: {score}</p>
                  <p className="text-sm text-muted-foreground">
                    Rounds completed: {round - 1}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Time: {totalGameTime}s
                  </p>
                </div>
              </div>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={resetGame}
                  variant="outline"
                  className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Main Menu
                </Button>
                <Button
                  onClick={startGame}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
                >
                  Play Again
                </Button>
              </div>
            </div>
          ) : showSequence ? (
            // Show Sequence
            <div className="text-center space-y-6">
              <div className="mb-4">
                <Clock className="w-8 h-8 text-yellow-400 mx-auto animate-pulse" />
                <p className="text-muted-foreground mt-2">Memorize the numbers!</p>
                <p className="text-4xl font-bold text-yellow-400">{countdown}</p>
              </div>
              <div className="flex justify-center gap-4">
                {sequence.map((num, idx) => (
                  <div
                    key={idx}
                    className="w-16 h-16 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-3xl font-bold text-purple-400 animate-pulse"
                  >
                    {num}
                  </div>
                ))}
              </div>
            </div>
          ) : isCorrect !== null ? (
            // Result Display
            <div className="text-center space-y-6">
              {isCorrect ? (
                <div className="p-6 rounded-2xl bg-green-500/10 inline-block">
                  <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-green-400">Correct! +10 Points</h2>
                  <p className="text-muted-foreground mt-2">Get ready for the next round...</p>
                </div>
              ) : (
                <div className="p-6 rounded-2xl bg-red-500/10 inline-block">
                  <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-red-400">Wrong!</h2>
                  <p className="text-muted-foreground mt-2">
                    Your answer: {userInput.split('').join(' ')}
                  </p>
                  <p className="text-muted-foreground">
                    Correct: {sequence.join(' ')}
                  </p>
                </div>
              )}
            </div>
          ) : (
            // Input Screen
            <div className="text-center space-y-6">
              <p className="text-muted-foreground">Enter the 5 numbers in order:</p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  type="text"
                  value={userInput}
                  onChange={handleInputChange}
                  placeholder="Enter 5 numbers..."
                  className="text-center text-2xl tracking-widest bg-gray-800 border-purple-500/30 focus:border-purple-500 max-w-xs mx-auto"
                  maxLength={5}
                  autoFocus
                />
                <Button
                  type="submit"
                  disabled={userInput.length !== 5}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
                >
                  Submit Answer
                </Button>
              </form>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card className="bg-gray-900/50 border-purple-500/10">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">How to Play</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-muted-foreground">
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-xs font-bold text-purple-400 mt-0.5">1</div>
              <span>5 random numbers (1-9) will appear for 3 seconds</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-xs font-bold text-purple-400 mt-0.5">2</div>
              <span>Enter the numbers in the correct order</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-xs font-bold text-purple-400 mt-0.5">3</div>
              <span>Score +10 points for each correct answer</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-xs font-bold text-purple-400 mt-0.5">4</div>
              <span>One wrong answer ends the game</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
