'use client';

import dynamic from 'next/dynamic';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import StickyBrand from '@/components/StickyBrand';
import Hero from '@/components/Hero';
import Preview from '@/components/Preview';
import HighlightValue from '@/components/HighlightValue';
import FaqSection from '@/components/FaqSection';
import MissionSection from '@/components/MissionSection';
import { ChevronRight, Sparkles, Brain } from 'lucide-react';

// Lazy load heavy interactive components for better initial load performance
const LifeMap = dynamic(() => import('@/components/LifeMap'), {
  loading: () => <SectionSkeleton />,
  ssr: false,
});

const PsychExperiment = dynamic(() => import('@/components/PsychExperiment'), {
  loading: () => <SectionSkeleton />,
  ssr: false,
});

const ProbSim = dynamic(() => import('@/components/ProbSim'), {
  loading: () => <SectionSkeleton />,
  ssr: false,
});

const MindJournal = dynamic(() => import('@/components/MindJournal'), {
  loading: () => <SectionSkeleton />,
  ssr: false,
});

const PuzzleSection = dynamic(() => import('@/components/PuzzleSection'), {
  loading: () => <SectionSkeleton />,
  ssr: false,
});

const KnowledgeGraph = dynamic(() => import('@/components/KnowledgeGraph'), {
  loading: () => <SectionSkeleton />,
  ssr: false,
});

// Skeleton loader for lazy sections
function SectionSkeleton() {
  return (
    <div className="section-padding">
      <div className="container-width">
        <div className="animate-pulse">
          <div className="h-8 w-48 bg-charcoal-800 rounded-lg mb-4 mx-auto" />
          <div className="h-4 w-96 bg-charcoal-800 rounded-lg mb-8 mx-auto" />
          <div className="h-64 bg-charcoal-800/50 rounded-xl" />
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col">
      {/* Sticky Header */}
      <StickyBrand />
      
      {/* Main Content */}
      <div className="flex-1">
        {/* Hero Section - Above the fold, load immediately */}
        <Hero />
        
        {/* Preview Carousel Section */}
        <section id="preview">
          <Preview />
        </section>
        
        {/* Mission Section - Why We're Free */}
        <MissionSection />
        
        {/* Highlight Value Section */}
        <section id="fitur">
          <HighlightValue />
        </section>
        
        {/* Life Map Interactive Section - Lazy loaded */}
        <section id="lifemap">
          <LifeMap />
        </section>
        
        {/* FAQ Section */}
        <section id="faq">
          <FaqSection />
        </section>
        
        {/* Psychology Experiment Section - Lazy loaded */}
        <PsychExperiment />
        
        {/* Probability Simulator Section - Lazy loaded */}
        <ProbSim />
        
        {/* Mind Journal Section - Lazy loaded */}
        <MindJournal />
        
        {/* Puzzle Section - Lazy loaded */}
        <PuzzleSection />
        
        {/* Knowledge Graph Section - Lazy loaded */}
        <KnowledgeGraph />
      </div>
      
      {/* Footer with CTA */}
      <footer className="relative bg-charcoal-950 border-t border-gold-500/10">
        {/* CTA Section */}
        <div className="relative py-16 sm:py-20 overflow-hidden">
          {/* Background effects */}
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-900/50 to-charcoal-950" />
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent" />
          
          {/* Floating elements */}
          <div className="absolute top-10 left-10 w-20 h-20 border border-gold-500/5 rounded-full" />
          <div className="absolute bottom-10 right-10 w-32 h-32 border border-gold-500/5 rounded-full" />
          <div className="absolute top-1/2 left-1/4 w-40 h-40 bg-gold-500/5 rounded-full blur-3xl" />
          
          <div className="container-width px-4 sm:px-6 lg:px-8 relative text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gold-500/30 bg-charcoal-900/50 mb-6">
              <Sparkles className="w-4 h-4 text-gold-500" />
              <span className="text-sm text-gold-400 font-medium">Free Forever</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 max-w-3xl mx-auto">
              <span className="text-foreground">Start Your Journey of </span>
              <span className="gradient-gold-text">Self-Discovery</span>
            </h2>
            
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
              Create a free account to save your progress, track your growth, 
              and unlock all MG Insight tools. No credit card required.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                asChild
                size="lg"
                className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold px-8 py-6 text-lg rounded-xl shadow-lg shadow-gold-500/20 hover:shadow-gold-500/40 transition-all duration-300 hover:scale-105"
              >
                <Link href="/signup">
                  <Brain className="mr-2 w-5 h-5" />
                  Create Free Account
                </Link>
              </Button>
              
              <Button 
                variant="outline"
                size="lg"
                asChild
                className="border-gold-500/30 text-gold-400 hover:bg-gold-500/10 hover:border-gold-500/50 px-8 py-6 text-lg rounded-xl transition-all duration-300"
              >
                <Link href="/login">
                  Already have an account?
                </Link>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Footer Content */}
        <div className="border-t border-gold-500/10">
          <div className="container-width px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
              {/* Brand Column */}
              <div className="md:col-span-1">
                <Link href="/" className="flex items-center gap-3 mb-4 group">
                  <div className="relative w-10 h-10">
                    <div className="absolute inset-0 gradient-gold rounded-lg rotate-45" />
                    <div className="absolute inset-1 bg-charcoal-950 rounded-md rotate-45" />
                    <Brain className="absolute inset-0 m-auto w-5 h-5 text-gold-400" />
                  </div>
                  <div>
                    <span className="font-bold text-foreground">MG Insight</span>
                    <span className="block text-[10px] text-muted-foreground tracking-widest uppercase">
                      Mind Geometry
                    </span>
                  </div>
                </Link>
                <p className="text-sm text-muted-foreground mb-4">
                  Free platform for self-discovery, clear thinking, and wiser life decisions.
                </p>
              </div>
              
              {/* Quick Links */}
              <div>
                <h4 className="font-semibold text-foreground mb-4">Tools</h4>
                <ul className="space-y-2">
                  {['Life Map', 'Mind Journal', 'Probability Sim', 'Mind Puzzle'].map((item) => (
                    <li key={item}>
                      <Link href="/#fitur" className="text-sm text-muted-foreground hover:text-gold-400 transition-colors">
                        {item}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* About */}
              <div>
                <h4 className="font-semibold text-foreground mb-4">About</h4>
                <ul className="space-y-2">
                  <li>
                    <Link 
                      href="#mission" 
                      className="text-sm text-muted-foreground hover:text-gold-400 transition-colors"
                    >
                      Our Mission
                    </Link>
                  </li>
                  <li>
                    <Link 
                      href="#faq" 
                      className="text-sm text-muted-foreground hover:text-gold-400 transition-colors"
                    >
                      FAQ
                    </Link>
                  </li>
                </ul>
              </div>
              
              {/* Account */}
              <div>
                <h4 className="font-semibold text-foreground mb-4">Account</h4>
                <ul className="space-y-2">
                  <li>
                    <Link 
                      href="/login" 
                      className="text-sm text-muted-foreground hover:text-gold-400 transition-colors"
                    >
                      Sign In
                    </Link>
                  </li>
                  <li>
                    <Link 
                      href="/signup" 
                      className="text-sm text-muted-foreground hover:text-gold-400 transition-colors"
                    >
                      Create Account
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Bottom Bar */}
            <div className="mt-12 pt-8 border-t border-gold-500/10 flex flex-col sm:flex-row justify-between items-center gap-4">
              <p className="text-sm text-muted-foreground">
                © 2026 MG Insight. All rights reserved.
              </p>
              <div className="flex items-center gap-6">
                {['Privacy', 'Terms', 'Cookies'].map((item) => (
                  <Link
                    key={item}
                    href="#"
                    className="text-sm text-muted-foreground hover:text-gold-400 transition-colors"
                  >
                    {item}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
