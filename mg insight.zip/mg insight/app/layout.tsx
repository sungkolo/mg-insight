import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import GoogleAnalytics from "@/components/GoogleAnalytics";
import { AuthProvider } from "@/components/AuthProvider";
import { LanguageProvider } from "@/context/language-context";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MG Insight | Mind Geometry - Transformasi Pikiran Mendalam",
  description: "MG Insight adalah platform analisis psikologi dan pengembangan diri premium. Temukan pemahaman mendalam tentang pola pikir, perilaku, dan potensi diri Anda melalui teknologi Mind Geometry.",
  keywords: ["MG Insight", "Mind Geometry", "psikologi", "pengembangan diri", "analisis pikiran", "self-improvement", "mindfulness"],
  authors: [{ name: "MG Insight Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "MG Insight | Mind Geometry",
    description: "Transformasi Pikiran Mendalam dengan Mind Geometry",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "MG Insight | Mind Geometry",
    description: "Transformasi Pikiran Mendalam dengan Mind Geometry",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="dark scroll-smooth" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {/* Google Analytics - Set NEXT_PUBLIC_GA_ID in .env */}
        <GoogleAnalytics />
        <AuthProvider>
          <LanguageProvider>
            {children}
          </LanguageProvider>
        </AuthProvider>
        <Toaster />
      </body>
    </html>
  );
}
