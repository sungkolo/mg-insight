import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// All features are now free - this endpoint returns user status
export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ 
        isAuthenticated: false,
        hasAccess: false,
        message: 'Sign in to access all free tools'
      });
    }

    // All logged-in users have full access (all features are free)
    return NextResponse.json({
      isAuthenticated: true,
      hasAccess: true,
      freeAccess: true,
      user: {
        email: session.user.email,
        name: session.user.name,
      },
      message: 'All features are free for registered users',
    });
  } catch (error) {
    console.error('Error checking access status:', error);
    return NextResponse.json({ 
      isAuthenticated: false,
      hasAccess: false 
    });
  }
}
