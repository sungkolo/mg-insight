import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

// GET - Fetch a single journal entry by ID
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;

    // Check authentication - all logged-in users can access
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to view journals' },
        { status: 401 }
      );
    }

    // Fetch the journal - no premium check required
    const journal = await db.journal.findUnique({
      where: { id },
    });

    if (!journal) {
      return NextResponse.json(
        { success: false, error: 'Journal not found', message: 'The requested journal entry does not exist' },
        { status: 404 }
      );
    }

    // Check ownership - users can only access their own journals
    if (journal.userId !== session.user.id) {
      return NextResponse.json(
        { success: false, error: 'Forbidden', message: 'You can only access your own journals' },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      journal,
    });

  } catch (error) {
    console.error('[JOURNAL_GET_ONE_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to fetch journal' },
      { status: 500 }
    );
  }
}

// PUT - Update a journal entry
export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;

    // Check authentication - all logged-in users can update
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to update journals' },
        { status: 401 }
      );
    }

    // Check ownership - no premium check required
    const existingJournal = await db.journal.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!existingJournal) {
      return NextResponse.json(
        { success: false, error: 'Journal not found', message: 'The requested journal entry does not exist' },
        { status: 404 }
      );
    }

    if (existingJournal.userId !== session.user.id) {
      return NextResponse.json(
        { success: false, error: 'Forbidden', message: 'You can only update your own journals' },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await req.json();
    const { title, content, mood, tags } = body;

    // Validate required fields
    if (title !== undefined && !title.trim()) {
      return NextResponse.json(
        { success: false, error: 'Validation error', message: 'Title cannot be empty' },
        { status: 400 }
      );
    }

    if (content !== undefined && !content.trim()) {
      return NextResponse.json(
        { success: false, error: 'Validation error', message: 'Content cannot be empty' },
        { status: 400 }
      );
    }

    // Calculate mood score from mood string
    const moodScores: Record<string, number> = {
      happy: 10,
      grateful: 9,
      inspired: 9,
      productive: 8,
      calm: 7,
      thoughtful: 6,
      neutral: 5,
      anxious: 3,
      stressed: 3,
      sad: 2,
    };
    const moodScore = mood ? (moodScores[mood.toLowerCase()] ?? 5) : undefined;

    // Update journal
    const updatedJournal = await db.journal.update({
      where: { id },
      data: {
        title: title?.trim(),
        content: content?.trim(),
        mood,
        moodScore,
        tags,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Journal entry updated successfully',
      journal: updatedJournal,
    });

  } catch (error) {
    console.error('[JOURNAL_PUT_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to update journal' },
      { status: 500 }
    );
  }
}

// DELETE - Delete a single journal entry by ID
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    const { id } = await params;

    // Check authentication - all logged-in users can delete
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to delete journals' },
        { status: 401 }
      );
    }

    // Check ownership - no premium check required
    const existingJournal = await db.journal.findUnique({
      where: { id },
      select: { userId: true },
    });

    if (!existingJournal) {
      return NextResponse.json(
        { success: false, error: 'Journal not found', message: 'The requested journal entry does not exist' },
        { status: 404 }
      );
    }

    if (existingJournal.userId !== session.user.id) {
      return NextResponse.json(
        { success: false, error: 'Forbidden', message: 'You can only delete your own journals' },
        { status: 403 }
      );
    }

    // Delete the journal
    await db.journal.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: 'Journal entry deleted successfully',
    });

  } catch (error) {
    console.error('[JOURNAL_DELETE_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to delete journal' },
      { status: 500 }
    );
  }
}
