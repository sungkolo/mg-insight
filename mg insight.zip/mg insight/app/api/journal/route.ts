import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

// GET - Fetch all journals for the authenticated user
export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    // Check authentication - all logged-in users can access
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to access journals' },
        { status: 401 }
      );
    }

    // Fetch journals for the user - no premium check required
    const journals = await db.journal.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        content: true,
        mood: true,
        tags: true,
        aiSummary: true,
        aiEmotion: true,
        aiAdvice: true,
        aiInsight: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    return NextResponse.json({
      success: true,
      journals,
      count: journals.length,
    });

  } catch (error) {
    console.error('[JOURNAL_GET_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to fetch journals' },
      { status: 500 }
    );
  }
}

// POST - Create a new journal entry
export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);

    // Check authentication - all logged-in users can create journals
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to create journals' },
        { status: 401 }
      );
    }

    // Parse request body
    const body = await req.json();
    const { title, content, mood, moodScore, tags } = body;

    // Validate required fields
    if (!title || !title.trim()) {
      return NextResponse.json(
        { success: false, error: 'Validation error', message: 'Title is required' },
        { status: 400 }
      );
    }

    if (!content || !content.trim()) {
      return NextResponse.json(
        { success: false, error: 'Validation error', message: 'Content is required' },
        { status: 400 }
      );
    }

    // Generate AI insight based on content (simple version)
    const aiInsight = generateAIInsight(content, mood);

    // Create journal entry - moodScore uses database default (5)
    const journal = await db.journal.create({
      data: {
        title: title.trim(),
        content: content.trim(),
        mood: mood || 'neutral',
        tags: tags || null,
        aiInsight,
        userId: session.user.id,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Journal entry saved successfully',
      journal,
    });

  } catch (error) {
    console.error('[JOURNAL_POST_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to create journal' },
      { status: 500 }
    );
  }
}

// DELETE - Delete a journal entry
export async function DELETE(req: Request) {
  try {
    const session = await getServerSession(authOptions);

    // Check authentication - all logged-in users can delete their journals
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to delete journals' },
        { status: 401 }
      );
    }

    // Get journal ID from URL
    const { searchParams } = new URL(req.url);
    const journalId = searchParams.get('id');

    if (!journalId) {
      return NextResponse.json(
        { success: false, error: 'Validation error', message: 'Journal ID is required' },
        { status: 400 }
      );
    }

    // Check if journal belongs to the user
    const existingJournal = await db.journal.findUnique({
      where: { id: journalId },
      select: { userId: true },
    });

    if (!existingJournal) {
      return NextResponse.json(
        { success: false, error: 'Not found', message: 'Journal entry not found' },
        { status: 404 }
      );
    }

    if (existingJournal.userId !== session.user.id) {
      return NextResponse.json(
        { success: false, error: 'Forbidden', message: 'You can only delete your own journals' },
        { status: 403 }
      );
    }

    // Delete the journal
    await db.journal.delete({
      where: { id: journalId },
    });

    return NextResponse.json({
      success: true,
      message: 'Journal entry deleted successfully',
    });

  } catch (error) {
    console.error('[JOURNAL_DELETE_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to delete journal' },
      { status: 500 }
    );
  }
}

// Helper function to calculate mood score from mood string
function calculateMoodScore(mood?: string): number {
  const moodScores: Record<string, number> = {
    happy: 10,
    grateful: 9,
    inspired: 9,
    productive: 8,
    calm: 7,
    thoughtful: 6,
    neutral: 5,
    anxious: 3,
    stressed: 3,
    sad: 2,
  };

  return moodScores[mood?.toLowerCase() || 'neutral'] ?? 5;
}

// Helper function to generate AI insights
function generateAIInsight(content: string, mood?: string): string {
  const insights: Record<string, string[]> = {
    happy: [
      'Your positive energy is contagious! Keep nurturing what brings you joy.',
      'Great moments deserve to be celebrated. Consider sharing this with someone you care about.',
      'Your happiness today contributes to your overall well-being. Keep up the positive mindset!',
    ],
    productive: [
      'Your productivity patterns show peak performance. Consider replicating today\'s approach.',
      'Achievement unlocked! Your focus and dedication are paying off.',
      'Your structured approach is working well. Consider documenting your methods for future reference.',
    ],
    thoughtful: [
      'Reflection is a powerful tool for growth. Your introspection is valuable.',
      'Taking time to think deeply shows emotional intelligence. Continue exploring these thoughts.',
      'Your thoughtfulness today indicates a growth mindset. Keep questioning and learning.',
    ],
    neutral: [
      'A balanced state of mind. Consider what activities bring you the most fulfillment.',
      'Neutral days are opportunities for self-discovery. What would make today memorable?',
      'Use this calm moment to set intentions for your next chapter.',
    ],
    sad: [
      'Remember that all emotions are temporary. Be gentle with yourself today.',
      'Writing about difficult feelings is a healthy coping mechanism. You\'re doing great.',
      'Consider reaching out to someone you trust. Connection often helps during tough times.',
    ],
    anxious: [
      'Deep breathing exercises can help manage anxiety. Try the 4-7-8 technique.',
      'Your feelings are valid. Breaking tasks into smaller steps can reduce overwhelm.',
      'Grounding techniques like naming 5 things you see can help center your thoughts.',
    ],
    stressed: [
      'Identify what\'s within your control and focus there. Let go of what you cannot change.',
      'Self-care isn\'t selfish. Consider taking a short break to recharge.',
      'Progress over perfection. You\'re handling more than you realize.',
    ],
    grateful: [
      'Gratitude practices boost overall happiness. You\'re building a positive habit!',
      'Noticing the good in life enhances well-being. Keep cultivating thankfulness.',
      'Your appreciation mindset is powerful. Consider making this a daily practice.',
    ],
  };

  // Get mood-specific insights or use neutral
  const moodInsights = insights[mood?.toLowerCase() || 'neutral'] || insights.neutral;
  
  // Return a random insight from the mood category
  return moodInsights[Math.floor(Math.random() * moodInsights.length)];
}
