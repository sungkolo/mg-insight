import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Initialize ZAI client (SDK handles API internally)
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAIClient() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// POST - Generate AI insights for a journal entry
export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);

    // Check authentication - all logged-in users can generate AI insights
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to generate insights' },
        { status: 401 }
      );
    }

    // Parse request body
    const body = await req.json();
    const { journalId } = body;

    if (!journalId) {
      return NextResponse.json(
        { success: false, error: 'Validation error', message: 'Journal ID is required' },
        { status: 400 }
      );
    }

    // Fetch the journal
    const journal = await db.journal.findUnique({
      where: { id: journalId },
    });

    if (!journal) {
      return NextResponse.json(
        { success: false, error: 'Not found', message: 'Journal entry not found' },
        { status: 404 }
      );
    }

    // Check ownership - security: users can only generate insights for their own journals
    if (journal.userId !== session.user.id) {
      return NextResponse.json(
        { success: false, error: 'Forbidden', message: 'You can only generate insights for your own journals' },
        { status: 403 }
      );
    }

    let aiSummary: string;
    let aiEmotion: string;
    let aiAdvice: string;

    try {
      // Use z-ai-web-dev-sdk for AI-powered insights (server-side only)
      const zai = await getZAIClient();

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: `You are a compassionate psychological insight assistant. Analyze journal entries and provide helpful, supportive insights.
              
Your response must be formatted exactly like this:
SUMMARY: [A brief 1-2 sentence summary of the main themes]
EMOTION: [The primary emotional pattern detected, with a brief explanation]
ADVICE: [One practical, actionable piece of advice for personal growth]

Keep each section concise but meaningful. Be empathetic and constructive.`,
          },
          {
            role: 'user',
            content: `Analyze this journal entry:

Title: "${journal.title}"
Content: "${journal.content}"
Mood: ${journal.mood || 'Not specified'}

Provide a summary, emotional analysis, and growth advice.`,
          },
        ],
        thinking: { type: 'disabled' }
      });

      const aiText = completion.choices[0]?.message?.content || '';

      // Parse the response with flexible regex patterns
      const summaryMatch = aiText.match(/SUMMARY:\s*(.+?)(?=\nEMOTION:|$)/s);
      const emotionMatch = aiText.match(/EMOTION:\s*(.+?)(?=\nADVICE:|$)/s);
      const adviceMatch = aiText.match(/ADVICE:\s*(.+?)$/s);

      aiSummary = summaryMatch?.[1]?.trim() || 'Unable to generate summary';
      aiEmotion = emotionMatch?.[1]?.trim() || 'Unable to detect emotional pattern';
      aiAdvice = adviceMatch?.[1]?.trim() || 'Unable to generate advice';

    } catch (aiError) {
      console.error('[AI_SDK_ERROR]', aiError);
      
      // Fallback to local insights on AI error
      const localInsights = generateLocalInsights(journal.content, journal.mood);
      aiSummary = localInsights.summary;
      aiEmotion = localInsights.emotion;
      aiAdvice = localInsights.advice;
    }

    // Update journal with AI insights in database
    const updatedJournal = await db.journal.update({
      where: { id: journalId },
      data: {
        aiSummary,
        aiEmotion,
        aiAdvice,
        aiInsight: `${aiSummary}\n\n${aiEmotion}\n\n${aiAdvice}`, // Legacy field for backward compatibility
      },
    });

    return NextResponse.json({
      success: true,
      message: 'AI insights generated successfully',
      insights: {
        summary: aiSummary,
        emotion: aiEmotion,
        advice: aiAdvice,
      },
      journal: updatedJournal,
    });

  } catch (error) {
    console.error('[JOURNAL_INSIGHT_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to generate insights' },
      { status: 500 }
    );
  }
}

// Local insights generator (fallback when AI SDK is unavailable)
function generateLocalInsights(content: string, mood: string | null): {
  summary: string;
  emotion: string;
  advice: string;
} {
  const contentLower = content.toLowerCase();
  const wordCount = content.split(/\s+/).length;

  // Detect themes from content
  const themes: string[] = [];
  if (contentLower.includes('work') || contentLower.includes('job') || contentLower.includes('career')) {
    themes.push('career');
  }
  if (contentLower.includes('family') || contentLower.includes('friend') || contentLower.includes('relationship')) {
    themes.push('relationships');
  }
  if (contentLower.includes('goal') || contentLower.includes('plan') || contentLower.includes('future')) {
    themes.push('future planning');
  }
  if (contentLower.includes('health') || contentLower.includes('exercise') || contentLower.includes('sleep')) {
    themes.push('wellness');
  }
  if (contentLower.includes('money') || contentLower.includes('finance') || contentLower.includes('budget')) {
    themes.push('finances');
  }

  // Mood-based insights
  const moodInsights: Record<string, { emotion: string; advice: string }> = {
    happy: {
      emotion: 'Your entry radiates positive energy and joy. This is a wonderful state that reflects healthy emotional well-being.',
      advice: 'Consider documenting what specifically contributed to this positive mood - these triggers can help you recreate similar feelings in the future.',
    },
    productive: {
      emotion: 'You\'re in an achievement-oriented mindset, showing motivation and focus on your goals.',
      advice: 'Channel this productive energy into your most important tasks. Consider breaking larger goals into smaller milestones to maintain momentum.',
    },
    grateful: {
      emotion: 'Your entry shows appreciation and thankfulness, which is linked to increased happiness and life satisfaction.',
      advice: 'Continue practicing gratitude by noting three things you\'re thankful for each day. This habit can significantly boost your overall well-being.',
    },
    thoughtful: {
      emotion: 'You\'re in a reflective state, processing experiences and ideas deeply. This shows emotional intelligence and self-awareness.',
      advice: 'Journaling regularly during thoughtful periods can help crystallize insights. Consider what actions might emerge from your reflections.',
    },
    neutral: {
      emotion: 'Your emotional state appears balanced and calm. This neutral space can be good for objective decision-making.',
      advice: 'Use this balanced state to assess different areas of your life objectively. What small improvements could make a big difference?',
    },
    anxious: {
      emotion: 'There are signs of worry or unease in your entry. Anxiety often stems from uncertainty about future events.',
      advice: 'Try the 4-7-8 breathing technique: inhale for 4 seconds, hold for 7, exhale for 8. Also, identify what\'s within your control versus what isn\'t.',
    },
    stressed: {
      emotion: 'You seem to be experiencing pressure or overwhelm. Stress can impact both mental and physical health.',
      advice: 'Prioritize self-care and consider delegating tasks where possible. Even a 5-minute break can help reset your stress levels.',
    },
    sad: {
      emotion: 'Your entry reflects feelings of sadness or melancholy. Remember that all emotions are temporary and valid.',
      advice: 'Allow yourself to feel this emotion without judgment. Consider reaching out to someone you trust, and engage in activities that usually bring you comfort.',
    },
    calm: {
      emotion: 'You\'re experiencing a peaceful, centered state. This emotional equilibrium is valuable for clear thinking.',
      advice: 'Notice what contributed to this calm state and consider making it a regular part of your routine. This is an excellent time for important decisions.',
    },
    inspired: {
      emotion: 'Your entry shows enthusiasm and creative energy. Inspiration is a powerful motivator for positive change.',
      advice: 'Capture this inspired energy by taking immediate action on your ideas. Break them into small steps to maintain momentum.',
    },
  };

  const moodInsight = moodInsights[mood?.toLowerCase() || 'neutral'] || moodInsights.neutral;

  // Generate summary based on content and themes
  let summary = `Your journal entry explores ${wordCount} words`;
  if (themes.length > 0) {
    summary += ` touching on themes of ${themes.join(', ')}`;
  }
  summary += `. ${mood ? `Your mood of "${mood}" sets the emotional tone.` : ''}`;

  return {
    summary,
    emotion: moodInsight.emotion,
    advice: moodInsight.advice,
  };
}
