import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { NextResponse } from 'next/server';

// All features are now free - this endpoint is kept for backwards compatibility
// but no longer performs any upgrade action
export async function POST() {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Unauthorized',
          message: 'Please sign in to access your account' 
        },
        { status: 401 }
      );
    }

    // All features are now free for all registered users
    return NextResponse.json({
      success: true,
      message: 'All features are now free! No upgrade needed.',
      freeAccess: true,
    });

  } catch (error) {
    console.error('[UPGRADE_API_ERROR]', error);
    
    return NextResponse.json(
      { 
        success: false,
        error: 'Internal server error',
        message: 'An unexpected error occurred. Please try again later.' 
      },
      { status: 500 }
    );
  }
}
