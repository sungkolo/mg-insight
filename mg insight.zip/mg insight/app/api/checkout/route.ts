import { NextResponse } from 'next/server';

// All features are now free - payment is no longer required
// This endpoint is kept for backwards compatibility
export async function POST() {
  return NextResponse.json({
    success: true,
    message: 'All features are now free! No payment required.',
    freeAccess: true,
    redirect: '/premium',
  });
}
