import { NextResponse } from 'next/server';

// All features are now free - Stripe webhooks are no longer needed
// This endpoint is kept for backwards compatibility
export async function POST() {
  return NextResponse.json({
    received: true,
    message: 'All features are now free. No payment processing needed.',
  });
}
