import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// All features are now free - this endpoint is kept for backwards compatibility
// No longer performs any upgrade action
export async function POST() {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // All features are now free for all registered users
    return NextResponse.json({
      success: true,
      message: 'All features are now free! No upgrade needed.',
      freeAccess: true,
    });
  } catch (error) {
    console.error('Demo upgrade error:', error);
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    );
  }
}
