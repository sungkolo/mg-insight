import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

// GET - Fetch advanced analytics for the authenticated premium user
export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    // Check authentication
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to access analytics' },
        { status: 401 }
      );
    }

    // Check premium status
    if (session.user.role !== 'premium') {
      return NextResponse.json(
        { success: false, error: 'Premium required', message: 'Analytics are available for Premium members only' },
        { status: 403 }
      );
    }

    const now = new Date();

    // This week: last 7 days
    const thisWeekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    thisWeekStart.setHours(0, 0, 0, 0);

    // Last week: 7-14 days ago
    const lastWeekStart = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
    lastWeekStart.setHours(0, 0, 0, 0);

    // Fetch journals for this week
    const thisWeekJournals = await db.journal.findMany({
      where: {
        userId: session.user.id,
        createdAt: {
          gte: thisWeekStart,
        },
      },
      select: {
        moodScore: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
    });

    // Fetch journals for last week
    const lastWeekJournals = await db.journal.findMany({
      where: {
        userId: session.user.id,
        createdAt: {
          gte: lastWeekStart,
          lt: thisWeekStart,
        },
      },
      select: {
        moodScore: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
    });

    // Calculate this week stats - use null if no data
    const avgThisWeek: number | null = thisWeekJournals.length > 0
      ? Math.round((thisWeekJournals.reduce((sum, j) => sum + j.moodScore, 0) / thisWeekJournals.length) * 10) / 10
      : null;

    // Calculate last week stats - use null if no data
    const avgLastWeek: number | null = lastWeekJournals.length > 0
      ? Math.round((lastWeekJournals.reduce((sum, j) => sum + j.moodScore, 0) / lastWeekJournals.length) * 10) / 10
      : null;

    // Calculate percentage change - EXPLICIT NULL CHECKING
    // If avgLastWeek is null, percentageChange must be null (not 0)
    let percentageChange: number | null = null;

    if (avgLastWeek !== null && avgThisWeek !== null) {
      percentageChange = Math.round(((avgThisWeek - avgLastWeek) / avgLastWeek) * 100);
    }

    // Calculate consistency (days with entries this week)
    const daysWithEntries = new Set(
      thisWeekJournals.map(j => new Date(j.createdAt).toDateString())
    );
    const consistency = daysWithEntries.size;

    // Get consistency label
    const getConsistencyLabel = (days: number): string => {
      if (days <= 2) return 'Low';
      if (days <= 5) return 'Moderate';
      return 'Strong';
    };

    // Find highest and lowest mood days
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const fullDayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dailyScores: Record<string, { total: number; count: number }> = {};

    thisWeekJournals.forEach(j => {
      const dayName = fullDayNames[new Date(j.createdAt).getDay()];
      if (!dailyScores[dayName]) {
        dailyScores[dayName] = { total: 0, count: 0 };
      }
      dailyScores[dayName].total += j.moodScore;
      dailyScores[dayName].count += 1;
    });

    let highestMoodDay: string | null = null;
    let lowestMoodDay: string | null = null;
    let highestAvg = 0;
    let lowestAvg = 11;

    Object.entries(dailyScores).forEach(([day, data]) => {
      const avg = data.total / data.count;
      if (avg > highestAvg) {
        highestAvg = avg;
        highestMoodDay = day;
      }
      if (avg < lowestAvg) {
        lowestAvg = avg;
        lowestMoodDay = day;
      }
    });

    // If only one day with data, lowest = highest
    if (Object.keys(dailyScores).length === 1) {
      lowestMoodDay = highestMoodDay;
    }

    // Generate weekly data for mini chart (7 days)
    const weeklyData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dayKey = date.toISOString().split('T')[0];
      const dayName = dayNames[date.getDay()];

      // Get entries for this specific day
      const dayEntries = thisWeekJournals.filter(j => {
        const journalDate = new Date(j.createdAt).toISOString().split('T')[0];
        return journalDate === dayKey;
      });

      const avgMood = dayEntries.length > 0
        ? Math.round((dayEntries.reduce((sum, j) => sum + j.moodScore, 0) / dayEntries.length) * 10) / 10
        : null;

      weeklyData.push({
        day: dayName,
        mood: avgMood,
        entries: dayEntries.length,
      });
    }

    // Generate insight
    const insights: string[] = [];

    // Trend insight
    if (percentageChange !== null) {
      if (percentageChange > 0) {
        insights.push(`Your emotional state improved compared to last week. Keep maintaining this consistency.`);
      } else if (percentageChange < 0) {
        insights.push(`Your mood has declined compared to last week. Consider reviewing your routines.`);
      } else {
        insights.push(`Your mood is stable compared to last week.`);
      }
    } else if (avgThisWeek !== null) {
      insights.push(`No comparison data available from last week.`);
    }

    // Consistency insight
    if (consistency >= 5) {
      insights.push(`Strong journaling consistency detected. This improves emotional clarity.`);
    } else if (consistency < 3 && thisWeekJournals.length > 0) {
      insights.push(`Low journaling consistency. Try writing at least once per day.`);
    }

    // Overall mood insight
    if (avgThisWeek !== null) {
      if (avgThisWeek >= 7) {
        insights.push(`Overall, your emotional state has been positive this week.`);
      } else if (avgThisWeek >= 4) {
        insights.push(`Your mood has been balanced this week.`);
      } else {
        insights.push(`Your mood has been lower this week. Consider activities that bring you joy.`);
      }
    }

    const insight = insights.length > 0
      ? insights.join(' ')
      : 'Not enough journal data to generate insights.';

    return NextResponse.json({
      success: true,
      avgThisWeek,
      avgLastWeek,
      percentageChange,
      highestMoodDay,
      lowestMoodDay,
      consistency,
      consistencyLabel: getConsistencyLabel(consistency),
      weeklyData,
      totalEntriesThisWeek: thisWeekJournals.length,
      totalEntriesLastWeek: lastWeekJournals.length,
      insight,
      hasData: thisWeekJournals.length > 0,
    });

  } catch (error) {
    console.error('[ADVANCED_ANALYTICS_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}
