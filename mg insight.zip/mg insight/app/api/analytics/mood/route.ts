import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

// GET - Fetch weekly mood analytics for the authenticated premium user
export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    // Check authentication
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', message: 'Please sign in to access analytics' },
        { status: 401 }
      );
    }

    // Check premium status
    if (session.user.role !== 'premium') {
      return NextResponse.json(
        { success: false, error: 'Premium required', message: 'Analytics are available for Premium members only' },
        { status: 403 }
      );
    }

    // Get date range for last 7 days
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    // Set to start of day
    sevenDaysAgo.setHours(0, 0, 0, 0);

    // Fetch journals from the last 7 days
    const journals = await db.journal.findMany({
      where: {
        userId: session.user.id,
        createdAt: {
          gte: sevenDaysAgo,
        },
      },
      select: {
        moodScore: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
    });

    // Day names mapping
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    // Group journals by day
    const dailyMoodScores: Record<string, { total: number; count: number }> = {};
    
    journals.forEach((journal) => {
      const date = new Date(journal.createdAt);
      const dayKey = date.toISOString().split('T')[0]; // YYYY-MM-DD format
      
      if (!dailyMoodScores[dayKey]) {
        dailyMoodScores[dayKey] = { total: 0, count: 0 };
      }
      
      dailyMoodScores[dayKey].total += journal.moodScore;
      dailyMoodScores[dayKey].count += 1;
    });

    // Generate weekly data for last 7 days (always return 7 days)
    const weeklyData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dayKey = date.toISOString().split('T')[0];
      const dayName = dayNames[date.getDay()];
      
      const dayData = dailyMoodScores[dayKey];
      const avgMood = dayData && dayData.count > 0 
        ? Math.round(dayData.total / dayData.count) 
        : 0;
      
      weeklyData.push({
        day: dayName,
        date: dayKey,
        mood: avgMood,
        entries: dayData?.count || 0,
      });
    }

    // Calculate overall stats
    const totalEntries = journals.length;
    const totalScore = journals.reduce((sum, j) => sum + j.moodScore, 0);
    const avgMoodScore = totalEntries > 0 ? Math.round(totalScore / totalEntries) : 0;

    return NextResponse.json({
      success: true,
      weeklyData,
      stats: {
        totalEntries,
        avgMoodScore,
        hasData: totalEntries > 0,
      },
    });

  } catch (error) {
    console.error('[MOOD_ANALYTICS_ERROR]', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error', message: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}
