'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import StickyBrand from '@/components/StickyBrand';
import { Sparkles, CheckCircle, ChevronRight } from 'lucide-react';

// This page is kept for backwards compatibility but now shows that all features are free
export default function CancelPage() {
  return (
    <main className="min-h-screen flex flex-col bg-charcoal-950">
      <StickyBrand />

      <div className="flex-1 flex items-center justify-center py-16 px-4">
        {/* Background Effects */}
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-gold-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 w-full max-w-md">
          <Card className="bg-charcoal-900/50 border-gold-500/20 backdrop-blur-sm text-center">
            <CardHeader>
              <div className="w-16 h-16 rounded-full bg-gold-500/10 border border-gold-500/20 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-gold-400" />
              </div>
              <CardTitle className="text-2xl text-foreground">
                <span className="gradient-gold-text">All Features Are Free!</span>
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                No payment needed. MG Insight is now 100% free for all registered users.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Create a free account to access all tools including Life Map, Mind Journal, 
                Probability Simulator, and Mind Puzzle.
              </p>

              {/* Benefits */}
              <div className="space-y-3 mb-6 text-left">
                {[
                  'All tools are 100% free',
                  'No subscription required',
                  'Your data stays private',
                  'Access all features immediately',
                ].map((benefit) => (
                  <div key={benefit} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    <span className="text-foreground">{benefit}</span>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <Link href="/premium" className="block">
                  <Button className="w-full bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold py-6 rounded-xl shadow-lg shadow-gold-500/20">
                    <Sparkles className="mr-2 h-5 w-5" />
                    Go to Dashboard
                    <ChevronRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>

                <Link href="/" className="block">
                  <Button variant="outline" className="w-full border-gold-500/30 text-gold-400 hover:bg-gold-500/10 py-6 rounded-xl">
                    Back to Home
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-charcoal-950 border-t border-gold-500/10 py-6">
        <div className="container-width px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm text-muted-foreground">
            © 2026 MG Insight. All rights reserved.
          </p>
        </div>
      </footer>
    </main>
  );
}
