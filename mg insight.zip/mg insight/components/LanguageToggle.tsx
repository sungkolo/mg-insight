'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/context/language-context';
import { Button } from '@/components/ui/button';

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-1 p-1 rounded-lg bg-zinc-800/50 border border-zinc-700/50">
      <button
        onClick={() => setLanguage('id')}
        className={`relative px-2 py-1 rounded-md text-sm font-medium transition-colors ${
          language === 'id'
            ? 'text-white'
            : 'text-zinc-500 hover:text-zinc-300'
        }`}
      >
        <AnimatePresence mode="wait">
          {language === 'id' && (
            <motion.div
              layoutId="language-indicator"
              className="absolute inset-0 bg-gold-500/20 rounded-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            />
          )}
        </AnimatePresence>
        <span className="relative z-10 flex items-center gap-1">
          <span>🇮🇩</span>
          <span>ID</span>
        </span>
      </button>
      
      <span className="text-zinc-600">|</span>
      
      <button
        onClick={() => setLanguage('en')}
        className={`relative px-2 py-1 rounded-md text-sm font-medium transition-colors ${
          language === 'en'
            ? 'text-white'
            : 'text-zinc-500 hover:text-zinc-300'
        }`}
      >
        <AnimatePresence mode="wait">
          {language === 'en' && (
            <motion.div
              layoutId="language-indicator"
              className="absolute inset-0 bg-gold-500/20 rounded-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            />
          )}
        </AnimatePresence>
        <span className="relative z-10 flex items-center gap-1">
          <span>🇺🇸</span>
          <span>EN</span>
        </span>
      </button>
    </div>
  );
}

// Compact version for mobile or smaller spaces
export function LanguageToggleCompact() {
  const { language, toggleLanguage } = useLanguage();

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleLanguage}
      className="h-8 px-2 text-zinc-400 hover:text-white"
    >
      <motion.span
        key={language}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.15 }}
        className="flex items-center gap-1"
      >
        {language === 'id' ? (
          <>
            <span>🇮🇩</span>
            <span className="text-xs">ID</span>
          </>
        ) : (
          <>
            <span>🇺🇸</span>
            <span className="text-xs">EN</span>
          </>
        )}
      </motion.span>
    </Button>
  );
}
