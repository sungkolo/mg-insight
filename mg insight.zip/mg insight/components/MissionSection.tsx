'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Heart, 
  Brain, 
  Sparkles, 
  Users, 
  Globe, 
  Lightbulb,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';

export default function MissionSection() {
  const values = [
    {
      icon: Brain,
      title: 'Self-Awareness',
      description: 'Develop a deeper understanding of your thoughts, emotions, and behaviors.',
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20',
    },
    {
      icon: Lightbulb,
      title: 'Clear Thinking',
      description: 'Sharpen your decision-making with structured analytical tools.',
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/20',
    },
    {
      icon: Heart,
      title: 'Wiser Decisions',
      description: 'Make life choices aligned with your values and long-term goals.',
      color: 'text-rose-400',
      bgColor: 'bg-rose-500/20',
    },
    {
      icon: Users,
      title: 'Personal Growth',
      description: 'Track your progress and evolve continuously as a person.',
      color: 'text-green-400',
      bgColor: 'bg-green-500/20',
    },
  ];

  const benefits = [
    'All tools are 100% free',
    'No premium subscriptions',
    'Your data stays private',
    'Accessible to everyone',
  ];

  return (
    <section className="section-padding bg-gradient-to-b from-charcoal-950 via-charcoal-900/50 to-charcoal-950">
      <div className="container-width">
        {/* Mission Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gold-500/30 bg-gold-500/5 mb-6">
            <Globe className="w-4 h-4 text-gold-400" />
            <span className="text-sm text-gold-400 font-medium">Our Mission</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 max-w-3xl mx-auto">
            Personal Growth Should Be{' '}
            <span className="gradient-gold-text">Accessible to Everyone</span>
          </h2>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            MG Insight is a free platform designed to help people reflect, think clearly, 
            and make better life decisions. We believe that tools for self-improvement 
            should not be locked behind paywalls.
          </p>
        </motion.div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {values.map((value, index) => {
            const Icon = value.icon;
            return (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-charcoal-900/50 border-gold-500/10 hover:border-gold-500/30 transition-all duration-300 h-full group">
                  <CardContent className="p-6 text-center">
                    <div className={`w-14 h-14 rounded-2xl ${value.bgColor} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className={`w-7 h-7 ${value.color}`} />
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">{value.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Philosophy Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <Card className="bg-gradient-to-r from-gold-500/10 to-amber-500/5 border-gold-500/20">
            <CardContent className="p-8 sm:p-12">
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="flex-1 text-center lg:text-left">
                  <div className="inline-flex items-center gap-2 mb-4">
                    <Sparkles className="w-5 h-5 text-gold-400" />
                    <span className="text-sm font-medium text-gold-400">Why We're Free</span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-bold text-foreground mb-4">
                    Growth Should Have No Barriers
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    We believe that personal development tools should be available to everyone, 
                    regardless of their financial situation. That&apos;s why all MG Insight features 
                    are completely free — no trials, no premium tiers, no hidden costs.
                  </p>
                  
                  {/* Benefits */}
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    {benefits.map((benefit) => (
                      <div key={benefit} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                        <span className="text-sm text-foreground">{benefit}</span>
                      </div>
                    ))}
                  </div>
                  
                  <Button 
                    asChild
                    size="lg"
                    className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold"
                  >
                    <Link href="/signup">
                      Create Free Account
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                </div>
                
                <div className="flex-shrink-0">
                  <div className="w-48 h-48 rounded-full bg-gradient-to-br from-gold-500/20 to-amber-500/10 flex items-center justify-center relative">
                    <div className="absolute inset-4 rounded-full bg-gradient-to-br from-gold-500/10 to-transparent" />
                    <Heart className="w-16 h-16 text-gold-400" />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute inset-0 rounded-full border border-gold-500/20"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Impact Statement */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-sm text-muted-foreground mb-4">
            Join thousands of users on their journey of self-discovery
          </p>
          <div className="flex flex-wrap justify-center gap-8">
            <div className="text-center">
              <p className="text-3xl font-bold text-gold-400">100%</p>
              <p className="text-xs text-muted-foreground">Free Forever</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-purple-400">5+</p>
              <p className="text-xs text-muted-foreground">Growth Tools</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-green-400">∞</p>
              <p className="text-xs text-muted-foreground">Possibilities</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
