'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Brain, Compass, TrendingUp, Shield, Sparkles } from 'lucide-react';

const values = [
  {
    id: 1,
    icon: Brain,
    title: 'Analisis Mendalam',
    description: 'Memahami pola pikir dan perilaku dengan akurasi tinggi menggunakan algoritma Mind Geometry.',
    stat: '99.7%',
    statLabel: 'Akurasi',
  },
  {
    id: 2,
    icon: Compass,
    title: 'Panduan Personal',
    description: 'Rekomendasi yang disesuaikan dengan profil unik Anda untuk pengembangan diri yang optimal.',
    stat: '1:1',
    statLabel: 'Personalisasi',
  },
  {
    id: 3,
    icon: TrendingUp,
    title: 'Growth Tracking',
    description: 'Pantau perkembangan dan transformasi Anda dengan visualisasi yang intuitif dan actionable.',
    stat: '24/7',
    statLabel: 'Monitoring',
  },
  {
    id: 4,
    icon: Shield,
    title: 'Privasi Terjamin',
    description: 'Data Anda dienkripsi dengan standar tertinggi. Keamanan dan privasi adalah prioritas utama.',
    stat: '256-bit',
    statLabel: 'Enkripsi',
  },
  {
    id: 5,
    icon: Sparkles,
    title: 'Insight Real-time',
    description: 'Dapatkan wawasan instan dan relevan yang dapat langsung diterapkan dalam kehidupan sehari-hari.',
    stat: '< 3s',
    statLabel: 'Response',
  },
];

export default function HighlightValue() {
  return (
    <section id="fitur" className="section-padding relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 gradient-dark opacity-50" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold-500/3 rounded-full blur-3xl" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Mengapa MG Insight
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Nilai </span>
            <span className="gradient-gold-text">Premium</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Platform analisis psikologi yang menggabungkan sains kognitif dengan teknologi AI untuk hasil yang akurat dan bermakna.
          </p>
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {values.map((value, index) => {
            const IconComponent = value.icon;
            return (
              <Card
                key={value.id}
                className={`group relative bg-charcoal-900/50 border-gold-500/10 hover:border-gold-500/30 transition-all duration-500 hover:shadow-xl hover:shadow-gold-500/5 hover:-translate-y-1 ${
                  index === 0 ? 'sm:col-span-2 lg:col-span-1' : ''
                }`}
              >
                <CardContent className="p-6 lg:p-8 relative overflow-hidden">
                  {/* Glow effect on hover */}
                  <div className="absolute -inset-px bg-gradient-to-r from-gold-500/0 via-gold-500/10 to-gold-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl" />
                  
                  {/* Icon */}
                  <div className="relative w-14 h-14 rounded-xl bg-gradient-to-br from-gold-500/20 to-gold-600/10 border border-gold-500/20 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:border-gold-500/40 transition-all duration-300">
                    <IconComponent className="w-7 h-7 text-gold-400" />
                  </div>
                  
                  {/* Stat Badge */}
                  <div className="absolute top-6 right-6 text-right">
                    <div className="text-2xl font-bold gradient-gold-text">{value.stat}</div>
                    <div className="text-xs text-muted-foreground">{value.statLabel}</div>
                  </div>
                  
                  {/* Content */}
                  <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-gold-400 transition-colors">
                    {value.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                  
                  {/* Bottom gradient line */}
                  <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
