'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronRight, Sparkles, BookOpen, Target, Map } from 'lucide-react';

// Platform value cards data
const platformValues = [
  {
    icon: BookOpen,
    title: 'Self Reflection',
    description: 'Use Mind Journal to understand your emotions and thought patterns.',
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/20',
    borderColor: 'border-purple-500/30',
  },
  {
    icon: Target,
    title: 'Decision Simulation',
    description: 'ProbSim helps analyze possible outcomes of important life decisions.',
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/20',
    borderColor: 'border-amber-500/30',
  },
  {
    icon: Map,
    title: 'Life Direction',
    description: 'LifeMap visualizes your goals and personal growth journey.',
    color: 'text-green-400',
    bgColor: 'bg-green-500/20',
    borderColor: 'border-green-500/30',
  },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 gradient-dark" />
      
      {/* Animated gradient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gold-600/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
      
      {/* Grid pattern overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(212, 165, 116, 0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(212, 165, 116, 0.1) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />
      
      <div className="relative z-10 container-width section-padding text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gold-500/30 bg-charcoal-900/50 mb-8 animate-fade-in">
          <Sparkles className="w-4 h-4 text-gold-500" />
          <span className="text-sm text-gold-400 font-medium">Free Platform for Personal Growth</span>
        </div>
        
        {/* Main Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 animate-fade-in stagger-1">
          <span className="block text-foreground">Temukan Kekuatan</span>
          <span className="block gradient-gold-text mt-2">Mind Geometry</span>
        </h1>
        
        {/* Subheadline */}
        <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-12 animate-fade-in stagger-2">
          Buka potensi tersembunyi dalam pikiran Anda. MG Insight membantu Anda memahami pola pikir, 
          mengoptimalkan keputusan, dan mencapai transformasi mendalam melalui analisis berbasis geometri kognitif.
        </p>
        
        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in stagger-3">
          <Button 
            size="lg"
            className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold px-8 py-6 text-lg rounded-xl shadow-lg shadow-gold-500/20 hover:shadow-gold-500/40 transition-all duration-300 hover:scale-105"
          >
            Mulai Gratis
            <ChevronRight className="ml-2 w-5 h-5" />
          </Button>
          
          <Button 
            variant="outline"
            size="lg"
            className="border-gold-500/30 text-gold-400 hover:bg-gold-500/10 hover:border-gold-500/50 px-8 py-6 text-lg rounded-xl transition-all duration-300"
          >
            Jelajahi Platform
          </Button>
        </div>
        
        {/* Platform Value Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mt-16 max-w-4xl mx-auto animate-fade-in stagger-4">
          {platformValues.map((item, index) => {
            const Icon = item.icon;
            return (
              <Card 
                key={index}
                className={`bg-charcoal-900/50 ${item.borderColor} hover:bg-charcoal-900/70 transition-all duration-300 group backdrop-blur-sm`}
              >
                <CardContent className="p-6 text-center">
                  <div className={`w-14 h-14 rounded-2xl ${item.bgColor} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className={`w-7 h-7 ${item.color}`} />
                  </div>
                  <h3 className="font-semibold text-foreground text-lg mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-gold-500/30 flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-gold-500 rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
}
