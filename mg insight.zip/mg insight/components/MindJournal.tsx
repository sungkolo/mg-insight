'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { BookHeart, TrendingUp, Smile, Meh, Frown, Sparkles, Heart, FileText, Target, Lightbulb, Calendar, Zap } from 'lucide-react';

interface MoodEntry {
  text: string;
  mood: 'positive' | 'neutral' | 'negative';
  score: number;
  keywords: string[];
  timestamp: Date;
  template?: string;
}

interface JournalTemplate {
  id: string;
  title: string;
  icon: React.ElementType;
  prompts: string[];
  color: string;
}

const journalTemplates: JournalTemplate[] = [
  {
    id: 'gratitude',
    title: 'Gratitude Journal',
    icon: Heart,
    color: 'from-rose-500 to-pink-600',
    prompts: [
      'Apa yang Anda syukuri hari ini?',
      'Siapa orang yang membuat hari Anda lebih baik?',
      'Apa pencapaian kecil yang Anda rayakan?',
    ],
  },
  {
    id: 'reflection',
    title: 'Daily Reflection',
    icon: Sparkles,
    color: 'from-purple-500 to-violet-600',
    prompts: [
      'Apa highlight hari ini?',
      'Apa yang bisa diperbaiki?',
      'Apa pelajaran yang Anda dapatkan?',
    ],
  },
  {
    id: 'goal',
    title: 'Goal Setting',
    icon: Target,
    color: 'from-emerald-500 to-green-600',
    prompts: [
      'Apa 3 prioritas Anda untuk besok?',
      'Apa progres yang Anda buat hari ini?',
      'Apa hambatan yang perlu diatasi?',
    ],
  },
  {
    id: 'creative',
    title: 'Creative Ideas',
    icon: Lightbulb,
    color: 'from-amber-500 to-orange-600',
    prompts: [
      'Apa ide baru yang muncul hari ini?',
      'Apa masalah yang ingin Anda selesaikan?',
      'Bagaimana cara berinovasi dalam hidup Anda?',
    ],
  },
  {
    id: 'mood',
    title: 'Mood Check-in',
    icon: Calendar,
    color: 'from-blue-500 to-cyan-600',
    prompts: [
      'Bagaimana perasaan Anda sekarang?',
      'Apa yang mempengaruhi mood Anda?',
      'Apa yang bisa membuat Anda lebih baik?',
    ],
  },
];

const moodKeywords = {
  positive: ['senang', 'bahagia', 'berhasil', 'sukses', 'cinta', 'hebat', 'luar biasa', 'antusias', 'bersemangat', 'grateful', 'syukur', 'berharga', 'indah', 'menyenangkan', 'semangat', 'optimis', 'yakin', 'percaya', 'bangga', 'puas'],
  negative: ['sedih', 'kecewa', 'marah', 'frustasi', 'khawatir', 'takut', 'cemas', 'gelisah', 'stres', 'lelah', 'bosan', 'sendu', 'hampa', 'kosong', 'ragu', 'bingung', 'putus asa', 'kesal', 'jengkel', 'tekanan'],
  neutral: ['biasa', 'normal', 'standar', 'lumayan', 'oke', 'gitu', 'saja', 'hari ini', 'kemarin', 'besok', 'kerja', 'aktivitas', 'rutin'],
};

const affirmations = [
  'Setiap hari adalah kesempatan baru untuk berkembang.',
  'Pikiran Anda adalah kekuatan terbesar Anda.',
  'Langkah kecil hari ini adalah fondasi kesuksesan besok.',
  'Anda memiliki kemampuan untuk menciptakan perubahan.',
  'Setiap tantangan adalah peluang untuk belajar.',
  'Anda layak mendapatkan kebahagiaan dan kesuksesan.',
  'Ketahanan Anda lebih kuat dari yang Anda kira.',
  'Hari ini penuh dengan kemungkinan tak terbatas.',
  'Kesalahan adalah langkah menuju kemajuan.',
  'Anda mengendalikan reaksi Anda terhadap setiap situasi.',
];

const tips = [
  'Tulis secara konsisten setiap hari untuk hasil terbaik.',
  'Fokus pada perasaan, bukan hanya peristiwa.',
  'Jangan menghakimi pikiran Anda - tulis dengan jujur.',
  'Review jurnal mingguan Anda untuk melihat pola.',
  'Gunakan template untuk memandu refleksi Anda.',
];

export default function MindJournal() {
  const [journalText, setJournalText] = useState('');
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<JournalTemplate | null>(null);
  const [dailyAffirmation, setDailyAffirmation] = useState('');
  const [dailyTip, setDailyTip] = useState('');
  const [showTemplates, setShowTemplates] = useState(false);

  useEffect(() => {
    setDailyAffirmation(affirmations[Math.floor(Math.random() * affirmations.length)]);
    setDailyTip(tips[Math.floor(Math.random() * tips.length)]);
  }, []);

  const analyzeMood = (text: string): { mood: 'positive' | 'neutral' | 'negative'; score: number; keywords: string[] } => {
    const lowerText = text.toLowerCase();
    const foundKeywords: { type: 'positive' | 'neutral' | 'negative'; word: string }[] = [];
    
    let positiveCount = 0;
    let negativeCount = 0;
    let neutralCount = 0;

    moodKeywords.positive.forEach((word) => {
      if (lowerText.includes(word)) {
        positiveCount++;
        foundKeywords.push({ type: 'positive', word });
      }
    });

    moodKeywords.negative.forEach((word) => {
      if (lowerText.includes(word)) {
        negativeCount++;
        foundKeywords.push({ type: 'negative', word });
      }
    });

    moodKeywords.neutral.forEach((word) => {
      if (lowerText.includes(word)) {
        neutralCount++;
        foundKeywords.push({ type: 'neutral', word });
      }
    });

    const total = positiveCount + negativeCount + neutralCount || 1;
    let mood: 'positive' | 'neutral' | 'negative' = 'neutral';
    
    if (positiveCount > negativeCount && positiveCount > neutralCount) {
      mood = 'positive';
    } else if (negativeCount > positiveCount && negativeCount > neutralCount) {
      mood = 'negative';
    }

    const score = Math.round(((positiveCount * 100) + (neutralCount * 50) - (negativeCount * 30)) / total);
    const clampedScore = Math.max(0, Math.min(100, score + 50));

    return {
      mood,
      score: clampedScore,
      keywords: foundKeywords.slice(0, 5).map((k) => k.word),
    };
  };

  const handleSubmitJournal = () => {
    if (journalText.trim().length < 10) return;

    const analysis = analyzeMood(journalText);
    const newEntry: MoodEntry = {
      text: journalText,
      mood: analysis.mood,
      score: analysis.score,
      keywords: analysis.keywords,
      timestamp: new Date(),
      template: selectedTemplate?.title,
    };

    setEntries([newEntry, ...entries]);
    setJournalText('');
    setSelectedTemplate(null);
  };

  const getMoodIcon = (mood: 'positive' | 'neutral' | 'negative') => {
    switch (mood) {
      case 'positive':
        return <Smile className="w-5 h-5 text-emerald-400" />;
      case 'negative':
        return <Frown className="w-5 h-5 text-rose-400" />;
      default:
        return <Meh className="w-5 h-5 text-amber-400" />;
    }
  };

  // Calculate average mood score
  const avgScore = entries.length > 0
    ? Math.round(entries.reduce((acc, e) => acc + e.score, 0) / entries.length)
    : 50;

  // Count by mood
  const moodCounts = {
    positive: entries.filter(e => e.mood === 'positive').length,
    neutral: entries.filter(e => e.mood === 'neutral').length,
    negative: entries.filter(e => e.mood === 'negative').length,
  };

  return (
    <section className="section-padding bg-charcoal-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Mind Journal
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Jurnal </span>
            <span className="gradient-gold-text">Pikiran</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Tulis refleksi harian dengan template terpandu dan lihat visualisasi mood secara real-time.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Templates Panel */}
          <Card className="bg-charcoal-900/50 border-gold-500/10 lg:col-span-1">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-foreground">Templates</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowTemplates(!showTemplates)}
                  className="text-xs text-gold-400"
                >
                  {showTemplates ? 'Sembunyikan' : 'Lihat Semua'}
                </Button>
              </div>
              
              <div className="space-y-2">
                {journalTemplates.slice(0, showTemplates ? undefined : 3).map((template) => {
                  const IconComponent = template.icon;
                  const isSelected = selectedTemplate?.id === template.id;
                  return (
                    <button
                      key={template.id}
                      onClick={() => setSelectedTemplate(isSelected ? null : template)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                        isSelected
                          ? 'bg-gold-500/20 border border-gold-500/30'
                          : 'bg-charcoal-800/30 border border-transparent hover:bg-charcoal-800/50'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${template.color} flex items-center justify-center`}>
                        <IconComponent className="w-4 h-4 text-white" />
                      </div>
                      <span className={`text-sm ${isSelected ? 'text-gold-400' : 'text-muted-foreground'}`}>
                        {template.title}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Daily Tip */}
              <div className="mt-6 p-4 rounded-xl bg-charcoal-800/30 border border-gold-500/10">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-gold-400" />
                  <span className="text-xs text-gold-400 font-medium">Tips Hari Ini</span>
                </div>
                <p className="text-xs text-muted-foreground">{dailyTip}</p>
              </div>
            </CardContent>
          </Card>

          {/* Journal Input */}
          <Card className="bg-charcoal-900/50 border-gold-500/10 lg:col-span-2">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gold-500/20 flex items-center justify-center">
                  <BookHeart className="w-5 h-5 text-gold-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">
                    {selectedTemplate ? selectedTemplate.title : 'Tulis Refleksi'}
                  </h3>
                  <span className="text-xs text-muted-foreground">
                    {entries.length} entri tersimpan
                  </span>
                </div>
              </div>

              {/* Daily Affirmation */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-gold-500/10 to-transparent border border-gold-500/10 mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-gold-400" />
                  <span className="text-xs text-gold-400 font-medium">Affirmasi Hari Ini</span>
                </div>
                <p className="text-sm text-muted-foreground italic">"{dailyAffirmation}"</p>
              </div>

              {/* Template Prompts */}
              {selectedTemplate && (
                <div className="mb-4 p-4 rounded-xl bg-charcoal-800/30 border border-gold-500/10">
                  <div className="text-xs text-muted-foreground mb-2">Panduan penulisan:</div>
                  <ul className="space-y-1">
                    {selectedTemplate.prompts.map((prompt, idx) => (
                      <li key={idx} className="text-sm text-foreground flex items-start gap-2">
                        <span className="text-gold-400 mt-1">•</span>
                        {prompt}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Textarea */}
              <Textarea
                placeholder={selectedTemplate 
                  ? selectedTemplate.prompts[0] + '...'
                  : "Bagaimana perasaan Anda hari ini? Apa yang terjadi? Apa yang Anda pikirkan?"
                }
                value={journalText}
                onChange={(e) => setJournalText(e.target.value)}
                className="min-h-[180px] bg-charcoal-800/50 border-gold-500/20 focus:border-gold-500/50 text-foreground placeholder:text-muted-foreground/50 resize-none"
              />

              <div className="flex items-center justify-between mt-4">
                <span className="text-xs text-muted-foreground">
                  {journalText.length} karakter
                </span>
                <Button
                  onClick={handleSubmitJournal}
                  disabled={journalText.trim().length < 10}
                  className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-medium disabled:opacity-50"
                >
                  Simpan & Analisis
                </Button>
              </div>

              {/* Recent Entries */}
              {entries.length > 0 && (
                <div className="mt-6 pt-6 border-t border-gold-500/10">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm font-medium text-foreground">Entri Terbaru</h4>
                    <div className="flex items-center gap-3 text-xs">
                      <span className="text-emerald-400">{moodCounts.positive} positif</span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-amber-400">{moodCounts.neutral} netral</span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-rose-400">{moodCounts.negative} negatif</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {entries.slice(0, 5).map((entry, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg bg-charcoal-800/30 border border-gold-500/5"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            {getMoodIcon(entry.mood)}
                            {entry.template && (
                              <span className="text-xs text-gold-400">{entry.template}</span>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {entry.timestamp.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-2">{entry.text}</p>
                        {entry.keywords.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {entry.keywords.slice(0, 3).map((kw, i) => (
                              <span
                                key={i}
                                className="px-2 py-0.5 rounded-full text-xs bg-gold-500/10 text-gold-400"
                              >
                                {kw}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Mood Visualization */}
        {entries.length > 0 && (
          <div className="mt-8 max-w-3xl mx-auto">
            <Card className="bg-charcoal-900/50 border-gold-500/10">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-gold-500/20 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-gold-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Ringkasan Mood</h3>
                    <span className="text-xs text-muted-foreground">Berdasarkan {entries.length} entri</span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-8">
                  {/* Mood Meter */}
                  <div className="relative w-28 h-28">
                    <svg className="w-full h-full -rotate-90">
                      <circle
                        cx="56"
                        cy="56"
                        r="48"
                        fill="none"
                        stroke="rgba(212, 165, 116, 0.1)"
                        strokeWidth="8"
                      />
                      <circle
                        cx="56"
                        cy="56"
                        r="48"
                        fill="none"
                        stroke="url(#moodGradient2)"
                        strokeWidth="8"
                        strokeLinecap="round"
                        strokeDasharray={`${(avgScore / 100) * 301} 301`}
                        className="transition-all duration-1000"
                      />
                      <defs>
                        <linearGradient id="moodGradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#d4a574" />
                          <stop offset="100%" stopColor="#b8860b" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-2xl font-bold gradient-gold-text">{avgScore}</span>
                      <span className="text-[10px] text-muted-foreground">Mood Score</span>
                    </div>
                  </div>

                  {/* Mood Distribution */}
                  <div className="flex-1 space-y-3">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-muted-foreground">Positif</span>
                        <span className="text-emerald-400">{Math.round((moodCounts.positive / entries.length) * 100)}%</span>
                      </div>
                      <div className="h-2 bg-charcoal-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-green-400 rounded-full"
                          style={{ width: `${(moodCounts.positive / entries.length) * 100}%` }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-muted-foreground">Netral</span>
                        <span className="text-amber-400">{Math.round((moodCounts.neutral / entries.length) * 100)}%</span>
                      </div>
                      <div className="h-2 bg-charcoal-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full"
                          style={{ width: `${(moodCounts.neutral / entries.length) * 100}%` }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-muted-foreground">Negatif</span>
                        <span className="text-rose-400">{Math.round((moodCounts.negative / entries.length) * 100)}%</span>
                      </div>
                      <div className="h-2 bg-charcoal-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-rose-500 to-red-400 rounded-full"
                          style={{ width: `${(moodCounts.negative / entries.length) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </section>
  );
}
