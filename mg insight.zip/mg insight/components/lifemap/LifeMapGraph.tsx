'use client';

import { useCallback, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  ReactFlow,
  Node,
  Edge,
  useNodesState,
  useEdgesState,
  Background,
  Controls,
  MiniMap,
  BackgroundVariant,
  MarkerType,
  Position,
  Handle,
  NodeProps,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Target,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  ZoomIn,
  ZoomOut,
  Maximize2,
  GitBranch,
} from 'lucide-react';
import { useLifeMapStore } from '@/store/lifemap-store';
import type { PriorityLevel } from '@/types/lifemap';

const priorityConfig: Record<PriorityLevel, { color: string; border: string; glow: string }> = {
  critical: { color: 'text-red-400', border: 'border-red-500/50', glow: 'shadow-red-500/20' },
  high: { color: 'text-orange-400', border: 'border-orange-500/50', glow: 'shadow-orange-500/20' },
  medium: { color: 'text-yellow-400', border: 'border-yellow-500/50', glow: 'shadow-yellow-500/20' },
  low: { color: 'text-green-400', border: 'border-green-500/50', glow: 'shadow-green-500/20' },
};

// Custom Decision Node Component
function DecisionNode({ data }: NodeProps) {
  const nodeData = data as { label: string; priority?: PriorityLevel; description?: string; isSelected?: boolean };
  const config = nodeData.priority ? priorityConfig[nodeData.priority] : priorityConfig.medium;

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
    >
      <Handle type="target" position={Position.Top} className="!bg-amber-500 !w-3 !h-3" />
      <Card
        className={`
          relative px-6 py-4 min-w-[200px] max-w-[280px]
          bg-gradient-to-br from-amber-500/20 to-orange-500/10
          backdrop-blur-xl border-2 ${config.border}
          shadow-2xl ${config.glow}
          ${nodeData.isSelected ? 'ring-2 ring-amber-400 ring-offset-2 ring-offset-black' : ''}
        `}
      >
        <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center shadow-lg">
          <Target className="w-4 h-4 text-white" />
        </div>
        <div className="text-center">
          <p className="font-semibold text-white text-sm">{nodeData.label}</p>
          {nodeData.description && (
            <p className="text-xs text-white/40 mt-1 line-clamp-2">{nodeData.description}</p>
          )}
          {nodeData.priority && (
            <Badge className={`mt-2 ${priorityConfig[nodeData.priority].color} bg-white/5 text-[10px]`}>
              {nodeData.priority}
            </Badge>
          )}
        </div>
      </Card>
      <Handle type="source" position={Position.Bottom} className="!bg-amber-500 !w-3 !h-3" />
    </motion.div>
  );
}

// Custom Outcome Node Component
function OutcomeNode({ data }: NodeProps) {
  const nodeData = data as {
    label: string;
    probability?: number;
    isSimulated?: boolean;
    emotionalImpact?: number;
    riskLevel?: number;
    isSelected?: boolean;
  };

  const probColor = nodeData.probability && nodeData.probability >= 60
    ? 'from-green-500/20 to-emerald-500/10 border-green-500/30'
    : nodeData.probability && nodeData.probability >= 30
    ? 'from-yellow-500/20 to-amber-500/10 border-yellow-500/30'
    : 'from-red-500/20 to-rose-500/10 border-red-500/30';

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
    >
      <Handle type="target" position={Position.Top} className="!bg-purple-500 !w-2 !h-2" />
      <Card
        className={`
          relative px-4 py-3 min-w-[160px] max-w-[220px]
          bg-gradient-to-br ${probColor}
          backdrop-blur-xl border
          shadow-xl
          ${nodeData.isSimulated ? 'ring-2 ring-green-400 ring-offset-2 ring-offset-black shadow-green-500/30' : ''}
          ${nodeData.isSelected ? 'ring-2 ring-purple-400' : ''}
          transition-all duration-300
        `}
      >
        {nodeData.isSimulated && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center"
          >
            <CheckCircle2 className="w-3 h-3 text-white" />
          </motion.div>
        )}
        <div className="text-center">
          <p className="font-medium text-white text-sm">{nodeData.label}</p>
          {nodeData.probability !== undefined && (
            <Badge className={`mt-2 ${nodeData.probability >= 60 ? 'bg-green-500/20 text-green-400' : nodeData.probability >= 30 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'} text-xs`}>
              {nodeData.probability}%
            </Badge>
          )}
          {(nodeData.emotionalImpact !== undefined || nodeData.riskLevel !== undefined) && (
            <div className="flex justify-center gap-2 mt-2 text-[10px] text-white/40">
              {nodeData.emotionalImpact !== undefined && <span>Impact: {nodeData.emotionalImpact}/10</span>}
              {nodeData.riskLevel !== undefined && <span>Risk: {nodeData.riskLevel}/10</span>}
            </div>
          )}
        </div>
      </Card>
      <Handle type="source" position={Position.Bottom} className="!bg-purple-500 !w-2 !h-2" />
    </motion.div>
  );
}

// Empty State Component
function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none"
    >
      <div className="text-center space-y-6">
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
          className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-amber-500/10 to-purple-500/10 border border-white/5 flex items-center justify-center"
        >
          <GitBranch className="w-12 h-12 text-white/20" />
        </motion.div>
        <div>
          <h3 className="text-xl font-semibold text-white/50 mb-2">No Decision Tree Yet</h3>
          <p className="text-sm text-white/30">Create a decision and add outcomes to visualize your life map</p>
        </div>
      </div>
    </motion.div>
  );
}

const nodeTypes = {
  decision: DecisionNode,
  outcome: OutcomeNode,
};

export default function LifeMapGraph() {
  const { rootDecision, simulationResult, setSelectedNode, selectedNodeId } = useLifeMapStore();

  // Convert decision data to React Flow nodes and edges
  const { nodes: initialNodes, edges: initialEdges } = useMemo(() => {
    if (!rootDecision) {
      return { nodes: [], edges: [] };
    }

    const nodes: Node[] = [];
    const edges: Edge[] = [];

    // Root decision node
    nodes.push({
      id: rootDecision.id,
      type: 'decision',
      position: { x: 400, y: 50 },
      data: {
        label: rootDecision.title,
        priority: rootDecision.priority,
        description: rootDecision.description,
        type: 'decision',
        isSelected: selectedNodeId === rootDecision.id,
      },
    });

    // Outcome nodes
    const outcomeCount = rootDecision.outcomes.length;
    const startX = 200;
    const spacing = 250;

    rootDecision.outcomes.forEach((outcome, index) => {
      const xPos = startX + (index * spacing) - ((outcomeCount - 1) * spacing) / 2;
      const isSimulated = simulationResult?.outcomeId === outcome.id;

      nodes.push({
        id: outcome.id,
        type: 'outcome',
        position: { x: xPos, y: 250 },
        data: {
          label: outcome.title,
          probability: outcome.probability,
          emotionalImpact: outcome.emotionalImpact,
          riskLevel: outcome.riskLevel,
          isSimulated,
          type: 'outcome',
          isSelected: selectedNodeId === outcome.id,
        },
      });

      // Edge from decision to outcome
      edges.push({
        id: `${rootDecision.id}-${outcome.id}`,
        source: rootDecision.id,
        target: outcome.id,
        animated: isSimulated,
        style: {
          stroke: isSimulated ? '#22c55e' : outcome.probability >= 60 ? '#22c55e' : outcome.probability >= 30 ? '#eab308' : '#ef4444',
          strokeWidth: isSimulated ? 3 : 2,
        },
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: isSimulated ? '#22c55e' : outcome.probability >= 60 ? '#22c55e' : outcome.probability >= 30 ? '#eab308' : '#ef4444',
        },
        label: `${outcome.probability}%`,
        labelStyle: { fill: '#fff', fontSize: 10 },
        labelBgStyle: { fill: 'rgba(0,0,0,0.5)', fillOpacity: 1 },
        labelBgPadding: [4, 2] as [number, number],
        labelBgBorderRadius: 4,
      });
    });

    return { nodes, edges };
  }, [rootDecision, simulationResult, selectedNodeId]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  // Update nodes when data changes
  useEffect(() => {
    setNodes(initialNodes);
    setEdges(initialEdges);
  }, [initialNodes, initialEdges, setNodes, setEdges]);

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node.id);
  }, [setSelectedNode]);

  if (!rootDecision) {
    return (
      <div className="relative h-full bg-gradient-to-br from-black via-black to-zinc-950 rounded-2xl overflow-hidden border border-white/5">
        <Background
          variant={BackgroundVariant.Dots}
          gap={20}
          size={1}
          color="rgba(255,255,255,0.03)"
        />
        <EmptyState />
      </div>
    );
  }

  return (
    <div className="relative h-full bg-gradient-to-br from-black via-black to-zinc-950 rounded-2xl overflow-hidden border border-white/5">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.3 }}
        minZoom={0.3}
        maxZoom={2}
        defaultEdgeOptions={{
          type: 'smoothstep',
        }}
        className="bg-transparent"
      >
        <Background
          variant={BackgroundVariant.Dots}
          gap={20}
          size={1}
          color="rgba(255,255,255,0.03)"
        />
        <Controls
          className="!bg-black/50 !border-white/10 !rounded-xl overflow-hidden"
          showZoom={true}
          showFitView={true}
          showInteractive={false}
        />
        <MiniMap
          className="!bg-black/50 !border-white/10 !rounded-xl overflow-hidden"
          nodeColor={(node) => {
            if (node.type === 'decision') return '#f59e0b';
            const data = node.data as { probability?: number };
            if (data.probability && data.probability >= 60) return '#22c55e';
            if (data.probability && data.probability >= 30) return '#eab308';
            return '#ef4444';
          }}
          maskColor="rgba(0,0,0,0.8)"
        />
      </ReactFlow>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 flex items-center gap-4 text-xs text-white/40 bg-black/50 backdrop-blur-sm rounded-lg px-4 py-2 border border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-amber-500" />
          <span>Decision</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-500" />
          <span>High Prob</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-yellow-500" />
          <span>Med Prob</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500" />
          <span>Low Prob</span>
        </div>
      </div>

      {/* Node Count */}
      <div className="absolute top-4 right-4 text-xs text-white/40 bg-black/50 backdrop-blur-sm rounded-lg px-3 py-2 border border-white/5">
        {rootDecision.outcomes.length} outcomes
      </div>
    </div>
  );
}
