'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Plus,
  Trash2,
  Target,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Zap,
  RefreshCw,
  Save,
  ChevronDown,
  ChevronUp,
  GripVertical,
  TrendingUp,
  Heart,
  Shield,
} from 'lucide-react';
import { useLifeMapStore, createDecision, createOutcome } from '@/store/lifemap-store';
import type { PriorityLevel, Outcome } from '@/types/lifemap';

const priorityConfig: Record<PriorityLevel, { color: string; bg: string; label: string }> = {
  critical: { color: 'text-red-400', bg: 'bg-red-500/20', label: 'Critical' },
  high: { color: 'text-orange-400', bg: 'bg-orange-500/20', label: 'High' },
  medium: { color: 'text-yellow-400', bg: 'bg-yellow-500/20', label: 'Medium' },
  low: { color: 'text-green-400', bg: 'bg-green-500/20', label: 'Low' },
};

export default function LifeMapControl() {
  const {
    rootDecision,
    addOutcome,
    updateOutcome,
    removeOutcome,
    updateDecision,
    setRootDecision,
    reset,
    saveToHistory,
  } = useLifeMapStore();

  // Local state for new decision
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPriority, setNewPriority] = useState<PriorityLevel>('medium');

  // Local state for new outcome
  const [outcomeTitle, setOutcomeTitle] = useState('');
  const [outcomeDescription, setOutcomeDescription] = useState('');
  const [expandedOutcomes, setExpandedOutcomes] = useState<Set<string>>(new Set());

  // Calculate total probability
  const totalProbability = rootDecision?.outcomes.reduce((sum, o) => sum + o.probability, 0) || 0;
  const isProbabilityValid = totalProbability === 100;
  const hasOutcomes = (rootDecision?.outcomes.length || 0) > 0;

  // Handle create decision
  const handleCreateDecision = () => {
    if (!newTitle.trim()) return;
    const decision = createDecision(newTitle.trim(), newDescription.trim(), newPriority);
    setRootDecision(decision);
    setNewTitle('');
    setNewDescription('');
    setNewPriority('medium');
  };

  // Handle add outcome
  const handleAddOutcome = () => {
    if (!outcomeTitle.trim() || !rootDecision) return;
    
    // Calculate initial probability
    const currentTotal = rootDecision.outcomes.reduce((sum, o) => sum + o.probability, 0);
    const remaining = Math.max(0, 100 - currentTotal);
    const initialProb = rootDecision.outcomes.length === 0 ? 100 : Math.min(remaining, Math.floor(100 / (rootDecision.outcomes.length + 1)));
    
    const outcome = createOutcome(outcomeTitle.trim(), initialProb, outcomeDescription.trim());
    addOutcome(outcome);
    setOutcomeTitle('');
    setOutcomeDescription('');
  };

  // Handle probability change with auto-adjustment
  const handleProbabilityChange = (outcomeId: string, newProb: number) => {
    if (!rootDecision) return;
    
    updateOutcome(outcomeId, { probability: newProb });
  };

  // Auto-balance probabilities
  const autoBalanceProbabilities = () => {
    if (!rootDecision || rootDecision.outcomes.length === 0) return;
    
    const equalProb = Math.floor(100 / rootDecision.outcomes.length);
    const remainder = 100 - equalProb * rootDecision.outcomes.length;
    
    rootDecision.outcomes.forEach((outcome, index) => {
      updateOutcome(outcome.id, { 
        probability: equalProb + (index === 0 ? remainder : 0) 
      });
    });
  };

  // Toggle outcome expansion
  const toggleOutcomeExpansion = (id: string) => {
    setExpandedOutcomes((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  return (
    <div className="h-full flex flex-col space-y-4 overflow-y-auto pr-2 custom-scrollbar">
      {/* Decision Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-2xl overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2 text-base">
              <Target className="w-4 h-4 text-amber-400" />
              Decision Node
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!rootDecision ? (
              <>
                <Input
                  placeholder="What decision are you facing?"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-amber-500/50 focus:ring-amber-500/20"
                />
                <Input
                  placeholder="Describe the context..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-amber-500/50 focus:ring-amber-500/20"
                />
                <Select value={newPriority} onValueChange={(v) => setNewPriority(v as PriorityLevel)}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent className="bg-charcoal-900 border-white/10">
                    {Object.entries(priorityConfig).map(([value, config]) => (
                      <SelectItem key={value} value={value} className="text-white focus:bg-white/10">
                        <span className={`px-2 py-0.5 rounded text-xs ${config.bg} ${config.color}`}>
                          {config.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  onClick={handleCreateDecision}
                  disabled={!newTitle.trim()}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Decision
                </Button>
              </>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-3"
              >
                <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/10 to-orange-500/5 border border-amber-500/20">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-white">{rootDecision.title}</h3>
                      {rootDecision.description && (
                        <p className="text-sm text-white/50 mt-1">{rootDecision.description}</p>
                      )}
                    </div>
                    <Badge className={`${priorityConfig[rootDecision.priority].bg} ${priorityConfig[rootDecision.priority].color}`}>
                      {priorityConfig[rootDecision.priority].label}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      saveToHistory();
                      reset();
                    }}
                    className="flex-1 border-white/10 text-white/70 hover:text-white hover:bg-white/5"
                  >
                    <RefreshCw className="w-3 h-3 mr-1" />
                    Reset
                  </Button>
                </div>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Outcomes Section */}
      {rootDecision && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-2xl overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2 text-base">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  Outcomes
                  <Badge variant="outline" className="border-white/10 text-white/50 ml-2">
                    {rootDecision.outcomes.length}
                  </Badge>
                </CardTitle>
                <div className="flex items-center gap-2">
                  {isProbabilityValid ? (
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-yellow-400" />
                  )}
                  <span className={`text-sm font-medium ${isProbabilityValid ? 'text-green-400' : 'text-yellow-400'}`}>
                    {totalProbability}%
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Probability Bar */}
              <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full ${isProbabilityValid ? 'bg-gradient-to-r from-green-500 to-emerald-500' : 'bg-gradient-to-r from-yellow-500 to-orange-500'}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(totalProbability, 100)}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>

              {/* Outcome List */}
              <AnimatePresence>
                {rootDecision.outcomes.map((outcome, index) => (
                  <motion.div
                    key={outcome.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="rounded-xl bg-white/5 border border-white/10 overflow-hidden"
                  >
                    <div
                      className="p-3 cursor-pointer hover:bg-white/5 transition-colors"
                      onClick={() => toggleOutcomeExpansion(outcome.id)}
                    >
                      <div className="flex items-center gap-3">
                        <GripVertical className="w-4 h-4 text-white/30" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-white truncate">{outcome.title}</p>
                          <p className="text-xs text-white/40">{outcome.probability}% probability</p>
                        </div>
                        <Badge className={`${getProbabilityColor(outcome.probability)} text-xs`}>
                          {outcome.probability}%
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeOutcome(outcome.id);
                          }}
                          className="h-6 w-6 p-0 text-white/30 hover:text-red-400"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                        {expandedOutcomes.has(outcome.id) ? (
                          <ChevronUp className="w-4 h-4 text-white/30" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-white/30" />
                        )}
                      </div>
                    </div>

                    {/* Expanded Content */}
                    <AnimatePresence>
                      {expandedOutcomes.has(outcome.id) && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="border-t border-white/5"
                        >
                          <div className="p-4 space-y-4">
                            {/* Probability Slider */}
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-white/50">Probability</span>
                                <span className="text-white font-medium">{outcome.probability}%</span>
                              </div>
                              <Slider
                                value={[outcome.probability]}
                                onValueChange={([value]) => handleProbabilityChange(outcome.id, value)}
                                max={100}
                                step={1}
                                className="w-full"
                              />
                            </div>

                            {/* Impact Meters */}
                            <div className="grid grid-cols-2 gap-3">
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm text-white/50">
                                  <Heart className="w-3 h-3 text-pink-400" />
                                  Emotional Impact
                                </div>
                                <Slider
                                  value={[outcome.emotionalImpact || 5]}
                                  onValueChange={([value]) => updateOutcome(outcome.id, { emotionalImpact: value })}
                                  max={10}
                                  step={1}
                                />
                                <p className="text-xs text-white/30 text-center">{outcome.emotionalImpact || 5}/10</p>
                              </div>
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm text-white/50">
                                  <Shield className="w-3 h-3 text-blue-400" />
                                  Risk Level
                                </div>
                                <Slider
                                  value={[outcome.riskLevel || 5]}
                                  onValueChange={([value]) => updateOutcome(outcome.id, { riskLevel: value })}
                                  max={10}
                                  step={1}
                                />
                                <p className="text-xs text-white/30 text-center">{outcome.riskLevel || 5}/10</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Add Outcome Form */}
              <div className="pt-2 border-t border-white/5 space-y-3">
                <Input
                  placeholder="Add possible outcome..."
                  value={outcomeTitle}
                  onChange={(e) => setOutcomeTitle(e.target.value)}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                />
                <div className="flex gap-2">
                  <Button
                    onClick={handleAddOutcome}
                    disabled={!outcomeTitle.trim()}
                    className="flex-1 bg-white/5 hover:bg-white/10 text-white border border-white/10"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Outcome
                  </Button>
                  {!isProbabilityValid && hasOutcomes && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={autoBalanceProbabilities}
                      className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                    >
                      <Zap className="w-3 h-3 mr-1" />
                      Auto Balance
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Quick Stats */}
      {rootDecision && rootDecision.outcomes.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-2 gap-3"
        >
          <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-xs text-white/50">Highest Prob</span>
            </div>
            <p className="text-lg font-semibold text-white">
              {Math.max(...rootDecision.outcomes.map((o) => o.probability))}%
            </p>
          </Card>
          <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-1">
              <Target className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-white/50">Avg Risk</span>
            </div>
            <p className="text-lg font-semibold text-white">
              {(rootDecision.outcomes.reduce((sum, o) => sum + (o.riskLevel || 5), 0) / rootDecision.outcomes.length).toFixed(1)}/10
            </p>
          </Card>
        </motion.div>
      )}
    </div>
  );
}

function getProbabilityColor(prob: number): string {
  if (prob >= 60) return 'bg-green-500/20 text-green-400';
  if (prob >= 30) return 'bg-yellow-500/20 text-yellow-400';
  return 'bg-red-500/20 text-red-400';
}
