'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Play,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  Brain,
  Target,
  Zap,
  RotateCcw,
  ChevronRight,
  Clock,
  Heart,
  Shield,
  Lightbulb,
} from 'lucide-react';
import { useLifeMapStore, simulateOutcome } from '@/store/lifemap-store';

export default function SimulationEngine() {
  const { rootDecision, simulationResult, setSimulationResult, isSimulating, setIsSimulating } = useLifeMapStore();
  const [showResult, setShowResult] = useState(false);

  const canSimulate = rootDecision && rootDecision.outcomes.length > 0;

  const handleSimulate = async () => {
    if (!rootDecision || isSimulating) return;

    setIsSimulating(true);
    setShowResult(false);

    // Simulate processing delay for UX
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const result = simulateOutcome(rootDecision);
    setSimulationResult(result);
    setIsSimulating(false);
    setShowResult(true);
  };

  const handleReset = () => {
    setSimulationResult(null);
    setShowResult(false);
  };

  return (
    <div className="space-y-4">
      {/* Simulate Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-2xl overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <motion.div
                animate={isSimulating ? { rotate: 360 } : { rotate: 0 }}
                transition={{ duration: 1, repeat: isSimulating ? Infinity : 0, ease: 'linear' }}
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center"
              >
                {isSimulating ? (
                  <Sparkles className="w-6 h-6 text-white" />
                ) : (
                  <Play className="w-6 h-6 text-white ml-0.5" />
                )}
              </motion.div>
              <div className="flex-1">
                <h3 className="font-semibold text-white">Simulate Future</h3>
                <p className="text-xs text-white/40">
                  {canSimulate
                    ? `${rootDecision?.outcomes.length || 0} possible outcomes`
                    : 'Add outcomes to simulate'}
                </p>
              </div>
              <Button
                onClick={handleSimulate}
                disabled={!canSimulate || isSimulating}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white"
              >
                {isSimulating ? (
                  <>
                    <motion.div
                      animate={{ opacity: [1, 0.5, 1] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      Simulating...
                    </motion.div>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Simulate
                  </>
                )}
              </Button>
            </div>

            {/* Progress Bar during simulation */}
            <AnimatePresence>
              {isSimulating && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 space-y-2"
                >
                  <Progress value={66} className="h-1" />
                  <p className="text-xs text-white/30 text-center">
                    Running probabilistic simulation...
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>

      {/* Simulation Result */}
      <AnimatePresence>
        {showResult && simulationResult && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/5 backdrop-blur-xl border-green-500/20 rounded-2xl overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-2 text-base">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 300, delay: 0.2 }}
                    >
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                    </motion.div>
                    Simulation Result
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleReset}
                    className="text-white/50 hover:text-white"
                  >
                    <RotateCcw className="w-3 h-3 mr-1" />
                    Reset
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Outcome Title */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  className="p-4 rounded-xl bg-white/5 border border-white/10"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-white/50">Selected Outcome</p>
                      <p className="text-lg font-semibold text-white">{simulationResult.outcomeTitle}</p>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400 text-base px-3 py-1">
                      {simulationResult.probability}%
                    </Badge>
                  </div>
                </motion.div>

                {/* Confidence Score */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="grid grid-cols-2 gap-3"
                >
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-1">
                      <Target className="w-3 h-3 text-amber-400" />
                      <span className="text-xs text-white/50">Confidence</span>
                    </div>
                    <p className="text-lg font-semibold text-white">{simulationResult.confidence}%</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-3 h-3 text-blue-400" />
                      <span className="text-xs text-white/50">Timestamp</span>
                    </div>
                    <p className="text-sm font-medium text-white">
                      {new Date(simulationResult.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </motion.div>

                {/* Path */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  className="p-3 rounded-xl bg-white/5 border border-white/10"
                >
                  <p className="text-xs text-white/50 mb-2">Decision Path</p>
                  <div className="flex items-center gap-1 flex-wrap">
                    {simulationResult.path.map((step, index) => (
                      <span key={index} className="flex items-center gap-1">
                        <Badge variant="outline" className="border-white/20 text-white/70 text-xs">
                          {step}
                        </Badge>
                        {index < simulationResult.path.length - 1 && (
                          <ChevronRight className="w-3 h-3 text-white/30" />
                        )}
                      </span>
                    ))}
                  </div>
                </motion.div>

                {/* Insight */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  className="p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-pink-500/5 border border-purple-500/20"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                      <Lightbulb className="w-4 h-4 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-xs text-purple-400 font-medium mb-1">Insight</p>
                      <p className="text-sm text-white/70">{simulationResult.insight}</p>
                    </div>
                  </div>
                </motion.div>

                {/* Psychological Interpretation */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  className="p-4 rounded-xl bg-gradient-to-br from-blue-500/10 to-cyan-500/5 border border-blue-500/20"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <Brain className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-xs text-blue-400 font-medium mb-1">Psychological Interpretation</p>
                      <p className="text-sm text-white/70">{simulationResult.psychologicalInterpretation}</p>
                    </div>
                  </div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Extra Features */}
      {rootDecision && rootDecision.outcomes.length > 0 && !simulationResult && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="grid grid-cols-2 gap-3"
        >
          <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-xl p-3 opacity-50">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-white/30" />
              <span className="text-xs text-white/50">Timeline Mode</span>
            </div>
            <Badge className="mt-2 bg-white/5 text-white/30 text-[10px]">Coming Soon</Badge>
          </Card>
          <Card className="bg-black/40 backdrop-blur-xl border-white/5 rounded-xl p-3 opacity-50">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-white/30" />
              <span className="text-xs text-white/50">Compare A/B</span>
            </div>
            <Badge className="mt-2 bg-white/5 text-white/30 text-[10px]">Coming Soon</Badge>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
