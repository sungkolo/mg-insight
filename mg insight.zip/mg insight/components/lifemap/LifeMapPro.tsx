'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import {
  Plus,
  Trash2,
  Edit3,
  Check,
  X,
  Map,
  Network,
  GitBranch,
  Clock,
  Target,
  Sparkles,
  Save,
} from 'lucide-react';

// Node Type Definition
interface LifeNode {
  id: number;
  title: string;
  description: string;
  probability: number;
  createdAt: Date;
}

// Initial empty state
const initialNodes: LifeNode[] = [];

export default function LifeMapPro() {
  // State
  const [nodes, setNodes] = useState<LifeNode[]>(initialNodes);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  // Statistics calculation
  const totalNodes = nodes.length;
  const connections = 0; // For future implementation
  const decisions = nodes.length;

  // Create new node
  const createNode = useCallback(() => {
    const newNode: LifeNode = {
      id: Date.now(),
      title: 'New Life Decision',
      description: 'Click to edit this decision',
      probability: 50,
      createdAt: new Date(),
    };

    setNodes((prev) => [...prev, newNode]);
    setLastUpdated(new Date());
  }, []);

  // Delete node
  const deleteNode = useCallback((id: number) => {
    setNodes((prev) => prev.filter((node) => node.id !== id));
    setLastUpdated(new Date());
  }, []);

  // Start editing
  const startEditing = useCallback((node: LifeNode) => {
    setEditingId(node.id);
    setEditTitle(node.title);
    setEditDescription(node.description);
  }, []);

  // Cancel editing
  const cancelEditing = useCallback(() => {
    setEditingId(null);
    setEditTitle('');
    setEditDescription('');
  }, []);

  // Save edit
  const saveEdit = useCallback((id: number) => {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === id
          ? { ...node, title: editTitle, description: editDescription }
          : node
      )
    );
    setEditingId(null);
    setEditTitle('');
    setEditDescription('');
    setLastUpdated(new Date());
  }, [editTitle, editDescription]);

  // Update probability
  const updateProbability = useCallback((id: number, probability: number) => {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === id ? { ...node, probability } : node
      )
    );
    setLastUpdated(new Date());
  }, []);

  // Format date
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Get probability color
  const getProbabilityColor = (prob: number) => {
    if (prob >= 70) return 'text-green-400';
    if (prob >= 40) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950 p-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
            <Map className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">LifeMap Pro</h1>
            <p className="text-sm text-zinc-400">Map your life decisions with probabilistic insights</p>
          </div>
          <Badge className="ml-2 bg-amber-500/20 text-amber-400 border-amber-500/30">
            <Sparkles className="w-3 h-3 mr-1" />
            Premium
          </Badge>
        </div>
      </motion.div>

      {/* Statistics Cards */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8"
      >
        <Card className="bg-zinc-900/50 border-zinc-800 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Target className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-zinc-400">Total Nodes</span>
            </div>
            <p className="text-2xl font-bold text-white">{totalNodes}</p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/50 border-zinc-800 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Network className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-zinc-400">Connections</span>
            </div>
            <p className="text-2xl font-bold text-white">{connections}</p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/50 border-zinc-800 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <GitBranch className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-zinc-400">Decisions</span>
            </div>
            <p className="text-2xl font-bold text-white">{decisions}</p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/50 border-zinc-800 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-green-400" />
              <span className="text-xs text-zinc-400">Last Updated</span>
            </div>
            <p className="text-sm font-medium text-white">{formatDate(lastUpdated)}</p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Action Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="flex items-center justify-between mb-6"
      >
        <div className="flex items-center gap-2">
          <h2 className="text-lg font-semibold text-white">Your Life Map</h2>
          <Badge variant="outline" className="border-zinc-700 text-zinc-400">
            {totalNodes} nodes
          </Badge>
        </div>
        <Button
          onClick={createNode}
          className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Node
        </Button>
      </motion.div>

      {/* Nodes Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence>
          {nodes.map((node, index) => (
            <motion.div
              key={node.id}
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Card className="bg-zinc-900/70 border-zinc-800 rounded-xl hover:border-zinc-700 transition-all duration-300 shadow-lg hover:shadow-xl">
                <CardHeader className="pb-2">
                  {editingId === node.id ? (
                    <div className="space-y-2">
                      <Input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        placeholder="Title"
                        className="bg-zinc-800 border-zinc-700 text-white"
                        autoFocus
                      />
                      <Input
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        placeholder="Description"
                        className="bg-zinc-800 border-zinc-700 text-white text-sm"
                      />
                    </div>
                  ) : (
                    <CardTitle
                      className="text-white cursor-pointer hover:text-amber-400 transition-colors text-lg"
                      onClick={() => startEditing(node)}
                    >
                      {node.title}
                    </CardTitle>
                  )}
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Description */}
                  {editingId === node.id ? null : (
                    <p className="text-sm text-zinc-400 line-clamp-2">
                      {node.description}
                    </p>
                  )}

                  {/* Probability Section */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-zinc-500">Probability</span>
                      <span className={`text-sm font-bold ${getProbabilityColor(node.probability)}`}>
                        {node.probability}%
                      </span>
                    </div>
                    <Slider
                      value={[node.probability]}
                      onValueChange={([value]) => updateProbability(node.id, value)}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Meta Info */}
                  <div className="flex items-center justify-between text-xs text-zinc-500">
                    <span>Created: {formatDate(node.createdAt)}</span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                    {editingId === node.id ? (
                      <>
                        <Button
                          size="sm"
                          onClick={() => saveEdit(node.id)}
                          className="flex-1 bg-green-600 hover:bg-green-500 text-white"
                        >
                          <Check className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={cancelEditing}
                          className="flex-1 border-zinc-700 text-zinc-400 hover:text-white"
                        >
                          <X className="w-3 h-3 mr-1" />
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => startEditing(node)}
                          className="flex-1 border-zinc-700 text-zinc-400 hover:text-white hover:border-zinc-600"
                        >
                          <Edit3 className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteNode(node.id)}
                          className="flex-1 border-zinc-700 text-red-400 hover:text-red-300 hover:border-red-500/50 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Delete
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Empty State */}
      {nodes.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col items-center justify-center py-16"
        >
          <div className="w-20 h-20 rounded-2xl bg-zinc-800/50 border border-zinc-700 flex items-center justify-center mb-4">
            <GitBranch className="w-10 h-10 text-zinc-600" />
          </div>
          <h3 className="text-lg font-medium text-zinc-400 mb-2">No Life Nodes Yet</h3>
          <p className="text-sm text-zinc-500 text-center max-w-sm mb-6">
            Start mapping your life decisions by creating your first node. Each node represents a decision point in your journey.
          </p>
          <Button
            onClick={createNode}
            className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Your First Node
          </Button>
        </motion.div>
      )}
    </div>
  );
}
