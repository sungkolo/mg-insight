'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Network, X, BookOpen, Lightbulb, Target, Brain, Cpu, Users, Heart, BarChart3, Shield } from 'lucide-react';

interface KnowledgeNode {
  id: string;
  title: string;
  description: string;
  details: string[];
  connections: string[];
  icon: React.ElementType;
  position: { x: number; y: number };
  color: string;
}

const knowledgeNodes: KnowledgeNode[] = [
  {
    id: 'cognition',
    title: 'Kognitif',
    description: 'Memahami proses berpikir dan pengambilan keputusan',
    details: [
      'Proses kognitif melibatkan perhatian, memori, bahasa, dan pemecahan masalah',
      'Pola pikir dapat diubah melalui latihan dan kesadaran diri',
      'Bias kognitif mempengaruhi keputusan sehari-hari secara signifikan',
    ],
    connections: ['memory', 'decision'],
    icon: Brain,
    position: { x: 50, y: 20 },
    color: 'from-blue-500 to-cyan-600',
  },
  {
    id: 'memory',
    title: 'Memori',
    description: 'Mekanisme penyimpanan dan pengambilan informasi',
    details: [
      'Memori jangka pendek menyimpan informasi 15-30 detik',
      'Memori jangka panjang dapat menyimpan informasi seumur hidup',
      'Teknik mnemonik dapat meningkatkan kemampuan memori hingga 50%',
    ],
    connections: ['cognition', 'learning'],
    icon: BookOpen,
    position: { x: 20, y: 45 },
    color: 'from-purple-500 to-violet-600',
  },
  {
    id: 'decision',
    title: 'Pengambilan Keputusan',
    description: 'Proses memilih di antara alternatif yang tersedia',
    details: [
      'Keputusan optimal memerlukan informasi lengkap dan waktu yang cukup',
      'Intuisi berperan penting dalam keputusan kompleks',
      'Framework sistematis dapat meningkatkan kualitas keputusan',
    ],
    connections: ['cognition', 'emotion', 'analytics'],
    icon: Target,
    position: { x: 80, y: 40 },
    color: 'from-amber-500 to-orange-600',
  },
  {
    id: 'emotion',
    title: 'Emosi',
    description: 'Respons afektif terhadap stimulus internal dan eksternal',
    details: [
      'Emosi dasar: senang, sedih, marah, takut, terkejut, jijik',
      'Kecerdasan emosional dapat dikembangkan melalui praktik',
      'Regulasi emosi adalah kunci kesejahteraan mental',
    ],
    connections: ['decision', 'social'],
    icon: Heart,
    position: { x: 60, y: 60 },
    color: 'from-rose-500 to-pink-600',
  },
  {
    id: 'social',
    title: 'Interaksi Sosial',
    description: 'Dinamika hubungan dan komunikasi antar individu',
    details: [
      'Manusia adalah makhluk sosial yang memerlukan koneksi',
      'Empati adalah fondasi hubungan yang sehat',
      'Komunikasi efektif meningkatkan kualitas hubungan',
    ],
    connections: ['emotion', 'cognition'],
    icon: Users,
    position: { x: 30, y: 75 },
    color: 'from-emerald-500 to-green-600',
  },
  {
    id: 'analytics',
    title: 'Analisis Data',
    description: 'Pengolahan informasi untuk insight yang bermakna',
    details: [
      'Data mentah menjadi informasi melalui proses analisis',
      'Visualisasi membantu memahami pola kompleks',
      'AI dan machine learning mempercepat analisis prediktif',
    ],
    connections: ['decision', 'learning'],
    icon: BarChart3,
    position: { x: 85, y: 70 },
    color: 'from-cyan-500 to-blue-600',
  },
  {
    id: 'learning',
    title: 'Pembelajaran',
    description: 'Proses akuisisi pengetahuan dan keterampilan baru',
    details: [
      'Neuroplasticity memungkinkan otak terus berkembang',
      'Spaced repetition meningkatkan retensi pembelajaran',
      'Pembelajaran aktif lebih efektif dari pasif',
    ],
    connections: ['memory', 'cognition'],
    icon: Lightbulb,
    position: { x: 15, y: 90 },
    color: 'from-yellow-500 to-amber-600',
  },
];

export default function KnowledgeGraph() {
  const [selectedNode, setSelectedNode] = useState<KnowledgeNode | null>(null);

  return (
    <section className="section-padding bg-charcoal-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Knowledge Graph
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Peta </span>
            <span className="gradient-gold-text">Pengetahuan</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Eksplorasi konsep-konsep kunci dan hubungan antar domain dalam Mind Geometry.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Graph Visualization */}
          <div className="lg:col-span-2">
            <Card className="bg-charcoal-900/50 border-gold-500/10 overflow-hidden">
              <CardContent className="p-4 sm:p-6">
                <div className="relative h-[400px] sm:h-[500px]">
                  {/* SVG Connections */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none">
                    {knowledgeNodes.map((node) =>
                      node.connections.map((connId) => {
                        const connNode = knowledgeNodes.find((n) => n.id === connId);
                        if (!connNode) return null;
                        return (
                          <line
                            key={`${node.id}-${connId}`}
                            x1={`${node.position.x}%`}
                            y1={`${node.position.y}%`}
                            x2={`${connNode.position.x}%`}
                            y2={`${connNode.position.y}%`}
                            stroke={
                              selectedNode?.id === node.id || selectedNode?.id === connId
                                ? 'rgba(212, 165, 116, 0.5)'
                                : 'rgba(212, 165, 116, 0.1)'
                            }
                            strokeWidth={
                              selectedNode?.id === node.id || selectedNode?.id === connId ? 2 : 1
                            }
                            className="transition-all duration-300"
                          />
                        );
                      })
                    )}
                  </svg>

                  {/* Nodes */}
                  {knowledgeNodes.map((node) => {
                    const IconComponent = node.icon;
                    const isSelected = selectedNode?.id === node.id;
                    const isConnected = selectedNode?.connections.includes(node.id);

                    return (
                      <button
                        key={node.id}
                        className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${
                          isSelected ? 'z-20 scale-110' : 'z-10 hover:scale-105'
                        }`}
                        style={{ left: `${node.position.x}%`, top: `${node.position.y}%` }}
                        onClick={() => setSelectedNode(isSelected ? null : node)}
                      >
                        {/* Node glow */}
                        <div
                          className={`absolute inset-0 rounded-full blur-xl transition-opacity duration-300 ${
                            isSelected || isConnected ? 'opacity-30' : 'opacity-10'
                          } bg-gradient-to-r ${node.color}`}
                        />
                        
                        {/* Node circle */}
                        <div
                          className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-all duration-300 ${
                            isSelected
                              ? `bg-gradient-to-br ${node.color} shadow-lg`
                              : isConnected
                              ? 'bg-charcoal-700 border-2 border-gold-500/40'
                              : 'bg-charcoal-800 border-2 border-gold-500/20 hover:border-gold-500/40'
                          }`}
                        >
                          <IconComponent
                            className={`w-6 h-6 sm:w-7 sm:h-7 ${
                              isSelected ? 'text-white' : 'text-gold-400'
                            }`}
                          />
                        </div>
                        
                        {/* Node label */}
                        <div
                          className={`absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap transition-all duration-300 ${
                            isSelected ? 'text-gold-400 font-medium' : 'text-muted-foreground'
                          } text-xs sm:text-sm`}
                        >
                          {node.title}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detail Panel */}
          <div className="lg:col-span-1">
            {selectedNode ? (
              <Card className="bg-charcoal-900/50 border-gold-500/30 animate-fade-in sticky top-24">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-lg bg-gradient-to-br ${selectedNode.color} flex items-center justify-center`}
                      >
                        <selectedNode.icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">{selectedNode.title}</h4>
                        <span className="text-xs text-muted-foreground">Domain Pengetahuan</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedNode(null)}
                      className="p-1 hover:bg-charcoal-800 rounded transition-colors"
                    >
                      <X className="w-5 h-5 text-muted-foreground hover:text-foreground" />
                    </button>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4">{selectedNode.description}</p>

                  {/* Details */}
                  <div className="space-y-3 mb-4">
                    <div className="text-xs uppercase tracking-wider text-gold-400 font-medium">
                      Key Insights
                    </div>
                    <ul className="space-y-2">
                      {selectedNode.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-gold-500 mt-2 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Connected Concepts */}
                  <div className="pt-4 border-t border-gold-500/10">
                    <div className="text-xs uppercase tracking-wider text-muted-foreground mb-3">
                      Terhubung dengan
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {selectedNode.connections.map((connId) => {
                        const connNode = knowledgeNodes.find((n) => n.id === connId);
                        if (!connNode) return null;
                        return (
                          <button
                            key={connId}
                            onClick={() => setSelectedNode(connNode)}
                            className="px-3 py-1 rounded-full text-xs bg-gold-500/10 text-gold-400 border border-gold-500/20 hover:bg-gold-500/20 transition-colors"
                          >
                            {connNode.title}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-charcoal-900/30 border-gold-500/10">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-charcoal-800 flex items-center justify-center mx-auto mb-4">
                    <Network className="w-8 h-8 text-muted-foreground/30" />
                  </div>
                  <h4 className="font-medium text-foreground mb-2">Pilih Node</h4>
                  <p className="text-sm text-muted-foreground">
                    Klik salah satu node pada graf untuk melihat detail dan insight.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
