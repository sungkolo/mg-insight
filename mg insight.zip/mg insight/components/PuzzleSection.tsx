'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Puzzle, 
  RotateCcw, 
  Trophy, 
  Clock, 
  Zap, 
  Star, 
  Move,
  CheckCircle,
  AlertCircle,
  Target,
  Sparkles,
  ChevronRight,
  Timer,
  Award
} from 'lucide-react';

// Puzzle configuration
const GRID_SIZE = 5;
const TOTAL_TILES = GRID_SIZE * GRID_SIZE;

interface Tile {
  id: number;
  value: number;
  isEmpty: boolean;
}

interface GameStats {
  moves: number;
  time: number;
  score: number;
  isComplete: boolean;
  perfectMoves: boolean;
}

// Generate solved state
const generateSolvedState = (): Tile[] => {
  const tiles: Tile[] = [];
  for (let i = 1; i < TOTAL_TILES; i++) {
    tiles.push({ id: i, value: i, isEmpty: false });
  }
  tiles.push({ id: TOTAL_TILES, value: 0, isEmpty: true });
  return tiles;
};

// Shuffle tiles (ensuring solvability)
const shuffleTiles = (tiles: Tile[]): Tile[] => {
  const shuffled = [...tiles];
  
  // Perform random valid moves to ensure solvability
  const emptyIndex = shuffled.findIndex(t => t.isEmpty);
  let currentIndex = emptyIndex;
  
  for (let i = 0; i < 200; i++) {
    const possibleMoves = getValidMoves(currentIndex);
    const randomMove = possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
    
    // Swap
    [shuffled[currentIndex], shuffled[randomMove]] = [shuffled[randomMove], shuffled[currentIndex]];
    currentIndex = randomMove;
  }
  
  return shuffled;
};

// Get valid moves for a position
const getValidMoves = (emptyIndex: number): number[] => {
  const moves: number[] = [];
  const row = Math.floor(emptyIndex / GRID_SIZE);
  const col = emptyIndex % GRID_SIZE;
  
  if (row > 0) moves.push(emptyIndex - GRID_SIZE); // Up
  if (row < GRID_SIZE - 1) moves.push(emptyIndex + GRID_SIZE); // Down
  if (col > 0) moves.push(emptyIndex - 1); // Left
  if (col < GRID_SIZE - 1) moves.push(emptyIndex + 1); // Right
  
  return moves;
};

// Check if puzzle is solved
const checkWin = (tiles: Tile[]): boolean => {
  for (let i = 0; i < TOTAL_TILES - 1; i++) {
    if (tiles[i].value !== i + 1) return false;
  }
  return tiles[TOTAL_TILES - 1].isEmpty;
};

// Calculate correctness percentage
const calculateCorrectness = (tiles: Tile[]): number => {
  let correct = 0;
  for (let i = 0; i < TOTAL_TILES - 1; i++) {
    if (tiles[i].value === i + 1) correct++;
  }
  return Math.round((correct / (TOTAL_TILES - 1)) * 100);
};

export default function PuzzleSection() {
  const [tiles, setTiles] = useState<Tile[]>(generateSolvedState);
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'complete'>('idle');
  const [stats, setStats] = useState<GameStats>({
    moves: 0,
    time: 0,
    score: 0,
    isComplete: false,
    perfectMoves: false,
  });
  const [bestScore, setBestScore] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(null);
  const [draggedTile, setDraggedTile] = useState<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Start new game
  const startGame = useCallback(() => {
    const solved = generateSolvedState();
    const shuffled = shuffleTiles(solved);
    setTiles(shuffled);
    setGameState('playing');
    setStats({
      moves: 0,
      time: 0,
      score: 1000,
      isComplete: false,
      perfectMoves: true,
    });
    setFeedback({ message: 'Susun angka 1-24 berurutan!', type: 'info' });
  }, []);

  // Timer effect
  useEffect(() => {
    if (gameState === 'playing' && !stats.isComplete) {
      timerRef.current = setInterval(() => {
        setStats(prev => {
          const newTime = prev.time + 1;
          // Decrease score over time (max 5 minutes penalty)
          const timePenalty = Math.min(newTime * 2, 600);
          return {
            ...prev,
            time: newTime,
            score: Math.max(100, 1000 - prev.moves * 5 - timePenalty),
          };
        });
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [gameState, stats.isComplete]);

  // Move tile
  const moveTile = useCallback((index: number) => {
    if (gameState !== 'playing' || stats.isComplete) return;
    
    const emptyIndex = tiles.findIndex(t => t.isEmpty);
    const validMoves = getValidMoves(emptyIndex);
    
    if (!validMoves.includes(index)) {
      setFeedback({ message: 'Pindahkan ke kotak kosong!', type: 'warning' });
      return;
    }
    
    // Swap tiles
    const newTiles = [...tiles];
    [newTiles[index], newTiles[emptyIndex]] = [newTiles[emptyIndex], newTiles[index]];
    
    setTiles(newTiles);
    
    // Update stats
    setStats(prev => ({
      ...prev,
      moves: prev.moves + 1,
      score: Math.max(100, prev.score - 5),
      perfectMoves: prev.perfectMoves && calculateCorrectness(newTiles) > calculateCorrectness(tiles),
    }));
    
    // Check win
    if (checkWin(newTiles)) {
      setGameState('complete');
      setStats(prev => {
        const finalScore = prev.score + 200; // Bonus for completion
        if (!bestScore || finalScore > bestScore) {
          setBestScore(finalScore);
        }
        return {
          ...prev,
          isComplete: true,
          score: finalScore,
        };
      });
      setFeedback({ message: 'Luar biasa! Puzzle terselesaikan!', type: 'success' });
    } else {
      const correctness = calculateCorrectness(newTiles);
      if (correctness >= 90) {
        setFeedback({ message: 'Hampir selesai! Terus lanjutkan!', type: 'success' });
      } else if (correctness >= 70) {
        setFeedback({ message: 'Bagus! Kamu di jalur yang tepat!', type: 'info' });
      }
    }
  }, [gameState, stats.isComplete, tiles, bestScore]);

  // Drag handlers
  const handleDragStart = (index: number) => {
    if (tiles[index].isEmpty) return;
    setDraggedTile(index);
  };

  const handleDragEnd = () => {
    setDraggedTile(null);
  };

  const handleDrop = (targetIndex: number) => {
    if (draggedTile !== null) {
      moveTile(draggedTile);
    }
    setDraggedTile(null);
  };

  // Format time
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Get tier info
  const getScoreTier = (score: number) => {
    if (score >= 900) return { tier: 'Diamond', color: 'text-cyan-400', icon: Sparkles };
    if (score >= 700) return { tier: 'Gold', color: 'text-gold-400', icon: Trophy };
    if (score >= 500) return { tier: 'Silver', color: 'text-slate-300', icon: Award };
    if (score >= 300) return { tier: 'Bronze', color: 'text-amber-600', icon: Star };
    return { tier: 'Participant', color: 'text-muted-foreground', icon: Target };
  };

  const correctness = calculateCorrectness(tiles);
  const scoreTier = getScoreTier(stats.score);

  return (
    <section className="section-padding bg-charcoal-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />
      <div className="absolute top-1/4 right-0 w-64 h-64 bg-gold-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-0 w-48 h-48 bg-gold-500/3 rounded-full blur-3xl" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Premium Puzzle
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Mind </span>
            <span className="gradient-gold-text">Puzzle</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Susun angka 1-24 berurutan dari kiri ke kanan, atas ke bawah. 
            Geser kotak ke posisi kosong untuk memindahkan.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card className="bg-charcoal-900/50 border-gold-500/10 overflow-hidden">
            <CardContent className="p-4 sm:p-6 lg:p-8">
              {/* Game Stats Bar */}
              <div className="grid grid-cols-4 gap-3 mb-6">
                <div className="bg-charcoal-800/50 rounded-xl p-3 text-center border border-gold-500/5">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Clock className="w-3.5 h-3.5 text-gold-400" />
                    <span className="text-xs text-muted-foreground">Waktu</span>
                  </div>
                  <div className="text-lg sm:text-xl font-mono font-bold text-foreground">
                    {formatTime(stats.time)}
                  </div>
                </div>
                
                <div className="bg-charcoal-800/50 rounded-xl p-3 text-center border border-gold-500/5">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Move className="w-3.5 h-3.5 text-gold-400" />
                    <span className="text-xs text-muted-foreground">Langkah</span>
                  </div>
                  <div className="text-lg sm:text-xl font-mono font-bold text-foreground">
                    {stats.moves}
                  </div>
                </div>
                
                <div className="bg-charcoal-800/50 rounded-xl p-3 text-center border border-gold-500/5">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Target className="w-3.5 h-3.5 text-gold-400" />
                    <span className="text-xs text-muted-foreground">Progres</span>
                  </div>
                  <div className="text-lg sm:text-xl font-mono font-bold text-foreground">
                    {correctness}%
                  </div>
                </div>
                
                <div className="bg-charcoal-800/50 rounded-xl p-3 text-center border border-gold-500/5">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Star className="w-3.5 h-3.5 text-gold-400" />
                    <span className="text-xs text-muted-foreground">Skor</span>
                  </div>
                  <div className={`text-lg sm:text-xl font-mono font-bold ${scoreTier.color}`}>
                    {stats.score}
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              {gameState === 'playing' && (
                <div className="mb-6">
                  <div className="flex justify-between text-xs text-muted-foreground mb-2">
                    <span>Progress</span>
                    <span>{correctness}% benar</span>
                  </div>
                  <Progress 
                    value={correctness} 
                    className="h-2 bg-charcoal-800 [&>div]:bg-gradient-to-r [&>div]:from-gold-600 [&>div]:to-gold-400"
                  />
                </div>
              )}

              {/* Feedback Message */}
              {feedback && (
                <div className={`mb-6 p-3 rounded-xl flex items-center gap-2 animate-fade-in ${
                  feedback.type === 'success' ? 'bg-emerald-500/10 border border-emerald-500/20' :
                  feedback.type === 'warning' ? 'bg-amber-500/10 border border-amber-500/20' :
                  'bg-gold-500/10 border border-gold-500/20'
                }`}>
                  {feedback.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400" />}
                  {feedback.type === 'warning' && <AlertCircle className="w-4 h-4 text-amber-400" />}
                  {feedback.type === 'info' && <Sparkles className="w-4 h-4 text-gold-400" />}
                  <span className={`text-sm ${
                    feedback.type === 'success' ? 'text-emerald-400' :
                    feedback.type === 'warning' ? 'text-amber-400' :
                    'text-gold-400'
                  }`}>
                    {feedback.message}
                  </span>
                </div>
              )}

              {/* Game Board */}
              {gameState === 'idle' ? (
                <div className="text-center py-8 sm:py-12">
                  <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-gold-500/20 to-gold-600/10 border border-gold-500/20 flex items-center justify-center mx-auto mb-6">
                    <Puzzle className="w-12 h-12 text-gold-400" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-semibold text-foreground mb-3">
                    Sliding Puzzle 5×5
                  </h3>
                  <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
                    Susun angka 1-24 berurutan dengan memindahkan kotak ke posisi kosong. 
                    Semakin sedikit langkah dan waktu, semakin tinggi skor!
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Button
                      onClick={startGame}
                      size="lg"
                      className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold px-8"
                    >
                      Mulai Puzzle
                      <ChevronRight className="ml-2 w-4 h-4" />
                    </Button>
                  </div>
                  
                  {bestScore && (
                    <div className="mt-6 text-sm text-muted-foreground">
                      Skor Terbaik: <span className="text-gold-400 font-semibold">{bestScore}</span>
                    </div>
                  )}
                </div>
              ) : gameState === 'complete' ? (
                <div className="text-center py-6 sm:py-8 animate-fade-in">
                  <div className={`w-24 h-24 rounded-2xl bg-gradient-to-br ${
                    stats.score >= 700 ? 'from-gold-500 to-amber-600' :
                    stats.score >= 500 ? 'from-slate-400 to-slate-500' :
                    'from-amber-600 to-amber-700'
                  } flex items-center justify-center mx-auto mb-6 shadow-lg ${
                    stats.score >= 700 ? 'shadow-gold-500/30' : ''
                  }`}>
                    <scoreTier.icon className="w-12 h-12 text-white" />
                  </div>
                  
                  <div className="mb-2">
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20">
                      {scoreTier.tier} Tier
                    </span>
                  </div>
                  
                  <h3 className="text-2xl sm:text-3xl font-bold gradient-gold-text mb-2">
                    Selamat!
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Puzzle berhasil diselesaikan!
                  </p>
                  
                  {/* Score Breakdown */}
                  <div className="bg-charcoal-800/50 rounded-xl p-6 mb-6 border border-gold-500/10">
                    <div className="text-5xl font-bold gradient-gold-text mb-2">
                      {stats.score}
                    </div>
                    <div className="text-sm text-muted-foreground mb-4">Total Score</div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Timer className="w-4 h-4 text-gold-400" />
                        </div>
                        <div className="text-xl font-semibold text-foreground">{formatTime(stats.time)}</div>
                        <div className="text-xs text-muted-foreground">Waktu</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Move className="w-4 h-4 text-gold-400" />
                        </div>
                        <div className="text-xl font-semibold text-foreground">{stats.moves}</div>
                        <div className="text-xs text-muted-foreground">Langkah</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <Zap className="w-4 h-4 text-gold-400" />
                        </div>
                        <div className="text-xl font-semibold text-foreground">
                          {stats.moves <= 100 ? 'Optimal' : stats.moves <= 150 ? 'Baik' : 'Cukup'}
                        </div>
                        <div className="text-xs text-muted-foreground">Efisiensi</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Button
                      onClick={startGame}
                      className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold"
                    >
                      <RotateCcw className="mr-2 w-4 h-4" />
                      Main Lagi
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  {/* Puzzle Grid */}
                  <div 
                    className="grid gap-1.5 sm:gap-2 mb-6"
                    style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)` }}
                  >
                    {tiles.map((tile, index) => {
                      const isEmpty = tile.isEmpty;
                      const isCorrect = !isEmpty && tile.value === index + 1;
                      const isDraggable = !isEmpty && getValidMoves(tiles.findIndex(t => t.isEmpty)).includes(index);
                      
                      return (
                        <button
                          key={tile.id}
                          disabled={isEmpty || !isDraggable}
                          draggable={!isEmpty && isDraggable}
                          onDragStart={() => handleDragStart(index)}
                          onDragEnd={handleDragEnd}
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={() => handleDrop(index)}
                          onClick={() => moveTile(index)}
                          className={`
                            aspect-square rounded-lg sm:rounded-xl font-bold text-lg sm:text-xl
                            transition-all duration-200 transform select-none
                            ${isEmpty 
                              ? 'bg-charcoal-800/30 border-2 border-dashed border-gold-500/10' 
                              : isCorrect
                              ? 'bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 border-2 border-emerald-500/30 text-emerald-400 shadow-lg shadow-emerald-500/10'
                              : isDraggable
                              ? 'bg-charcoal-800 border-2 border-gold-500/20 text-foreground hover:border-gold-500/50 hover:bg-charcoal-700 hover:scale-105 cursor-pointer'
                              : 'bg-charcoal-800/70 border-2 border-gold-500/10 text-muted-foreground'
                            }
                            ${draggedTile === index ? 'opacity-50 scale-95' : ''}
                            ${isDraggable && !isEmpty ? 'hover:shadow-lg hover:shadow-gold-500/10' : ''}
                          `}
                        >
                          {!isEmpty && tile.value}
                        </button>
                      );
                    })}
                  </div>

                  {/* Controls */}
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      <span className="text-gold-400">{correctness}%</span> posisi benar
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={startGame}
                      className="text-muted-foreground hover:text-gold-400 hover:bg-gold-500/10"
                    >
                      <RotateCcw className="mr-2 w-4 h-4" />
                      Reset
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Tips Section */}
          {gameState === 'playing' && (
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card className="bg-charcoal-900/30 border-gold-500/5">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-gold-500/10 flex items-center justify-center flex-shrink-0">
                      <Target className="w-4 h-4 text-gold-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-foreground mb-1">Tips</h4>
                      <p className="text-xs text-muted-foreground">
                        Fokus pada baris pertama, lalu lanjutkan ke baris berikutnya.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-charcoal-900/30 border-gold-500/5">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-gold-500/10 flex items-center justify-center flex-shrink-0">
                      <Zap className="w-4 h-4 text-gold-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-foreground mb-1">Scoring</h4>
                      <p className="text-xs text-muted-foreground">
                        Semakin sedikit langkah dan waktu, semakin tinggi skor!
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
