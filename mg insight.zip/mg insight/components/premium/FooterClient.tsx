'use client';

import { useLanguage } from '@/context/language-context';

export function FooterClient() {
  const { t } = useLanguage();

  return (
    <div className="text-center text-sm text-muted-foreground">
      <p>{t.copyright}</p>
    </div>
  );
}
