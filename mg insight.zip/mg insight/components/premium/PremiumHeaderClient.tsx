'use client';

import { Badge } from '@/components/ui/badge';
import { Crown } from 'lucide-react';
import { LanguageToggle } from '@/components/LanguageToggle';
import { useLanguage } from '@/context/language-context';

interface PremiumHeaderClientProps {
  email?: string | null;
}

export function PremiumHeaderClient({ email }: PremiumHeaderClientProps) {
  const { t } = useLanguage();

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Crown className="w-6 h-6 text-gold-400" />
        <h1 className="text-xl font-bold text-foreground">{t.premiumAccess}</h1>
      </div>
      <div className="flex items-center gap-3">
        <LanguageToggle />
        <Badge className="bg-gradient-to-r from-gold-600 to-gold-500 text-charcoal-950 font-bold">
          <Crown className="w-3.5 h-3.5 mr-1.5" />
          PREMIUM
        </Badge>
        <span className="text-sm text-muted-foreground hidden sm:inline">
          {email}
        </span>
      </div>
    </div>
  );
}
