'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Brain,
  Map,
  Target,
  BookOpen,
  BarChart3,
  Settings,
  LogOut,
  Activity,
  Zap,
  Puzzle,
  User,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '@/context/language-context';
import { LanguageToggleCompact } from '@/components/LanguageToggle';

interface PremiumSidebarClientProps {
  name?: string | null;
  email?: string | null;
  daysRemaining?: number;
}

// Nav item component - defined outside to avoid re-creation
function NavItem({ 
  item, 
  isActive 
}: { 
  item: { label: string; href: string; icon: React.ElementType };
  isActive: boolean;
}) {
  const Icon = item.icon;
  
  return (
    <Link
      href={item.href}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group ${
        isActive 
          ? 'bg-gold-500/10 text-gold-400 border border-gold-500/20' 
          : 'text-muted-foreground hover:text-foreground hover:bg-gold-500/5'
      }`}
    >
      <Icon className={`w-5 h-5 ${isActive ? 'text-gold-400' : 'group-hover:text-gold-400'}`} />
      <span className="font-medium text-sm">{item.label}</span>
    </Link>
  );
}

// Section header component - defined outside to avoid re-creation
function SectionHeader({ title }: { title: string }) {
  return (
    <div className="px-3 py-2">
      <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
        {title}
      </span>
    </div>
  );
}

export function PremiumSidebarClient({ name, email, daysRemaining }: PremiumSidebarClientProps) {
  const { t } = useLanguage();
  const pathname = usePathname();

  // Main navigation
  const mainNavItems = [
    { label: t.dashboard, href: '/premium', icon: Brain },
  ];

  // Tools section - All free for logged-in users
  const toolsItems = [
    { label: t.lifeMapPro, href: '/premium/lifemap-pro', icon: Map },
    { label: t.mindJournalPro, href: '/premium/mind-journal-pro', icon: BookOpen },
    { label: t.probSimAdvanced, href: '/premium/probsim-advanced', icon: Target },
    { label: t.mindPuzzlePro, href: '/premium/mind-puzzle-advanced', icon: Puzzle },
    { label: t.realitySimulator, href: '/premium/reality-simulator', icon: Zap },
  ];

  // Analytics section
  const analyticsItems = [
    { label: t.moodAnalytics, href: '/premium/mood-analytics', icon: Activity },
    { label: t.usageStats, href: '/premium/analytics', icon: BarChart3 },
  ];

  return (
    <>
      {/* Welcome Status - Free Access Banner */}
      <div className="p-4 border-b border-gold-500/10">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-gold-400" />
          <span className="text-sm font-medium text-gold-400">{t.freeAccess || 'Free Access'}</span>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          {t.freeAccessDesc || 'All tools are free for personal growth and self-discovery.'}
        </p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* Main Navigation */}
        <div className="space-y-1">
          {mainNavItems.map((item) => (
            <NavItem key={item.href} item={item} isActive={pathname === item.href} />
          ))}
        </div>

        {/* Tools Section */}
        <div className="space-y-1">
          <SectionHeader title={t.tools || "Tools"} />
          {toolsItems.map((item) => (
            <NavItem key={item.href} item={item} isActive={pathname === item.href} />
          ))}
        </div>

        {/* Analytics Section */}
        <div className="space-y-1">
          <SectionHeader title={t.analytics || "Analytics"} />
          {analyticsItems.map((item) => (
            <NavItem key={item.href} item={item} isActive={pathname === item.href} />
          ))}
        </div>
      </nav>

      {/* User Info */}
      <div className="p-4 border-t border-gold-500/10">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 rounded-full bg-gold-500/10 flex items-center justify-center">
            <User className="w-4 h-4 text-gold-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {name || email?.split('@')[0]}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {email}
            </p>
          </div>
        </div>
        <div className="flex gap-2 mb-3">
          <Link 
            href="/" 
            className="flex-1 text-center px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-gold-500/5 transition-colors"
          >
            <Settings className="w-4 h-4 inline mr-2" />
            {t.settings}
          </Link>
          <Link 
            href="/api/auth/signout" 
            className="flex-1 text-center px-3 py-2 rounded-lg text-sm text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut className="w-4 h-4 inline mr-2" />
            {t.signOut}
          </Link>
        </div>
        <div className="flex justify-center">
          <LanguageToggleCompact />
        </div>
      </div>
    </>
  );
}
