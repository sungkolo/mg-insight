'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { X, Lightbulb, Heart, Briefcase, GraduationCap, Home, Sparkles } from 'lucide-react';

const lifeNodes = [
  {
    id: 1,
    title: 'Karir & Ambisi',
    icon: Briefcase,
    position: { x: 20, y: 25 },
    tips: [
      'Fokus pada pengembangan skill yang relevan dengan tujuan jangka panjang',
      'Bangun jaringan profesional yang mendukung pertumbuhan karir',
      'Evaluasi kepuasan kerja secara berkala dan sesuaikan arah jika diperlukan',
    ],
    color: 'from-amber-500 to-yellow-600',
  },
  {
    id: 2,
    title: 'Hubungan & Keluarga',
    icon: Heart,
    position: { x: 75, y: 20 },
    tips: [
      'Komunikasi terbuka adalah kunci hubungan yang sehat',
      'Alokasikan waktu berkualitas untuk orang-orang tercinta',
      'Pelajari bahasa cinta pasangan dan keluarga Anda',
    ],
    color: 'from-rose-500 to-pink-600',
  },
  {
    id: 3,
    title: 'Pertumbuhan Diri',
    icon: Sparkles,
    position: { x: 45, y: 50 },
    tips: [
      'Dedikasikan waktu untuk refleksi dan introspeksi mingguan',
      'Keluar dari zona nyaman secara teratur untuk pertumbuhan',
      'Praktikkan mindfulness dan gratitude setiap hari',
    ],
    color: 'from-purple-500 to-violet-600',
  },
  {
    id: 4,
    title: 'Pendidikan & Skill',
    icon: GraduationCap,
    position: { x: 15, y: 65 },
    tips: [
      'Tetaplah belajar - investasi terbaik adalah pada diri sendiri',
      'Kombinasikan pembelajaran teori dengan praktik langsung',
      'Carilah mentor di bidang yang ingin Anda kuasai',
    ],
    color: 'from-blue-500 to-cyan-600',
  },
  {
    id: 5,
    title: 'Keseimbangan Hidup',
    icon: Home,
    position: { x: 80, y: 60 },
    tips: [
      'Tetapkan batasan yang jelas antara kerja dan kehidupan pribadi',
      'Prioritaskan kesehatan fisik dan mental secara seimbang',
      'Ciptakan rutinitas yang mendukung well-being secara holistik',
    ],
    color: 'from-emerald-500 to-green-600',
  },
];

const connections = [
  { from: 1, to: 3 },
  { from: 2, to: 3 },
  { from: 3, to: 4 },
  { from: 3, to: 5 },
  { from: 1, to: 4 },
  { from: 2, to: 5 },
];

export default function LifeMap() {
  const [selectedNode, setSelectedNode] = useState<typeof lifeNodes[0] | null>(null);

  return (
    <section id="lifemap" className="section-padding relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 gradient-dark opacity-50" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Life Map
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Peta </span>
            <span className="gradient-gold-text">Kehidupan</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Eksplorasi berbagai dimensi kehidupan dan temukan tips untuk mengoptimalkan setiap aspek.
          </p>
        </div>

        {/* Life Map Visualization */}
        <div className="relative max-w-4xl mx-auto">
          <Card className="bg-charcoal-900/50 border-gold-500/10 overflow-hidden">
            <CardContent className="p-6 sm:p-8">
              {/* Map Container */}
              <div className="relative h-[400px] sm:h-[500px]">
                {/* SVG Connections */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  {connections.map((conn, idx) => {
                    const fromNode = lifeNodes.find(n => n.id === conn.from);
                    const toNode = lifeNodes.find(n => n.id === conn.to);
                    if (!fromNode || !toNode) return null;
                    return (
                      <line
                        key={idx}
                        x1={`${fromNode.position.x}%`}
                        y1={`${fromNode.position.y}%`}
                        x2={`${toNode.position.x}%`}
                        y2={`${toNode.position.y}%`}
                        stroke="rgba(212, 165, 116, 0.15)"
                        strokeWidth="1"
                        strokeDasharray="4,4"
                      />
                    );
                  })}
                </svg>

                {/* Nodes */}
                {lifeNodes.map((node) => {
                  const IconComponent = node.icon;
                  const isSelected = selectedNode?.id === node.id;
                  
                  return (
                    <button
                      key={node.id}
                      className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${
                        isSelected ? 'z-20 scale-110' : 'z-10 hover:scale-105'
                      }`}
                      style={{ left: `${node.position.x}%`, top: `${node.position.y}%` }}
                      onClick={() => setSelectedNode(isSelected ? null : node)}
                    >
                      {/* Node glow */}
                      <div className={`absolute inset-0 rounded-full blur-xl transition-opacity duration-300 ${
                        isSelected ? 'opacity-50' : 'opacity-20'
                      } bg-gradient-to-r ${node.color}`} />
                      
                      {/* Node circle */}
                      <div className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-300 ${
                        isSelected
                          ? `bg-gradient-to-br ${node.color} shadow-lg`
                          : 'bg-charcoal-800 border-2 border-gold-500/30 hover:border-gold-500/50'
                      }`}>
                        <IconComponent className={`w-7 h-7 sm:w-8 sm:h-8 ${
                          isSelected ? 'text-white' : 'text-gold-400'
                        }`} />
                      </div>
                      
                      {/* Node label */}
                      <div className={`absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap transition-all duration-300 ${
                        isSelected ? 'text-gold-400 font-medium' : 'text-muted-foreground'
                      } text-xs sm:text-sm`}>
                        {node.title}
                      </div>
                    </button>
                  );
                })}

                {/* Center indicator */}
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                  <div className="w-32 h-32 border border-gold-500/10 rounded-full animate-pulse" />
                  <div className="absolute inset-4 border border-gold-500/10 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tips Panel */}
          {selectedNode && (
            <Card className="mt-6 bg-charcoal-900/80 border-gold-500/30 animate-fade-in">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${selectedNode.color} flex items-center justify-center`}>
                      <selectedNode.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{selectedNode.title}</h4>
                      <span className="text-xs text-muted-foreground">Tips & Insight</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedNode(null)}
                    className="p-1 hover:bg-charcoal-800 rounded transition-colors"
                  >
                    <X className="w-5 h-5 text-muted-foreground hover:text-foreground" />
                  </button>
                </div>
                
                <ul className="space-y-3">
                  {selectedNode.tips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Lightbulb className="w-4 h-4 text-gold-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </section>
  );
}
