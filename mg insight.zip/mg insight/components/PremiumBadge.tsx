'use client';

import { useSession } from 'next-auth/react';
import { Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FreeAccessBadgeProps {
  className?: string;
  variant?: 'default' | 'compact' | 'large';
  showIcon?: boolean;
}

// Renamed from PremiumBadge to reflect free access model
export default function PremiumBadge({ 
  className, 
  variant = 'default',
  showIcon = true 
}: FreeAccessBadgeProps) {
  const { data: session } = useSession();

  // Don't render if not logged in
  if (!session?.user) {
    return null;
  }

  const variants = {
    default: 'px-3 py-1 text-xs',
    compact: 'px-2 py-0.5 text-[10px]',
    large: 'px-4 py-2 text-sm',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full',
        'bg-gradient-to-r from-gold-600 to-gold-500',
        'text-charcoal-950 font-bold',
        'shadow-lg shadow-gold-500/20',
        variants[variant],
        className
      )}
    >
      {showIcon && (
        <Sparkles className={cn(
          'text-charcoal-950',
          variant === 'large' ? 'w-4 h-4' : variant === 'compact' ? 'w-3 h-3' : 'w-3.5 h-3.5'
        )} />
      )}
      <span className="uppercase tracking-wide">Free Access</span>
    </div>
  );
}

// Free access status indicator for logged-in users
export function FreeAccessStatus({ className }: { className?: string }) {
  const { data: session } = useSession();

  if (!session?.user) return null;

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gold-500/20 border border-gold-500/30">
        <Sparkles className="w-3.5 h-3.5 text-gold-400" />
        <span className="text-xs font-medium text-gold-400">Free Access</span>
      </div>
    </div>
  );
}

// Auth lock for features - now just checks login status
export function AuthLock({ 
  children, 
  locked = false,
  className 
}: { 
  children: React.ReactNode;
  locked?: boolean;
  className?: string;
}) {
  const { data: session } = useSession();
  const isLoggedIn = !!session?.user;

  if (isLoggedIn || !locked) {
    return <>{children}</>;
  }

  return (
    <div className={cn('relative', className)}>
      <div className="opacity-50 pointer-events-none blur-sm">
        {children}
      </div>
      <div className="absolute inset-0 flex items-center justify-center bg-charcoal-950/60 backdrop-blur-sm rounded-lg">
        <div className="flex flex-col items-center gap-2 p-4">
          <div className="w-12 h-12 rounded-full bg-gold-500/20 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-gold-400" />
          </div>
          <span className="text-sm font-medium text-foreground">Sign In Required</span>
          <span className="text-xs text-muted-foreground text-center">
            Free for all registered users
          </span>
        </div>
      </div>
    </div>
  );
}

// Legacy exports for backwards compatibility
export const PremiumStatus = FreeAccessStatus;
export const PremiumLock = AuthLock;
