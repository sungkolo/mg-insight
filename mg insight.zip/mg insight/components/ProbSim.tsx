'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { BarChart3, TrendingUp, Target, AlertCircle, CheckCircle, ArrowRight } from 'lucide-react';

interface SimulationResult {
  label: string;
  value: number;
  color: string;
}

export default function ProbSim() {
  const [event, setEvent] = useState('');
  const [confidence, setConfidence] = useState([70]);
  const [importance, setImportance] = useState([80]);
  const [effort, setEffort] = useState([50]);

  // Calculate results directly using useMemo - no useEffect needed
  const results: SimulationResult[] = useMemo(() => {
    if (event.length <= 3) return [];
    
    const successProbability = Math.min(95, Math.max(5,
      (confidence[0] * 0.4 + importance[0] * 0.3 + (100 - effort[0]) * 0.3)
    ));
    
    const riskFactor = Math.max(5, 100 - successProbability);
    const opportunityScore = Math.min(100, importance[0] * 0.6 + successProbability * 0.4);
    const readinessScore = Math.min(100, confidence[0] * 0.7 + (100 - effort[0]) * 0.3);

    return [
      { label: 'Probabilitas Sukses', value: Math.round(successProbability), color: 'bg-emerald-500' },
      { label: 'Faktor Risiko', value: Math.round(riskFactor), color: 'bg-rose-500' },
      { label: 'Skor Peluang', value: Math.round(opportunityScore), color: 'bg-gold-500' },
      { label: 'Tingkat Kesiapan', value: Math.round(readinessScore), color: 'bg-blue-500' },
    ];
  }, [event, confidence, importance, effort]);

  const recommendation = useMemo(() => {
    if (results.length === 0) return null;
    
    const success = results[0].value;
    if (success >= 75) {
      return {
        text: 'Sangat Direkomendasikan! Peluang sukses tinggi dengan risiko yang terkendali.',
        icon: CheckCircle,
        color: 'text-emerald-400',
      };
    } else if (success >= 50) {
      return {
        text: 'Layak Dipertimbangkan. Pertimbangkan mitigasi risiko sebelum melangkah.',
        icon: Target,
        color: 'text-gold-400',
      };
    } else {
      return {
        text: 'Perlu Pertimbangan Lebih. Risiko cukup tinggi, pertimbangkan alternatif lain.',
        icon: AlertCircle,
        color: 'text-rose-400',
      };
    }
  }, [results]);

  return (
    <section className="section-padding relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 gradient-dark opacity-50" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Probability Simulator
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Simulator </span>
            <span className="gradient-gold-text">Probabilitas</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Masukkan keputusan atau rencana Anda dan lihat visualisasi probabilitas sukses secara real-time.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Input Panel */}
          <Card className="bg-charcoal-900/50 border-gold-500/10">
            <CardContent className="p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gold-500/20 flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-gold-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Parameter Input</h3>
                  <span className="text-xs text-muted-foreground">Masukkan variabel keputusan</span>
                </div>
              </div>

              {/* Event Input */}
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="event" className="text-muted-foreground">
                    Keputusan / Rencana
                  </Label>
                  <Input
                    id="event"
                    placeholder="Contoh: Memulai bisnis online..."
                    value={event}
                    onChange={(e) => setEvent(e.target.value)}
                    className="bg-charcoal-800/50 border-gold-500/20 focus:border-gold-500/50 text-foreground placeholder:text-muted-foreground/50"
                  />
                </div>

                {/* Confidence Slider */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <Label className="text-muted-foreground">Tingkat Keyakinan</Label>
                    <span className="text-gold-400 font-medium">{confidence[0]}%</span>
                  </div>
                  <Slider
                    value={confidence}
                    onValueChange={setConfidence}
                    max={100}
                    step={1}
                    className="[&_[role=slider]]:bg-gold-500 [&_[role=slider]]:border-gold-400 [&_.bg-primary]:bg-gold-500/20"
                  />
                </div>

                {/* Importance Slider */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <Label className="text-muted-foreground">Tingkat Kepentingan</Label>
                    <span className="text-gold-400 font-medium">{importance[0]}%</span>
                  </div>
                  <Slider
                    value={importance}
                    onValueChange={setImportance}
                    max={100}
                    step={1}
                    className="[&_[role=slider]]:bg-gold-500 [&_[role=slider]]:border-gold-400 [&_.bg-primary]:bg-gold-500/20"
                  />
                </div>

                {/* Effort Slider */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <Label className="text-muted-foreground">Tingkat Usaha yang Dibutuhkan</Label>
                    <span className="text-gold-400 font-medium">{effort[0]}%</span>
                  </div>
                  <Slider
                    value={effort}
                    onValueChange={setEffort}
                    max={100}
                    step={1}
                    className="[&_[role=slider]]:bg-gold-500 [&_[role=slider]]:border-gold-400 [&_.bg-primary]:bg-gold-500/20"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results Panel */}
          <Card className="bg-charcoal-900/50 border-gold-500/10 transition-all duration-300">
            <CardContent className="p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gold-500/20 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-gold-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Hasil Simulasi</h3>
                  <span className="text-xs text-muted-foreground">Analisis probabilitas</span>
                </div>
              </div>

              {results.length > 0 && event.length > 3 ? (
                <div className="space-y-6">
                  {/* Bar Charts */}
                  <div className="space-y-4">
                    {results.map((result, idx) => (
                      <div key={idx} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">{result.label}</span>
                          <span className="text-sm font-medium text-foreground">{result.value}%</span>
                        </div>
                        <div className="h-3 bg-charcoal-800 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${result.color} rounded-full transition-all duration-500`}
                            style={{ width: `${result.value}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Recommendation */}
                  {recommendation && (
                    <div className="mt-6 p-4 rounded-xl bg-charcoal-800/50 border border-gold-500/10">
                      <div className="flex items-start gap-3">
                        <recommendation.icon className={`w-5 h-5 ${recommendation.color} mt-0.5 flex-shrink-0`} />
                        <div>
                          <div className="text-sm font-medium text-foreground mb-1">Rekomendasi</div>
                          <p className="text-sm text-muted-foreground">{recommendation.text}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Decision Matrix */}
                  <div className="grid grid-cols-2 gap-3 mt-4">
                    <div className="p-3 rounded-lg bg-charcoal-800/30 text-center">
                      <div className="text-2xl font-bold gradient-gold-text">{results[0].value}%</div>
                      <div className="text-xs text-muted-foreground">Success Rate</div>
                    </div>
                    <div className="p-3 rounded-lg bg-charcoal-800/30 text-center">
                      <div className="text-2xl font-bold text-foreground">
                        {results[0].value >= 70 ? 'High' : results[0].value >= 40 ? 'Medium' : 'Low'}
                      </div>
                      <div className="text-xs text-muted-foreground">Confidence</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-full bg-charcoal-800 flex items-center justify-center mx-auto mb-4">
                      <ArrowRight className="w-8 h-8 text-muted-foreground/30" />
                    </div>
                    <p className="text-muted-foreground text-sm">
                      Masukkan keputusan untuk melihat simulasi
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
