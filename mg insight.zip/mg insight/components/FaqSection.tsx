'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronDown, HelpCircle } from 'lucide-react';

const faqs = [
  {
    id: 1,
    question: 'Apa itu Mind Geometry dan bagaimana cara kerjanya?',
    answer: 'Mind Geometry adalah metodologi analisis kognitif yang memetakan pola pikir, perilaku, dan keputusan ke dalam model geometri multi-dimensi. Dengan menganalisis data interaksi Anda, sistem kami mengidentifikasi pola tersembunyi dan memberikan insight yang dapat ditindaklanjuti untuk pengembangan diri yang optimal.',
  },
  {
    id: 2,
    question: 'Apakah data saya aman dan bagaimana privasi dilindungi?',
    answer: 'Keamanan data adalah prioritas utama kami. Semua data dienkripsi dengan standar 256-bit AES dan disimpan di server yang memenuhi sertifikasi ISO 27001. Kami tidak pernah menjual atau membagikan data Anda ke pihak ketiga. Anda memiliki kontrol penuh atas data Anda dan dapat menghapusnya kapan saja.',
  },
  {
    id: 3,
    question: 'Berapa lama waktu yang dibutuhkan untuk melihat hasil?',
    answer: 'Sebagian besar pengguna mulai melihat insight yang bermakna dalam 7-14 hari penggunaan aktif. Namun, untuk hasil yang komprehensif dan pola yang akurat, kami merekomendasikan penggunaan minimal 30 hari. Semakin banyak interaksi, semakin personal dan akurat insight yang dihasilkan.',
  },
  {
    id: 4,
    question: 'Apakah MG Insight cocok untuk semua orang?',
    answer: 'MG Insight dirancang untuk individu yang berkomitmen pada pengembangan diri - mulai dari profesional, entrepreneur, hingga mereka yang sedang dalam transisi karir atau kehidupan. Platform ini paling efektif bagi mereka yang terbuka untuk introspeksi dan siap mengambil tindakan berdasarkan insight yang diberikan.',
  },
];

export default function FaqSection() {
  const [openId, setOpenId] = useState<number | null>(null);

  const toggleFaq = (id: number) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section id="faq" className="section-padding bg-charcoal-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />
      
      {/* Floating elements */}
      <div className="absolute top-20 left-10 w-32 h-32 border border-gold-500/5 rounded-full" />
      <div className="absolute bottom-20 right-10 w-24 h-24 border border-gold-500/5 rounded-full" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            FAQ
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Pertanyaan </span>
            <span className="gradient-gold-text">Umum</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Temukan jawaban untuk pertanyaan yang sering diajukan tentang MG Insight.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq) => (
            <Card
              key={faq.id}
              className={`bg-charcoal-900/50 border-gold-500/10 transition-all duration-300 cursor-pointer hover:border-gold-500/20 ${
                openId === faq.id ? 'border-gold-500/30 shadow-lg shadow-gold-500/5' : ''
              }`}
              onClick={() => toggleFaq(faq.id)}
            >
              <CardContent className="p-0">
                {/* Question Header */}
                <div className="flex items-center justify-between p-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors duration-300 ${
                      openId === faq.id 
                        ? 'bg-gold-500/20 border border-gold-500/30' 
                        : 'bg-charcoal-800 border border-gold-500/10'
                    }`}>
                      <HelpCircle className={`w-5 h-5 transition-colors duration-300 ${
                        openId === faq.id ? 'text-gold-400' : 'text-muted-foreground'
                      }`} />
                    </div>
                    <h3 className={`font-medium transition-colors duration-300 ${
                      openId === faq.id ? 'text-gold-400' : 'text-foreground'
                    }`}>
                      {faq.question}
                    </h3>
                  </div>
                  <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-300 ${
                    openId === faq.id ? 'rotate-180 text-gold-400' : ''
                  }`} />
                </div>

                {/* Answer */}
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openId === faq.id ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}
                >
                  <div className="px-6 pb-6 pt-0">
                    <div className="pl-14 border-l border-gold-500/10 ml-5">
                      <p className="text-muted-foreground leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Help */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Masih punya pertanyaan lain?
          </p>
          <span className="text-gold-400 hover:text-gold-300 cursor-pointer transition-colors inline-flex items-center gap-2">
            Hubungi tim support kami
            <HelpCircle className="w-4 h-4" />
          </span>
        </div>
      </div>
    </section>
  );
}
