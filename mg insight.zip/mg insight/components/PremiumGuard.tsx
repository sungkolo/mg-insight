'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect, useSyncExternalStore } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Lock, ArrowLeft } from 'lucide-react';

// Custom hook to check if we're mounted (avoids hydration issues)
function useMounted() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}

interface AuthGuardProps {
  children: React.ReactNode;
  redirectToLogin?: boolean;
}

// Component to guard content - requires login only (all features are free)
export function PremiumGuard({ 
  children, 
  redirectToLogin = false,
}: AuthGuardProps) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const mounted = useMounted();

  useEffect(() => {
    if (mounted && redirectToLogin) {
      if (status === 'unauthenticated') {
        router.push('/login?redirect=/premium');
      }
    }
  }, [mounted, status, router, redirectToLogin]);

  // Don't render during SSR
  if (!mounted) {
    return (
      <div className="min-h-screen bg-charcoal-950 flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gold-500/20" />
          <div className="w-24 h-4 bg-gold-500/20 rounded" />
        </div>
      </div>
    );
  }

  // Loading state
  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-charcoal-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-2 border-gold-500/30 border-t-gold-500 animate-spin" />
          <span className="text-muted-foreground">Loading...</span>
        </div>
      </div>
    );
  }

  // Not authenticated
  if (!session) {
    if (redirectToLogin) {
      return null; // Will redirect
    }
    
    return (
      <div className="min-h-screen bg-charcoal-950 flex items-center justify-center p-4">
        <Card className="max-w-md w-full bg-charcoal-900/50 border-gold-500/20">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-gold-500/20 flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8 text-gold-400" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">
              Sign In Required
            </h2>
            <p className="text-muted-foreground mb-6">
              Create a free account to access all MG Insight tools. No payment required.
            </p>
            <div className="flex flex-col gap-3">
              <Link href="/login">
                <Button className="w-full bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold">
                  Sign In
                </Button>
              </Link>
              <Link href="/signup">
                <Button variant="outline" className="w-full border-gold-500/30 text-gold-400 hover:bg-gold-500/10">
                  Create Free Account
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // User is logged in - all features are free
  return <>{children}</>;
}

// Component for conditional rendering based on auth status
interface AuthContentProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function PremiumContent({ children, fallback = null }: AuthContentProps) {
  const { data: session } = useSession();

  // All logged-in users have access
  if (session?.user) {
    return <>{children}</>;
  }

  return <>{fallback}</>;
}

// Component to show content only to non-logged-in users
export function FreeOnlyContent({ children }: { children: React.ReactNode }) {
  const { data: session } = useSession();

  if (!session) {
    return <>{children}</>;
  }

  return null;
}

// Component to show locked feature card (for non-logged-in users)
interface LockedFeatureCardProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
}

export function LockedFeatureCard({ title, description, icon }: LockedFeatureCardProps) {
  return (
    <Card className="bg-charcoal-900/50 border-gold-500/10 relative overflow-hidden group">
      {/* Locked overlay */}
      <div className="absolute inset-0 bg-charcoal-950/60 backdrop-blur-sm z-10 flex items-center justify-center">
        <div className="text-center p-6">
          <div className="w-12 h-12 rounded-full bg-gold-500/20 flex items-center justify-center mx-auto mb-3">
            <Lock className="w-6 h-6 text-gold-400" />
          </div>
          <p className="text-sm font-medium text-foreground mb-1">Sign In Required</p>
          <p className="text-xs text-muted-foreground mb-4">Free for all registered users</p>
          <Link href="/signup">
            <Button size="sm" className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold">
              Create Free Account
            </Button>
          </Link>
        </div>
      </div>

      {/* Original content (blurred) */}
      <CardContent className="p-6 opacity-50 blur-sm">
        <div className="flex items-start gap-4">
          {icon && (
            <div className="p-3 rounded-xl bg-gold-500/20">
              {icon}
            </div>
          )}
          <div>
            <h3 className="text-lg font-semibold text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Alias for backwards compatibility
export const AuthGuard = PremiumGuard;
export const AuthContent = PremiumContent;
