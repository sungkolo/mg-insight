'use client';

import Script from 'next/script';

// Google Analytics Component
// Replace GA_MEASUREMENT_ID with your actual Google Analytics ID
// Example: G-XXXXXXXXXX

export default function GoogleAnalytics() {
  const GA_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GA_ID || '';

  // Don't render if no GA ID is configured
  if (!GA_MEASUREMENT_ID) {
    return null;
  }

  return (
    <>
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`}
        strategy="afterInteractive"
      />
      <Script id="google-analytics" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${GA_MEASUREMENT_ID}', {
            page_title: document.title,
            page_location: window.location.href,
          });
        `}
      </Script>
    </>
  );
}

// Analytics event tracking helper
export const trackEvent = (
  action: string,
  category: string,
  label: string,
  value?: number
) => {
  if (typeof window !== 'undefined' && 'gtag' in window) {
    (window as unknown as { gtag: (...args: unknown[]) => void }).gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Predefined tracking events for MG Insight
export const analyticsEvents = {
  // Puzzle interactions
  puzzleStarted: () => trackEvent('start', 'puzzle', 'mind_puzzle'),
  puzzleCompleted: (score: number) => trackEvent('complete', 'puzzle', 'mind_puzzle', score),
  
  // Journal interactions
  journalEntry: () => trackEvent('submit', 'journal', 'mind_journal'),
  
  // Life Map interactions
  lifeMapNodeClicked: (node: string) => trackEvent('click', 'lifemap', node),
  
  // Psych Experiment
  psychTestStarted: () => trackEvent('start', 'psych_experiment', 'assessment'),
  psychTestCompleted: (result: string) => trackEvent('complete', 'psych_experiment', result),
  
  // Probability Simulator
  probSimUsed: () => trackEvent('use', 'probsim', 'probability_simulator'),
  
  // Knowledge Graph
  knowledgeGraphNodeClicked: (node: string) => trackEvent('click', 'knowledge_graph', node),
  
  // Resource pages
  documentationViewed: () => trackEvent('view', 'resources', 'documentation'),
  blogViewed: (article: string) => trackEvent('view', 'resources', `blog_${article}`),
  
  // CTA clicks
  ctaClicked: (location: string) => trackEvent('click', 'cta', location),
};
