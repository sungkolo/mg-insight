'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Menu, X, ChevronDown, BookOpen, FileText, LogOut, User, Loader2, LayoutDashboard } from 'lucide-react';

const navItems = [
  { label: 'Preview', href: '/#preview' },
  { label: 'Fitur', href: '/#fitur' },
  { label: 'LifeMap', href: '/#lifemap' },
  { label: 'FAQ', href: '/#faq' },
];

const resourceItems = [
  { 
    label: 'Documentation', 
    href: '/resources/documentation',
    icon: BookOpen,
    description: 'Panduan lengkap penggunaan platform'
  },
  { 
    label: 'Blog', 
    href: '/resources/blog',
    icon: FileText,
    description: 'Artikel dan insight terbaru'
  },
];

export default function StickyBrand() {
  const { data: session, status } = useSession();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isResourceOpen, setIsResourceOpen] = useState(false);
  const [isMobileResourceOpen, setIsMobileResourceOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const resourceRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (resourceRef.current && !resourceRef.current.contains(event.target as Node)) {
        setIsResourceOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Check if current path is a resource page
  const isResourcePage = pathname.startsWith('/resources');

  // Smooth scroll for anchor links
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('/#')) {
      e.preventDefault();
      const id = href.replace('/#', '');
      const element = document.getElementById(id);
      if (element) {
        const headerOffset = 80;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
        setIsMobileMenuOpen(false);
      }
    }
  };

  const handleSignOut = async () => {
    await signOut({ callbackUrl: '/' });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-charcoal-950/95 backdrop-blur-md border-b border-gold-500/10 shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="container-width px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10 sm:w-12 sm:h-12">
              <div className="absolute inset-0 gradient-gold rounded-lg rotate-45 group-hover:rotate-[50deg] transition-transform duration-300" />
              <div className="absolute inset-1 bg-charcoal-950 rounded-md rotate-45" />
              <span className="absolute inset-0 flex items-center justify-center font-bold text-gold-500 text-lg">
                MG
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-lg sm:text-xl font-bold text-foreground group-hover:text-gold-400 transition-colors">
                MG Insight
              </span>
              <span className="text-[10px] sm:text-xs text-muted-foreground tracking-widest uppercase">
                Mind Geometry
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8">
            {navItems.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className="text-sm text-muted-foreground hover:text-gold-400 transition-colors relative group"
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gold-500 group-hover:w-full transition-all duration-300" />
              </Link>
            ))}
            
            {/* Resource Dropdown */}
            <div ref={resourceRef} className="relative">
              <button
                onClick={() => setIsResourceOpen(!isResourceOpen)}
                className={`flex items-center gap-1 text-sm transition-colors relative group ${
                  isResourcePage ? 'text-gold-400' : 'text-muted-foreground hover:text-gold-400'
                }`}
              >
                Resources
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isResourceOpen ? 'rotate-180' : ''}`} />
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-gold-500 transition-all duration-300 ${isResourceOpen || isResourcePage ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </button>
              
              {/* Dropdown Menu */}
              {isResourceOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-4 w-64 animate-fade-in">
                  <div className="bg-charcoal-900/95 backdrop-blur-md border border-gold-500/20 rounded-xl shadow-xl shadow-black/20 overflow-hidden">
                    {resourceItems.map((item, index) => {
                      const IconComponent = item.icon;
                      return (
                        <Link
                          key={item.label}
                          href={item.href}
                          onClick={() => setIsResourceOpen(false)}
                          className={`flex items-start gap-3 p-4 hover:bg-gold-500/10 transition-colors group ${
                            index !== resourceItems.length - 1 ? 'border-b border-gold-500/10' : ''
                          }`}
                        >
                          <div className="w-9 h-9 rounded-lg bg-gold-500/10 border border-gold-500/20 flex items-center justify-center flex-shrink-0 group-hover:bg-gold-500/20 transition-colors">
                            <IconComponent className="w-4 h-4 text-gold-400" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground group-hover:text-gold-400 transition-colors">
                              {item.label}
                            </div>
                            <div className="text-xs text-muted-foreground mt-0.5">
                              {item.description}
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                  {/* Dropdown Arrow */}
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rotate-45 bg-charcoal-900 border-l border-t border-gold-500/20" />
                </div>
              )}
            </div>
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            {status === 'loading' ? (
              <Loader2 className="w-5 h-5 animate-spin text-gold-400" />
            ) : session ? (
              <>
                {/* User Menu */}
                <div ref={userMenuRef} className="relative">
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gold-500/10 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-full bg-gold-500/20 flex items-center justify-center">
                      <User className="w-4 h-4 text-gold-400" />
                    </div>
                    <span className="text-sm text-foreground max-w-[120px] truncate">
                      {session.user?.name || session.user?.email?.split('@')[0]}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isUserMenuOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isUserMenuOpen && (
                    <div className="absolute top-full right-0 mt-2 w-64 animate-fade-in">
                      <div className="bg-charcoal-900/95 backdrop-blur-md border border-gold-500/20 rounded-xl shadow-xl shadow-black/20 overflow-hidden">
                        {/* User Info */}
                        <div className="px-4 py-3 border-b border-gold-500/10">
                          <div className="text-sm font-medium text-foreground truncate">
                            {session.user?.email}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className="bg-gold-500/20 text-gold-400 text-xs">
                              Free Account
                            </Badge>
                          </div>
                        </div>
                        
                        {/* Menu Items */}
                        <div className="py-1">
                          <Link
                            href="/premium"
                            onClick={() => setIsUserMenuOpen(false)}
                            className="flex items-center gap-2 px-4 py-2.5 hover:bg-gold-500/10 transition-colors"
                          >
                            <LayoutDashboard className="w-4 h-4 text-gold-400" />
                            <span className="text-sm text-foreground">Dashboard</span>
                          </Link>

                          <Link
                            href="/resources/documentation"
                            onClick={() => setIsUserMenuOpen(false)}
                            className="flex items-center gap-2 px-4 py-2.5 hover:bg-gold-500/10 transition-colors"
                          >
                            <BookOpen className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm text-foreground">Documentation</span>
                          </Link>
                        </div>

                        {/* Sign Out */}
                        <div className="border-t border-gold-500/10 pt-1 pb-1">
                          <button
                            onClick={handleSignOut}
                            className="flex items-center gap-2 px-4 py-2.5 hover:bg-red-500/10 transition-colors w-full"
                          >
                            <LogOut className="w-4 h-4 text-red-400" />
                            <span className="text-sm text-red-400">Sign Out</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button 
                    variant="ghost"
                    className="text-gold-400 hover:text-gold-300 hover:bg-gold-500/10"
                  >
                    Sign In
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button 
                    className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold"
                  >
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-muted-foreground hover:text-gold-400 transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gold-500/10 animate-fade-in">
            <nav className="flex flex-col gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className="text-muted-foreground hover:text-gold-400 transition-colors py-2 px-2 rounded-lg hover:bg-gold-500/5"
                >
                  {item.label}
                </Link>
              ))}
              
              {/* Mobile Resource Dropdown */}
              <div>
                <button
                  onClick={() => setIsMobileResourceOpen(!isMobileResourceOpen)}
                  className={`flex items-center justify-between w-full py-2 px-2 rounded-lg transition-colors ${
                    isResourcePage ? 'text-gold-400 bg-gold-500/10' : 'text-muted-foreground hover:text-gold-400 hover:bg-gold-500/5'
                  }`}
                >
                  <span>Resources</span>
                  <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isMobileResourceOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isMobileResourceOpen && (
                  <div className="mt-2 ml-4 pl-4 border-l border-gold-500/20 space-y-1">
                    {resourceItems.map((item) => {
                      const IconComponent = item.icon;
                      return (
                        <Link
                          key={item.label}
                          href={item.href}
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            setIsMobileResourceOpen(false);
                          }}
                          className={`flex items-center gap-2 py-2 px-2 rounded-lg transition-colors ${
                            pathname === item.href 
                              ? 'text-gold-400 bg-gold-500/10' 
                              : 'text-muted-foreground hover:text-gold-400 hover:bg-gold-500/5'
                          }`}
                        >
                          <IconComponent className="w-4 h-4" />
                          <span className="text-sm">{item.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
              
              <div className="pt-2 mt-2 border-t border-gold-500/10">
                {status === 'loading' ? (
                  <div className="flex justify-center py-2">
                    <Loader2 className="w-5 h-5 animate-spin text-gold-400" />
                  </div>
                ) : session ? (
                  <div className="space-y-2">
                    {/* User Info */}
                    <div className="flex items-center gap-2 py-2 px-2">
                      <div className="w-8 h-8 rounded-full bg-gold-500/20 flex items-center justify-center">
                        <User className="w-4 h-4 text-gold-400" />
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-foreground">
                          {session.user?.name || session.user?.email?.split('@')[0]}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {session.user?.email}
                        </div>
                      </div>
                      <Badge className="bg-gold-500/20 text-gold-400 text-xs">
                        Free
                      </Badge>
                    </div>

                    <Link 
                      href="/premium"
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="flex items-center gap-2 py-2 px-2 rounded-lg hover:bg-gold-500/5 text-muted-foreground hover:text-gold-400"
                    >
                      <LayoutDashboard className="w-4 h-4" />
                      <span className="text-sm">Dashboard</span>
                    </Link>

                    <button
                      onClick={handleSignOut}
                      className="flex items-center gap-2 py-2 px-2 rounded-lg hover:bg-red-500/10 w-full text-red-400"
                    >
                      <LogOut className="w-4 h-4" />
                      <span className="text-sm">Sign Out</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Link href="/login" onClick={() => setIsMobileMenuOpen(false)}>
                      <Button 
                        variant="ghost"
                        className="text-gold-400 hover:text-gold-300 hover:bg-gold-500/10 justify-start w-full"
                      >
                        Sign In
                      </Button>
                    </Link>
                    <Link href="/signup" onClick={() => setIsMobileMenuOpen(false)}>
                      <Button 
                        className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold justify-start w-full"
                      >
                        Sign Up
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
