'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Brain, ChevronRight, RotateCcw, Sparkles, TrendingUp, Users } from 'lucide-react';

const questions = [
  {
    id: 1,
    question: 'Ketika menghadapi masalah kompleks, Anda cenderung...',
    options: [
      { text: 'Menganalisis data secara mendetail sebelum mengambil keputusan', type: 'analytical' },
      { text: 'Mengandalkan intuisi dan perasaan', type: 'intuitive' },
      { text: 'Mendiskusikan dengan orang lain untuk mendapat perspektif', type: 'collaborative' },
      { text: 'Bertindak cepat dan menyesuaikan seiring berjalannya waktu', type: 'pragmatic' },
    ],
  },
  {
    id: 2,
    question: 'Bagaimana Anda mengisi waktu luang?',
    options: [
      { text: 'Membaca buku atau belajar hal baru', type: 'analytical' },
      { text: 'Meditasi atau aktivitas kreatif', type: 'intuitive' },
      { text: 'Berkumpul dengan teman atau keluarga', type: 'collaborative' },
      { text: 'Olahraga atau aktivitas fisik', type: 'pragmatic' },
    ],
  },
  {
    id: 3,
    question: 'Apakah yang paling memotivasi Anda?',
    options: [
      { text: 'Pemahaman mendalam dan pengetahuan', type: 'analytical' },
      { text: 'Makna dan tujuan hidup', type: 'intuitive' },
      { text: 'Koneksi dan dampak sosial', type: 'collaborative' },
      { text: 'Pencapaian dan hasil nyata', type: 'pragmatic' },
    ],
  },
  {
    id: 4,
    question: 'Dalam situasi stress, Anda biasanya...',
    options: [
      { text: 'Mencari akar masalah dan solusi logis', type: 'analytical' },
      { text: 'Mengambil waktu untuk refleksi internal', type: 'intuitive' },
      { text: 'Bercerita kepada seseorang yang dipercaya', type: 'collaborative' },
      { text: 'Fokus pada tindakan yang bisa dilakukan', type: 'pragmatic' },
    ],
  },
];

const personalityTypes = {
  analytical: {
    title: 'The Analyst',
    description: 'Anda adalah pemikir mendalam yang menghargai logika dan data. Keputusan Anda berdasarkan analisis komprehensif dan Anda menikmati memecahkan masalah kompleks.',
    strengths: ['Kritis & Objektif', 'Detail-oriented', 'Problem Solver'],
    color: 'from-blue-500 to-cyan-600',
  },
  intuitive: {
    title: 'The Intuitive',
    description: 'Anda memiliki kepekaan tinggi terhadap nuansa dan makna. Intuisi Anda tajam dan Anda sering menemukan insight yang tersembunyi bagi orang lain.',
    strengths: ['Visioner', 'Kreatif', 'Empathetic'],
    color: 'from-purple-500 to-violet-600',
  },
  collaborative: {
    title: 'The Collaborator',
    description: 'Anda berkembang melalui interaksi sosial dan menghargai perspektif orang lain. Anda adalah jembatan yang menghubungkan ide dan orang.',
    strengths: ['Komunikator Ulung', 'Team Player', 'Emotionally Intelligent'],
    color: 'from-emerald-500 to-green-600',
  },
  pragmatic: {
    title: 'The Pragmatist',
    description: 'Anda fokus pada hasil dan aksi. Tidak suka bertele-tele, Anda percaya bahwa solusi terbaik adalah yang bisa langsung diterapkan.',
    strengths: ['Action-Oriented', 'Efisien', 'Result-Driven'],
    color: 'from-orange-500 to-red-600',
  },
};

export default function PsychExperiment() {
  const [currentStep, setCurrentStep] = useState<'intro' | 'questions' | 'result'>('intro');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({
    analytical: 0,
    intuitive: 0,
    collaborative: 0,
    pragmatic: 0,
  });

  const handleAnswer = (type: string) => {
    setAnswers((prev) => ({
      ...prev,
      [type]: prev[type] + 1,
    }));

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setCurrentStep('result');
    }
  };

  const getDominantType = () => {
    const maxType = Object.entries(answers).reduce((a, b) =>
      a[1] > b[1] ? a : b
    );
    return maxType[0] as keyof typeof personalityTypes;
  };

  const resetExperiment = () => {
    setCurrentStep('intro');
    setCurrentQuestion(0);
    setAnswers({
      analytical: 0,
      intuitive: 0,
      collaborative: 0,
      pragmatic: 0,
    });
  };

  const progress = currentStep === 'questions' 
    ? ((currentQuestion + 1) / questions.length) * 100 
    : 0;

  return (
    <section className="section-padding bg-charcoal-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/20 to-transparent" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Psych Experiment
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Temukan Tipe </span>
            <span className="gradient-gold-text">Kepribadian</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Jawab beberapa pertanyaan singkat untuk mengungkap pola pikir dominan Anda.
          </p>
        </div>

        {/* Experiment Card */}
        <div className="max-w-2xl mx-auto">
          <Card className="bg-charcoal-900/50 border-gold-500/10 overflow-hidden">
            <CardContent className="p-6 sm:p-8">
              {/* Intro State */}
              {currentStep === 'intro' && (
                <div className="text-center py-8 animate-fade-in">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-gold-500/20 to-gold-600/10 border border-gold-500/20 flex items-center justify-center mx-auto mb-6">
                    <Brain className="w-10 h-10 text-gold-400" />
                  </div>
                  <h3 className="text-2xl font-semibold text-foreground mb-4">
                    Mini Personality Assessment
                  </h3>
                  <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                    Temukan bagaimana cara Anda berpikir dan mengambil keputusan melalui 4 pertanyaan singkat. 
                    Proses ini hanya membutuhkan waktu sekitar 2 menit.
                  </p>
                  <Button
                    onClick={() => setCurrentStep('questions')}
                    className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-charcoal-950 font-semibold px-8"
                  >
                    Mulai Assessment
                    <ChevronRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              )}

              {/* Questions State */}
              {currentStep === 'questions' && (
                <div className="animate-fade-in">
                  {/* Progress */}
                  <div className="mb-8">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Pertanyaan {currentQuestion + 1} dari {questions.length}</span>
                      <span className="text-gold-400">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-1 bg-charcoal-800" />
                  </div>

                  {/* Question */}
                  <div className="mb-6">
                    <h3 className="text-xl font-medium text-foreground">
                      {questions[currentQuestion].question}
                    </h3>
                  </div>

                  {/* Options */}
                  <div className="space-y-3">
                    {questions[currentQuestion].options.map((option, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleAnswer(option.type)}
                        className="w-full text-left p-4 rounded-xl bg-charcoal-800/50 border border-gold-500/10 hover:border-gold-500/30 hover:bg-charcoal-800 transition-all duration-300 group"
                      >
                        <span className="text-muted-foreground group-hover:text-foreground transition-colors">
                          {option.text}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Result State */}
              {currentStep === 'result' && (
                <div className="text-center py-4 animate-fade-in">
                  {(() => {
                    const dominantType = getDominantType();
                    const personality = personalityTypes[dominantType];
                    
                    return (
                      <>
                        <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${personality.color} flex items-center justify-center mx-auto mb-6`}>
                          <Sparkles className="w-10 h-10 text-white" />
                        </div>
                        
                        <div className="mb-2">
                          <span className="text-xs uppercase tracking-wider text-muted-foreground">
                            Tipe Kepribadian Anda
                          </span>
                        </div>
                        
                        <h3 className="text-2xl font-bold gradient-gold-text mb-4">
                          {personality.title}
                        </h3>
                        
                        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                          {personality.description}
                        </p>
                        
                        {/* Strengths */}
                        <div className="flex flex-wrap justify-center gap-2 mb-8">
                          {personality.strengths.map((strength, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1 rounded-full text-xs bg-gold-500/10 text-gold-400 border border-gold-500/20"
                            >
                              {strength}
                            </span>
                          ))}
                        </div>
                        
                        {/* Score Distribution */}
                        <div className="bg-charcoal-800/50 rounded-xl p-4 mb-6">
                          <div className="text-sm text-muted-foreground mb-3">Distribusi Jawaban</div>
                          <div className="space-y-2">
                            {Object.entries(answers).map(([type, count]) => {
                              const p = personalityTypes[type as keyof typeof personalityTypes];
                              return (
                                <div key={type} className="flex items-center gap-3">
                                  <div className="w-20 text-xs text-muted-foreground text-right">
                                    {p.title.replace('The ', '')}
                                  </div>
                                  <div className="flex-1 h-2 bg-charcoal-900 rounded-full overflow-hidden">
                                    <div
                                      className={`h-full bg-gradient-to-r ${p.color} transition-all duration-500`}
                                      style={{ width: `${(count / questions.length) * 100}%` }}
                                    />
                                  </div>
                                  <div className="w-8 text-xs text-muted-foreground">
                                    {Math.round((count / questions.length) * 100)}%
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        
                        <Button
                          variant="outline"
                          onClick={resetExperiment}
                          className="border-gold-500/30 text-gold-400 hover:bg-gold-500/10 hover:border-gold-500/50"
                        >
                          <RotateCcw className="mr-2 w-4 h-4" />
                          Ulangi Assessment
                        </Button>
                      </>
                    );
                  })()}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
