'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, BookOpen, Brain, Target, LineChart, Compass, Lightbulb, Shield, Zap, Heart, Award } from 'lucide-react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
} from '@/components/ui/carousel';

const previewPages = [
  {
    id: 1,
    title: 'Pemetaan Kognitif',
    subtitle: 'Pahami Arsitektur Pikiran',
    description: 'Analisis mendalam tentang struktur kognitif Anda dan bagaimana pola pikir mempengaruhi keputusan sehari-hari.',
    icon: Brain,
    color: 'from-gold-500 to-gold-600',
  },
  {
    id: 2,
    title: 'Life Trajectory',
    subtitle: 'Visualisasi Masa Depan',
    description: 'Prediksi dan visualisasi lintasan kehidupan berdasarkan pola perilaku dan keputusan saat ini.',
    icon: Target,
    color: 'from-gold-400 to-gold-500',
  },
  {
    id: 3,
    title: 'Decision Matrix',
    subtitle: 'Analisis Keputusan Optimal',
    description: 'Sistem pendukung keputusan berbasis data untuk membantu Anda memilih jalan terbaik.',
    icon: LineChart,
    color: 'from-gold-500 to-gold-700',
  },
  {
    id: 4,
    title: 'Inner Compass',
    subtitle: 'Temukan Arah Hidup',
    description: 'Panduan intuitif untuk menemukan tujuan dan makna dalam perjalanan hidup Anda.',
    icon: Compass,
    color: 'from-gold-300 to-gold-500',
  },
  {
    id: 5,
    title: 'Insight Generator',
    subtitle: 'Wawasan Mendalam',
    description: 'AI-powered system yang menghasilkan insight personal dari data perilaku Anda.',
    icon: Lightbulb,
    color: 'from-gold-400 to-gold-600',
  },
  {
    id: 6,
    title: 'Mind Shield',
    subtitle: 'Proteksi Mental',
    description: 'Teknik dan strategi untuk membangun ketahanan mental menghadapi tekanan.',
    icon: Shield,
    color: 'from-gold-500 to-gold-600',
  },
  {
    id: 7,
    title: 'Energy Optimizer',
    subtitle: 'Kelola Energi',
    description: 'Pahami ritme energi optimal dan maksimalkan produktivitas sepanjang hari.',
    icon: Zap,
    color: 'from-gold-400 to-gold-500',
  },
  {
    id: 8,
    title: 'Emotional Map',
    subtitle: 'Peta Emosional',
    description: 'Eksplorasi dan pemahaman mendalam tentang lanskap emosi Anda.',
    icon: Heart,
    color: 'from-gold-500 to-gold-700',
  },
  {
    id: 9,
    title: 'Achievement Path',
    subtitle: 'Jalur Pencapaian',
    description: 'Rencana aksi terstruktur untuk mencapai tujuan personal dan profesional.',
    icon: Award,
    color: 'from-gold-300 to-gold-500',
  },
  {
    id: 10,
    title: 'Knowledge Synthesis',
    subtitle: 'Sintesis Pengetahuan',
    description: 'Integrasi dan sintesis semua pembelajaran menjadi wisdom yang actionable.',
    icon: BookOpen,
    color: 'from-gold-400 to-gold-600',
  },
];

export default function Preview() {
  return (
    <section id="preview" className="section-padding bg-charcoal-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent" />
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent" />
      
      <div className="container-width relative">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-1 rounded-full text-xs font-medium bg-gold-500/10 text-gold-400 border border-gold-500/20 mb-4">
            Preview Eksklusif
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            <span className="text-foreground">Jelajahi </span>
            <span className="gradient-gold-text">Semua Fitur</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Temukan 10 modul analisis premium yang dirancang untuk mentransformasi cara Anda berpikir dan mengambil keputusan.
          </p>
        </div>

        {/* Carousel */}
        <Carousel
          opts={{
            align: 'start',
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent className="-ml-2 sm:-ml-4">
            {previewPages.map((page, index) => {
              const IconComponent = page.icon;
              return (
                <CarouselItem key={page.id} className="pl-2 sm:pl-4 basis-full sm:basis-1/2 lg:basis-1/3">
                  <Card className="group relative h-full bg-charcoal-900/50 border-gold-500/10 hover:border-gold-500/30 transition-all duration-500 hover:shadow-xl hover:shadow-gold-500/5 overflow-hidden">
                    {/* Gradient overlay on hover */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <div className="absolute inset-0 bg-gradient-to-br from-gold-500/5 to-transparent" />
                    </div>
                    
                    <CardContent className="p-6 relative">
                      {/* Page number */}
                      <div className="absolute top-4 right-4 text-5xl font-bold text-gold-500/5 group-hover:text-gold-500/10 transition-colors">
                        {String(page.id).padStart(2, '0')}
                      </div>
                      
                      {/* Icon */}
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${page.color} p-0.5 mb-5 group-hover:scale-110 transition-transform duration-300`}>
                        <div className="w-full h-full rounded-xl bg-charcoal-900 flex items-center justify-center">
                          <IconComponent className="w-6 h-6 text-gold-400" />
                        </div>
                      </div>
                      
                      {/* Content */}
                      <div className="mb-2">
                        <span className="text-xs text-gold-500 uppercase tracking-wider">
                          {page.subtitle}
                        </span>
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-gold-400 transition-colors">
                        {page.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {page.description}
                      </p>
                    </CardContent>
                  </Card>
                </CarouselItem>
              );
            })}
          </CarouselContent>
          
          {/* Navigation */}
          <div className="hidden sm:block">
            <CarouselPrevious className="left-0 -translate-x-1/2 border-gold-500/30 text-gold-400 hover:bg-gold-500/10 hover:border-gold-500/50" />
            <CarouselNext className="right-0 translate-x-1/2 border-gold-500/30 text-gold-400 hover:bg-gold-500/10 hover:border-gold-500/50" />
          </div>
        </Carousel>

        {/* Mobile swipe hint */}
        <div className="flex sm:hidden justify-center mt-6 gap-2">
          {previewPages.map((_, index) => (
            <div
              key={index}
              className="w-2 h-2 rounded-full bg-gold-500/30"
            />
          ))}
        </div>
      </div>
    </section>
  );
}
